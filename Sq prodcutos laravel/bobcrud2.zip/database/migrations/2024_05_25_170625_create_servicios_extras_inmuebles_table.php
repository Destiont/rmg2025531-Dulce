<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateServiciosExtrasInmueblesTable extends Migration
{
    public function up()
    {
        Schema::create('servicios_extras_inmuebles', function (Blueprint $table) {
            $table->id('id_ser_ext_inm');
            $table->unsignedBigInteger('id_servicio_extra');
            $table->unsignedBigInteger('id_inmueble');
            $table->string('especificacion_ser_ext_inm', 255);

            $table->foreign('id_servicio_extra')->references('id_servicio_extra')->on('servicios_extras')->onDelete('cascade');
            $table->foreign('id_inmueble')->references('id_inmueble')->on('inmuebles')->onDelete('cascade');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('servicios_extras_inmuebles');
    }
}
