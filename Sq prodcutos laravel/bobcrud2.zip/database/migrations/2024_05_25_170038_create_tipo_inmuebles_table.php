<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTipoInmueblesTable extends Migration
{
    public function up()
    {
        Schema::create('tipo_inmuebles', function (Blueprint $table) {
            $table->id('id_tipo_inmueble');
            $table->string('nombre_tipo_inmueble', 50);
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('tipo_inmuebles');
    }
}
