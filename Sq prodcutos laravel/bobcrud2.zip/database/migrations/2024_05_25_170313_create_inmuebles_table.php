<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateInmueblesTable extends Migration
{
    public function up()
    {
        Schema::create('inmuebles', function (Blueprint $table) {
            $table->id('id_inmueble');
            $table->unsignedBigInteger('tipo_inmueble');
            $table->unsignedBigInteger('tipo_venta_inmueble');
            $table->string('descripcion_inm', 500);
            $table->string('ubicacion_inm', 100);
            $table->string('dimensiones_inm', 50);
            $table->integer('tamano_inm');
            $table->integer('habitacion_inm');
            $table->integer('bano_inm');
            $table->integer('precio_inm');
            $table->unsignedBigInteger('id_estado');
            $table->timestamps();

            // Definición de las relaciones con las tablas relacionadas
            $table->foreign('tipo_inmueble')->references('id_tipo_inmueble')->on('tipo_inmuebles');
            $table->foreign('tipo_venta_inmueble')->references('id_tipo_venta_inmueble')->on('tipo_venta_inmuebles');
            $table->foreign('id_estado')->references('id_estado')->on('estados');
        });
    }

    public function down()
    {
        Schema::dropIfExists('inmuebles');
    }
}
