<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateEmpleadosTable extends Migration
{
    public function up()
    {
        Schema::create('empleados', function (Blueprint $table) {
            $table->id('id_empleado');
            $table->unsignedBigInteger('id_usuario');
            $table->foreign('id_usuario')->references('id')->on('users')->onDelete('cascade');
            $table->string('nombre_emp', 100);
            $table->string('apellido_emp', 100);
            $table->date('fecha_contratacion_emp');
            $table->date('fecha_nacimiento_emp');
            $table->unsignedBigInteger('id_genero');
            $table->foreign('id_genero')->references('id_genero')->on('generos')->onDelete('cascade');
            $table->string('direccion_emp', 100);
            $table->string('telefono_emp', 15); // Cambié a string para soportar caracteres especiales y largos
            $table->decimal('salario_emp', 10, 2); // Cambié a decimal para representar mejor el salario
            $table->unsignedBigInteger('id_estado');
            $table->foreign('id_estado')->references('id_estado')->on('estados')->onDelete('cascade');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('empleados');
    }
}
