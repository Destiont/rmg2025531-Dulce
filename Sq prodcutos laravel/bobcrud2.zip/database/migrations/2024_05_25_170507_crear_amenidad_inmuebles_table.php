<?php


use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CrearAmenidadInmueblesTable extends Migration
{
    public function up()
    {
        Schema::create('amenidades_inmueble', function (Blueprint $table) {
            $table->id('id_ame_inm');
            $table->unsignedBigInteger('id_amenidad');
            $table->unsignedBigInteger('id_inmueble');
            $table->string('especificacion_ame_inm', 255);
            $table->timestamps();

            $table->foreign('id_amenidad')->references('id_amenidad')->on('amenidades');
            $table->foreign('id_inmueble')->references('id_inmueble')->on('inmuebles');
        });
    }

    public function down()
    {
        Schema::dropIfExists('amenidades_inmueble');
    }
}
