<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateServiciosConvenientesInmueblesTable extends Migration
{
    public function up()
    {
        Schema::create('servicios_convenientes_inmuebles', function (Blueprint $table) {
            $table->id('id_ser_con_inm');
            $table->unsignedBigInteger('id_servicio_conveniente');
            $table->unsignedBigInteger('id_inmueble');
            $table->string('especificacion_ser_con_inm', 255);

            $table->foreign('id_servicio_conveniente')->references('id_servicio_conveniente')->on('servicios_convenientes')->onDelete('cascade');
            $table->foreign('id_inmueble')->references('id_inmueble')->on('inmuebles')->onDelete('cascade');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('servicios_convenientes_inmuebles');
    }
}
