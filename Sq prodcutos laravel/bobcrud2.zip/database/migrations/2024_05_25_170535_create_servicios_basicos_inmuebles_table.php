<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateServiciosBasicosInmueblesTable extends Migration
{
    public function up()
    {
        Schema::create('servicios_basicos_inmuebles', function (Blueprint $table) {
            $table->id('id_ser_bas_inm');
            $table->unsignedBigInteger('id_servicio_basico');
            $table->unsignedBigInteger('id_inmueble');
            $table->string('especificacion_ser_bas_inm', 255);

            $table->foreign('id_servicio_basico')->references('id_servicio_basico')->on('servicios_basicos')->onDelete('cascade');
            $table->foreign('id_inmueble')->references('id_inmueble')->on('inmuebles')->onDelete('cascade');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('servicios_basicos_inmuebles');
    }
}
