<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateServiciosConvenientesTable extends Migration
{
    public function up()
    {
        Schema::create('servicios_convenientes', function (Blueprint $table) {
            $table->id('id_servicio_conveniente');
            $table->string('nombre_servicio_conveniente', 50);
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('servicios_convenientes');
    }
}
