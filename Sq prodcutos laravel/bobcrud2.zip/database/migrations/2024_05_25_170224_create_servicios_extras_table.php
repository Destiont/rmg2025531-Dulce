<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateServiciosExtrasTable extends Migration
{
    public function up()
    {
        Schema::create('servicios_extras', function (Blueprint $table) {
            $table->id('id_servicio_extra');
            $table->string('nombre_servicio_extra', 50);
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('servicios_extras');
    }
}
