<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ServicioConvenienteInmueble extends Model
{
    protected $table = 'servicios_convenientes_inmuebles';
    
    protected $primaryKey = 'id_ser_con_inm';

    protected $fillable = [
        'id_servicio_conveniente',
        'id_inmueble',
        'especificacion_ser_con_inm',
    ];

    // Relación con el modelo ServicioConveniente
    public function servicioConveniente()
    {
        return $this->belongsTo(ServicioConveniente::class, 'id_servicio_conveniente');
    }

    // Relación con el modelo Inmueble
    public function inmueble()
    {
        return $this->belongsTo(Inmueble::class, 'id_inmueble');
    }
}
