<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Inmueble extends Model
{
    use HasFactory;

    protected $table = 'inmuebles';
    protected $primaryKey = 'id_inmueble';

    protected $fillable = [
        'tipo_inmueble',
        'tipo_venta_inmueble',
        'descripcion_inm',
        'ubicacion_inm',
        'dimensiones_inm',
        'tamano_inm',
        'habitacion_inm',
        'bano_inm',
        'precio_inm',
        'id_estado'
    ];

    public function tipoInmueble()
    {
        return $this->belongsTo(TipoInmueble::class, 'tipo_inmueble', 'id_tipo_inmueble');
    }

    public function tipoVentaInmueble()
    {
        return $this->belongsTo(TipoVentaInmueble::class, 'tipo_venta_inmueble', 'id_tipo_venta_inmueble');
    }

    public function estado()
    {
        return $this->belongsTo(Estado::class, 'id_estado', 'id_estado');
    }
}
