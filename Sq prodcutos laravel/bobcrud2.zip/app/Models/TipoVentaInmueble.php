<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TipoVentaInmueble extends Model
{
    use HasFactory;

    protected $table = 'tipo_venta_inmuebles';
    protected $primaryKey = 'id_tipo_venta_inmueble';
    protected $fillable = ['nombre_tipo_venta_inmueble'];

    // Relaciones con otros modelos si las tienes
    // public function otrasRelaciones() {}

}
