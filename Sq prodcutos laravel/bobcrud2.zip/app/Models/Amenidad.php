<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Amenidad extends Model
{
    use HasFactory;

    protected $table = 'amenidades';
    protected $primaryKey = 'id_amenidad';
    protected $fillable = [
        'nombre_amenidad',
    ];
}
