<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AmenidadInmueble extends Model
{
    use HasFactory;

    protected $table = 'amenidades_inmueble';
    protected $primaryKey = 'id_ame_inm';
    protected $fillable = [
        'id_amenidad',
        'id_inmueble',
        'especificacion_ame_inm'
    ];

    public function amenidad()
    {
        return $this->belongsTo(Amenidad::class, 'id_amenidad');
    }

    public function inmueble()
    {
        return $this->belongsTo(Inmueble::class, 'id_inmueble');
    }
}
