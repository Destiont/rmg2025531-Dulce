<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ServicioBasicoInmueble extends Model
{
    use HasFactory;

    protected $table = 'servicios_basicos_inmuebles'; // Nombre de la tabla en la base de datos

    protected $primaryKey = 'id_ser_bas_inm'; // Nombre de la clave primaria

    protected $fillable = [
        'id_servicio_basico',
        'id_inmueble',
        'especificacion_ser_bas_inm',
    ];

    // Relación con el modelo ServicioBasico
    public function servicioBasico()
    {
        return $this->belongsTo(ServicioBasico::class, 'id_servicio_basico', 'id_servicio_basico');
    }

    // Relación con el modelo Inmueble
    public function inmueble()
    {
        return $this->belongsTo(Inmueble::class, 'id_inmueble', 'id_inmueble');
    }
}
