<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cliente extends Model
{
    use HasFactory;

    protected $primaryKey = 'id_cliente';

    protected $fillable = [
        'cedula_identidad',
        'nombre_cliente',
        'apellido_cliente',
        'telefono_cliente',
        'correo_cliente'
    ];

    public static $rules = [
        'cedula_identidad' => 'required|unique:clientes,cedula_identidad',
        'nombre_cliente' => 'required|string|max:255',
        'apellido_cliente' => 'required|string|max:255',
        'telefono_cliente' => 'required|string|max:15',
        'correo_cliente' => 'nullable|email|max:255',
    ];
}
