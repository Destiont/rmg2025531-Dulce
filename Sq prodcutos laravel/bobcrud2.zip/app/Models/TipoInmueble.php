<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TipoInmueble extends Model
{
    protected $fillable = ['nombre_tipo_inmueble'];

    // Especificar el nombre de la clave primaria si es diferente de 'id'
    protected $primaryKey = 'id_tipo_inmueble';

    public $timestamps = false; // Supongo que esta tabla no tiene timestamps

    // Resto del código del modelo
}
