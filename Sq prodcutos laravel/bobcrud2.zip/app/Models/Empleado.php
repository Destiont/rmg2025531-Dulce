<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

use App\Models\User;


class Empleado extends Model
{
    protected $primaryKey = 'id_empleado';
    use HasFactory;

    protected $fillable = [
        'id_usuario',
        'nombre_emp',
        'apellido_emp',
        'fecha_contratacion_emp',
        'fecha_nacimiento_emp',
        'id_genero',
        'direccion_emp',
        'telefono_emp',
        'salario_emp',
        'id_estado',
    ];

    public function usuario()
    {
        return $this->belongsTo(User::class, 'id_usuario');
    }

    public function genero()
    {
        return $this->belongsTo(Genero::class, 'id_genero');
    }

    public function estado()
    {
        return $this->belongsTo(Estado::class, 'id_estado');
    }
}
