<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ServicioExtra extends Model
{
    use HasFactory;

    protected $table = 'servicios_extras';
    protected $primaryKey = 'id_servicio_extra';
    protected $fillable = ['nombre_servicio_extra'];

    // Otras relaciones o métodos si los tienes
    // public function otrasRelaciones() {}

}
