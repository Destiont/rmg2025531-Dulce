<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ServicioExtraInmueble extends Model
{
    use HasFactory;
    protected $table = 'servicios_extras_inmuebles';

    protected $primaryKey = 'id_ser_ext_inm';

    protected $fillable = [
        'id_servicio_extra',
        'id_inmueble',
        'especificacion_ser_ext_inm',
    ];

    public function servicioExtra()
    {
        return $this->belongsTo(ServicioExtra::class, 'id_servicio_extra');
    }

    public function inmueble()
    {
        return $this->belongsTo(Inmueble::class, 'id_inmueble');
    }
}
