<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class InmueblesVista extends Model
{
    use HasFactory;

    protected $table = 'inmuebles_vista';

    protected $primaryKey = 'id_inm_vista';

    protected $fillable = [
        'id_inmueble',
        'ruta_inm_vista',
        'orden_inm_vista',
    ];

    public function inmueble()
    {
        return $this->belongsTo(Inmueble::class, 'id_inmueble', 'id');
    }
}
