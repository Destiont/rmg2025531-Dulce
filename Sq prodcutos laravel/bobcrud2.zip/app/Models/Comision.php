<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Comision extends Model
{
    use HasFactory;

    protected $table = 'comisiones';
    protected $primaryKey = 'id_comision';

    protected $fillable = [
        'id_empleado',
        'id_inmueble',
        'precio_comi',
    ];

    public function empleado()
    {
        return $this->belongsTo(Empleado::class, 'id_empleado');
    }

    public function inmueble()
    {
        return $this->belongsTo(Inmueble::class, 'id_inmueble');
    }
}
