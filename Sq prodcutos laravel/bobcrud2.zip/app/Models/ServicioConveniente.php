<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ServicioConveniente extends Model
{
    use HasFactory;

    protected $table = 'servicios_convenientes';
    protected $primaryKey = 'id_servicio_conveniente';
    protected $fillable = ['nombre_servicio_conveniente'];

    // Otras relaciones o métodos si los tienes
    // public function otrasRelaciones() {}

}
