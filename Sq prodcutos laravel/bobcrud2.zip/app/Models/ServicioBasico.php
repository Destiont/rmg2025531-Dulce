<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ServicioBasico extends Model
{
    use HasFactory;

    protected $table = 'servicios_basicos';
    protected $primaryKey = 'id_servicio_basico';
    protected $fillable = ['nombre_servicio_basico'];

    // Otras relaciones o métodos si los tienes
    // public function otrasRelaciones() {}

}
