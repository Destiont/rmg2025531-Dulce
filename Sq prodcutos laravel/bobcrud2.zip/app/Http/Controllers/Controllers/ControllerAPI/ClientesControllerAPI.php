<?php

namespace App\Http\Controllers\Controllers\ControllerAPI;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ClientesControllerAPI extends Controller
{
    //
}
