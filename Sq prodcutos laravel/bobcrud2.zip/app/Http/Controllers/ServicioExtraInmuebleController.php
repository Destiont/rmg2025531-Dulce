<?php

namespace App\Http\Controllers;

use App\Models\ServicioExtraInmueble;
use App\Models\ServicioExtra;
use App\Models\Inmueble;
use Illuminate\Http\Request;

class ServicioExtraInmuebleController extends Controller
{
// app/Http/Controllers/ServicioExtraInmuebleController.php

public function index(Request $request)
{
    $perPage = 10; // Number of items per page
    $currentPage = $request->input('page', 1);
    $search = $request->input('search');

    $query = ServicioExtraInmueble::query();

    if ($search) {
        $query->whereHas('servicioExtra', function ($query) use ($search) {
            $query->where('nombre_servicio_extra', 'like', '%' . $search . '%');
        });
    }

    $serviciosExtrasInmuebles = $query->paginate($perPage);

    return view('servicios_extras_inmuebles.index', [
        'serviciosExtrasInmuebles' => $serviciosExtrasInmuebles,
        'currentPage' => $serviciosExtrasInmuebles->currentPage(),
        'lastPage' => $serviciosExtrasInmuebles->lastPage(),
        'search' => $search
    ]);
}

    public function create()
    {
        $serviciosExtras = ServicioExtra::all();
        $inmuebles = Inmueble::all();
        return view('servicios_extras_inmuebles.create', compact('serviciosExtras', 'inmuebles'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'id_servicio_extra' => 'required|exists:servicios_extras,id_servicio_extra',
            'id_inmueble' => 'required|exists:inmuebles,id_inmueble',
            'especificacion_ser_ext_inm' => 'required|string|max:255',
        ]);

        try {
            ServicioExtraInmueble::create($request->all());
            return redirect()->route('servicios_extras_inmuebles.index')->with('success', 'Servicio extra para inmueble creado exitosamente.');
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'Hubo un error al crear el servicio extra para inmueble: ' . $e->getMessage());
        }
    }
}
