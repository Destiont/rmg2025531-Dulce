<?php

namespace App\Http\Controllers;

use App\Models\Amenidad;
use Illuminate\Http\Request;

class AmenidadController extends Controller
{
    public function index()
    {
        $amenidades = Amenidad::all();
        return view('amenidades.index', compact('amenidades'));
    }

    public function create()
    {
        return view('amenidades.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nombre_amenidad' => 'required|string|max:50',
        ]);

        Amenidad::create($request->all());

        return redirect()->route('amenidades.index')->with('success', 'Amenidad creada exitosamente.');
    }

    public function edit(Amenidad $amenidad)
    {
        return view('amenidades.edit', compact('amenidad'));
    }

    public function update(Request $request, Amenidad $amenidad)
    {
        $request->validate([
            'nombre_amenidad' => 'required|string|max:50',
        ]);

        $amenidad->update($request->all());

        return redirect()->route('amenidades.index')->with('success', 'Amenidad actualizada exitosamente.');
    }

    public function destroy(Amenidad $amenidad)
    {
        $amenidad->delete();

        return redirect()->route('amenidades.index')->with('success', 'Amenidad eliminada exitosamente.');
    }
}
