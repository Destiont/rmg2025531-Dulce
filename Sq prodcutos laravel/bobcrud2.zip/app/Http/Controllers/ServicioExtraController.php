<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ServicioExtra;

class ServicioExtraController extends Controller
{
    public function index()
    {
        $serviciosExtras = ServicioExtra::all();
        return view('servicios_extras.index', compact('serviciosExtras'));
    }

    public function create()
    {
        return view('servicios_extras.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nombre_servicio_extra' => 'required|max:50',
        ]);

        ServicioExtra::create($request->all());

        return redirect()->route('servicios_extras.index')
            ->with('success', 'Servicio extra creado exitosamente.');
    }

    public function show(ServicioExtra $servicioExtra)
    {
        return view('servicios_extras.show', compact('servicioExtra'));
    }

    public function edit(ServicioExtra $servicioExtra)
    {
        return view('servicios_extras.edit', compact('servicioExtra'));
    }

    public function update(Request $request, ServicioExtra $servicioExtra)
    {
        $request->validate([
            'nombre_servicio_extra' => 'required|max:50',
        ]);

        $servicioExtra->update($request->all());

        return redirect()->route('servicios_extras.index')
            ->with('success', 'Servicio extra actualizado exitosamente.');
    }

    public function destroy(ServicioExtra $servicioExtra)
    {
        $servicioExtra->delete();

        return redirect()->route('servicios_extras.index')
            ->with('success', 'Servicio extra eliminado exitosamente.');
    }
}
