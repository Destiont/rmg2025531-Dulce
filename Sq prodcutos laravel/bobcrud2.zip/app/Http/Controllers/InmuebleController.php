<?php

namespace App\Http\Controllers;

use App\Models\Inmueble;
use App\Models\TipoInmueble;
use App\Models\TipoVentaInmueble;
use App\Models\Estado;
use Illuminate\Http\Request;

class InmuebleController extends Controller
{
    public function index()
    {
        $inmuebles = Inmueble::with(['tipoInmueble', 'tipoVentaInmueble', 'estado'])
        ->where('id_estado', 1) // Solo inmuebles activos
        ->get();
        $inmuebles = Inmueble::paginate(10); // Cambia el número 10 por el número de resultados por página que desees


return view('inmuebles.index', compact('inmuebles'));
    }

    public function create()
    {
        $tiposInmueble = TipoInmueble::all();
        $tiposVentaInmueble = TipoVentaInmueble::all();
        $estados = Estado::all();
        return view('inmuebles.create', compact('tiposInmueble', 'tiposVentaInmueble', 'estados'));
    }

    public function store(Request $request)
    {
        $validatedData = $request->validate([
            'tipo_inmueble' => 'required|exists:tipo_inmuebles,id_tipo_inmueble',
            'tipo_venta_inmueble' => 'required|exists:tipo_venta_inmuebles,id_tipo_venta_inmueble',
            'descripcion_inm' => 'required|string|max:500',
            'ubicacion_inm' => 'required|string|max:100',
            'dimensiones_inm' => 'required|string|max:50',
            'tamano_inm' => 'required|integer',
            'habitacion_inm' => 'required|integer',
            'bano_inm' => 'required|integer',
            'precio_inm' => 'required|integer',
            'id_estado' => 'required|exists:estados,id_estado',
        ]);


        $inmueble = new Inmueble($request->all());
        $inmueble->id_estado = 1; // Estado activo
        $inmueble->save();


        if ($request->wantsJson()) {
            return response()->json(['message' => 'Inmueble created successfully', 'inmueble' => $inmueble], 201);
        }

        return redirect()->route('inmuebles.index')->with('success', 'Inmueble created successfully');
    }

    public function show($id)
    {
        $inmueble = Inmueble::with(['tipoInmueble', 'tipoVentaInmueble', 'estado'])->findOrFail($id);

        if (request()->wantsJson()) {
            return response()->json($inmueble);
        }

        return view('inmuebles.show', compact('inmueble'));
    }

    public function edit($id)
    {
        $inmueble = Inmueble::findOrFail($id);
        $tiposInmueble = TipoInmueble::all();
        $tiposVentaInmueble = TipoVentaInmueble::all();
        $estados = Estado::all();
        return view('inmuebles.edit', compact('inmueble', 'tiposInmueble', 'tiposVentaInmueble', 'estados'));
    }

    public function update(Request $request, $id)
    {
        $validatedData = $request->validate([
            'tipo_inmueble' => 'required|exists:tipo_inmuebles,id_tipo_inmueble',
            'tipo_venta_inmueble' => 'required|exists:tipo_venta_inmuebles,id_tipo_venta_inmueble',
            'descripcion_inm' => 'required|string|max:500',
            'ubicacion_inm' => 'required|string|max:100',
            'dimensiones_inm' => 'required|string|max:50',
            'tamano_inm' => 'required|integer',
            'habitacion_inm' => 'required|integer',
            'bano_inm' => 'required|integer',
            'precio_inm' => 'required|integer',
            'id_estado' => 'required|exists:estados,id_estado',
        ]);

        $inmueble = Inmueble::findOrFail($id);
        $inmueble->update($validatedData);

        if ($request->wantsJson()) {
            return response()->json(['message' => 'Inmueble updated successfully', 'inmueble' => $inmueble]);
        }

        return redirect()->route('inmuebles.index')->with('success', 'Inmueble updated successfully');
    }

    public function destroy($id)
    {
        $inmueble = Inmueble::findOrFail($id);
        $inmueble->id_estado = 2; // Estado inactivo
        $inmueble->save();

        if (request()->wantsJson()) {
            return response()->json(['message' => 'Inmueble deleted successfully']);
        }

        return redirect()->route('inmuebles.index')->with('success', 'Inmueble deleted successfully');
    }
}
