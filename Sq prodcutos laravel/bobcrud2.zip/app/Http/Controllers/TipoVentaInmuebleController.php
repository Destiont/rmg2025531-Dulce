<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\TipoVentaInmueble;

class TipoVentaInmuebleController extends Controller
{
    public function index()
    {
        $tipoVentaInmuebles = TipoVentaInmueble::all();
        return view('tipo_venta_inmuebles.index', compact('tipoVentaInmuebles'));
    }

    public function create()
    {
        return view('tipo_venta_inmuebles.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nombre_tipo_venta_inmueble' => 'required|max:50',
        ]);

        TipoVentaInmueble::create($request->all());

        return redirect()->route('tipo_venta_inmuebles.index')
            ->with('success', 'Tipo de venta de inmueble creado exitosamente.');
    }

    public function show(TipoVentaInmueble $tipoVentaInmueble)
    {
        return view('tipo_venta_inmuebles.show', compact('tipoVentaInmueble'));
    }

    public function edit(TipoVentaInmueble $tipoVentaInmueble)
    {
        return view('tipo_venta_inmuebles.edit', compact('tipoVentaInmueble'));
    }

    public function update(Request $request, TipoVentaInmueble $tipoVentaInmueble)
    {
        $request->validate([
            'nombre_tipo_venta_inmueble' => 'required|max:50',
        ]);

        $tipoVentaInmueble->update($request->all());

        return redirect()->route('tipo_venta_inmuebles.index')
            ->with('success', 'Tipo de venta de inmueble actualizado exitosamente.');
    }

    public function destroy(TipoVentaInmueble $tipoVentaInmueble)
    {
        $tipoVentaInmueble->delete();

        return redirect()->route('tipo_venta_inmuebles.index')
            ->with('success', 'Tipo de venta de inmueble eliminado exitosamente.');
    }
}
