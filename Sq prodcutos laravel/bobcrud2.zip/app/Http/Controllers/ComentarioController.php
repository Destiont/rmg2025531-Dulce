<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Comentario;

class ComentarioController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'descripcion_com' => 'required|string|max:255',
'puntuacion_com' => 'required|integer|min:1|max:5',

            'id_usuario' => 'required|exists:users,id',
        ]);

        Comentario::create([
            'descripcion_com' => $request->descripcion_com,
            'puntuacion_com' => $request->puntuacion_com,
            'id_usuario' => $request->id_usuario,
        ]);

        return redirect()->back()->with('success', 'Comentario guardado exitosamente');
    }
}
