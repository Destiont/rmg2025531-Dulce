<?php

namespace App\Http\Controllers;

use App\Models\Empleado;
use App\Models\User;
use App\Models\Usuario;
use App\Models\Genero;
use App\Models\Estado;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class EmpleadoController extends Controller
{
    public function index(Request $request)
    {
        $query = Empleado::with(['usuario', 'genero', 'estado'])
                         ->where('id_estado', 1); // Solo mostrar empleados activos

        if ($request->has('apellido_emp') && !empty($request->apellido_emp)) {
            $query->where('apellido_emp', 'like', '%' . $request->apellido_emp . '%');
        }

        $empleados = $query->paginate(10); // Paginar resultados, 10 por página

        return view('empleados.index', compact('empleados'));
    }

    public function create()
    {
        $usuarios = User::all();
        $generos = Genero::all();
        $estados = Estado::all();


        return view('empleados.create', compact('generos', 'estados', 'usuarios'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'id_usuario' => [
                'required',
                Rule::exists('users', 'id'), // Cambiado a 'users' y 'id'
            ],
            'nombre_emp' => 'required|string|max:100',
            'apellido_emp' => 'required|string|max:100',
            'fecha_contratacion_emp' => 'required|date',
            'fecha_nacimiento_emp' => 'required|date|before_or_equal:-18 years',
            'id_genero' => 'required|exists:generos,id_genero',
            'direccion_emp' => 'required|string|max:100',
            'telefono_emp' => 'required|numeric|digits_between:7,15',
            'salario_emp' => 'required|numeric|min:0',
            'id_estado' => 'required|exists:estados,id_estado',
        ], [
            'id_usuario.required' => 'El campo usuario es obligatorio.',
            'id_usuario.exists' => 'El usuario seleccionado no es válido.',
            'nombre_emp.required' => 'El campo nombre es obligatorio.',
            'nombre_emp.max' => 'El nombre no puede tener más de :max caracteres.',
            'apellido_emp.required' => 'El campo apellido es obligatorio.',
            'apellido_emp.max' => 'El apellido no puede tener más de :max caracteres.',
            'fecha_contratacion_emp.required' => 'El campo fecha de contratación es obligatorio.',
            'fecha_nacimiento_emp.required' => 'El campo fecha de nacimiento es obligatorio.',
            'fecha_nacimiento_emp.before_or_equal' => 'La fecha de nacimiento debe ser hace al menos 18 años.',
            'id_genero.required' => 'El campo género es obligatorio.',
            'id_genero.exists' => 'El género seleccionado no es válido.',
            'direccion_emp.required' => 'El campo dirección es obligatorio.',
            'direccion_emp.max' => 'La dirección no puede tener más de :max caracteres.',
            'telefono_emp.required' => 'El campo teléfono es obligatorio.',
            'telefono_emp.numeric' => 'El teléfono debe ser un número.',
            'telefono_emp.digits_between' => 'El teléfono debe tener entre :min y :max dígitos.',
            'salario_emp.required' => 'El campo salario es obligatorio.',
            'salario_emp.numeric' => 'El salario debe ser un número.',
            'salario_emp.min' => 'El salario no puede ser negativo.',
            'id_estado.required' => 'El campo estado es obligatorio.',
            'id_estado.exists' => 'El estado seleccionado no es válido.',
        ]);

        Empleado::create($request->all());
        return redirect()->route('empleados.index')->with('success', 'Empleado creado exitosamente.');
    }    public function edit(Empleado $empleado)
    {
        $generos = Genero::all();
        $estados = Estado::all();
        $usuarios = User::all();
        $usuarioSeleccionado = Usuario::find($empleado->id_usuario);

        return view('empleados.edit', compact('empleado', 'generos', 'estados', 'usuarios', 'usuarioSeleccionado'));
    }
    public function update(Request $request, Empleado $empleado)
    {
        $request->validate([
            'id_usuario' => 'required|exists:users,id',
            'nombre_emp' => 'required|string|max:100|regex:/^[\pL\s]+$/u',
            'apellido_emp' => 'required|string|max:100|regex:/^[\pL\s]+$/u',
            'fecha_contratacion_emp' => 'required|date',
            'fecha_nacimiento_emp' => 'required|date|before_or_equal:' . now()->subYears(18)->format('Y-m-d'),
            'id_genero' => 'required|exists:generos,id_genero',
            'direccion_emp' => 'required|string|max:100|regex:/^[\pL\s]+$/u',
            'telefono_emp' => 'required|numeric|digits_between:7,15',
            'salario_emp' => 'required|numeric|min:0',
            'id_estado' => 'required|exists:estados,id_estado',
        ], [
            'id_usuario.required' => 'El campo usuario es obligatorio.',
            'id_usuario.exists' => 'El usuario seleccionado no es válido.',
            'nombre_emp.required' => 'El campo nombre es obligatorio.',
            'nombre_emp.max' => 'El nombre no puede tener más de :max caracteres.',
            'nombre_emp.regex' => 'El nombre solo puede contener letras y espacios.',
            'apellido_emp.required' => 'El campo apellido es obligatorio.',
            'apellido_emp.max' => 'El apellido no puede tener más de :max caracteres.',
            'apellido_emp.regex' => 'El apellido solo puede contener letras y espacios.',
            'fecha_contratacion_emp.required' => 'El campo fecha de contratación es obligatorio.',
            'fecha_nacimiento_emp.required' => 'El campo fecha de nacimiento es obligatorio.',
            'fecha_nacimiento_emp.before_or_equal' => 'La fecha de nacimiento debe ser hace al menos 18 años.',
            'id_genero.required' => 'El campo género es obligatorio.',
            'id_genero.exists' => 'El género seleccionado no es válido.',
            'direccion_emp.required' => 'El campo dirección es obligatorio.',
            'direccion_emp.max' => 'La dirección no puede tener más de :max caracteres.',
            'direccion_emp.regex' => 'La dirección solo puede contener letras y espacios.',
            'telefono_emp.required' => 'El campo teléfono es obligatorio.',
            'telefono_emp.numeric' => 'El teléfono debe ser un número.',
            'telefono_emp.digits_between' => 'El teléfono debe tener entre :min y :max dígitos.',
            'salario_emp.required' => 'El campo salario es obligatorio.',
            'salario_emp.numeric' => 'El salario debe ser un número.',
            'salario_emp.min' => 'El salario no puede ser negativo.',
            'id_estado.required' => 'El campo estado es obligatorio.',
            'id_estado.exists' => 'El estado seleccionado no es válido.',
        ]);

        $empleado->update($request->all());
        return redirect()->route('empleados.index')->with('success', 'Empleado actualizado exitosamente.');
    }

    public function show(Empleado $empleado)
    {
        return view('empleados.show', compact('empleado'));
    }

    public function destroy(Empleado $empleado)
    {
        $empleado->id_estado = 2; // Cambiar estado a inactivo
        $empleado->save();

        return redirect()->route('empleados.index')->with('success', 'Empleado eliminado exitosamente.');
    }

}
