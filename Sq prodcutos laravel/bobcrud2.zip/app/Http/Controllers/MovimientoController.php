<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Movimiento;
use App\Models\Empleado;
use App\Models\Inmueble;

class MovimientoController extends Controller
{
    public function index()
    {
        $movimientos = Movimiento::all();
        return view('movimientos.index', compact('movimientos'));
    }

    public function create()
    {
        $empleados = Empleado::all();
        $inmuebles = Inmueble::all();
        return view('movimientos.create', compact('empleados', 'inmuebles'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'id_empleado' => 'required|exists:empleados,id_empleado',
            'id_inmueble' => 'required|exists:inmuebles,id_inmueble',
            'fecha_mov' => 'required|date',
            'precio_final_mov' => 'required|numeric|min:0',
            'comision_mov' => 'required|numeric|min:0',
        ]);

        Movimiento::create($request->all());

        return redirect()->route('movimientos.index')
            ->with('success', 'Movimiento creado exitosamente.');
    }

    public function show($id)
    {
        $movimiento = Movimiento::findOrFail($id);
        return view('movimientos.show', compact('movimiento'));
    }

    public function edit($id)
    {
        $movimiento = Movimiento::findOrFail($id);
        $empleados = Empleado::all();
        $inmuebles = Inmueble::all();
        return view('movimientos.edit', compact('movimiento', 'empleados', 'inmuebles'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'id_empleado' => 'required|exists:empleados,id_empleado',
            'id_inmueble' => 'required|exists:inmuebles,id_inmueble',
            'fecha_mov' => 'required|date',
            'precio_final_mov' => 'required|numeric|min:0',
            'comision_mov' => 'required|numeric|min:0',
        ]);

        $movimiento = Movimiento::findOrFail($id);
        $movimiento->update($request->all());

        return redirect()->route('movimientos.index')
            ->with('success', 'Movimiento actualizado exitosamente.');
    }

    public function destroy($id)
    {
        $movimiento = Movimiento::findOrFail($id);
        $movimiento->delete();

        return redirect()->route('movimientos.index')
            ->with('success', 'Movimiento eliminado exitosamente.');
    }
}
