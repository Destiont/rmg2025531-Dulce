<?php

namespace App\Http\Controllers;

use App\Models\ServicioConvenienteInmueble;
use App\Models\ServicioConveniente;
use App\Models\Inmueble;
use Illuminate\Http\Request;

class ServicioConvenienteInmuebleController extends Controller
{
// app/Http/Controllers/ServicioConvenienteInmuebleController.php

public function index(Request $request)
{
    $perPage = 10; // Number of items per page
    $currentPage = $request->input('page', 1);
    $search = $request->input('search');

    $query = ServicioConvenienteInmueble::query();

    if ($search) {
        $query->whereHas('servicioConveniente', function ($query) use ($search) {
            $query->where('nombre_servicio_conveniente', 'like', '%' . $search . '%');
        });
    }

    $serviciosConvenientesInmuebles = $query->paginate($perPage);

    return view('servicios_convenientes_inmuebles.index', [
        'serviciosConvenientesInmuebles' => $serviciosConvenientesInmuebles,
        'currentPage' => $serviciosConvenientesInmuebles->currentPage(),
        'lastPage' => $serviciosConvenientesInmuebles->lastPage(),
        'search' => $search
    ]);
}



    public function create()
    {
        $serviciosConvenientes = ServicioConveniente::all();
        $inmuebles = Inmueble::all();
        return view('servicios_convenientes_inmuebles.create', compact('serviciosConvenientes', 'inmuebles'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'id_servicio_conveniente' => 'required|exists:servicios_convenientes,id_servicio_conveniente',
            'id_inmueble' => 'required|exists:inmuebles,id_inmueble',
            'especificacion_ser_con_inm' => 'required',
        ]);

        ServicioConvenienteInmueble::create($request->all());

        return redirect()->route('servicios_convenientes_inmuebles.index')
            ->with('success', 'Relación Servicio Conveniente-Inmueble creada exitosamente.');
    }

    public function show(ServicioConvenienteInmueble $servicioConvenienteInmueble)
    {
        return view('servicios_convenientes_inmuebles.show', compact('servicioConvenienteInmueble'));
    }

    public function edit(ServicioConvenienteInmueble $servicioConvenienteInmueble)
    {
        $serviciosConvenientes = ServicioConveniente::all();
        $inmuebles = Inmueble::all();
        return view('servicios_convenientes_inmuebles.edit', compact('servicioConvenienteInmueble', 'serviciosConvenientes', 'inmuebles'));
    }

    public function update(Request $request, ServicioConvenienteInmueble $servicioConvenienteInmueble)
    {
        $request->validate([
            'id_servicio_conveniente' => 'required|exists:servicios_convenientes,id_servicio_conveniente',
            'id_inmueble' => 'required|exists:inmuebles,id_inmueble',
            'especificacion_ser_con_inm' => 'required',
        ]);

        $servicioConvenienteInmueble->update($request->all());

        return redirect()->route('servicios_convenientes_inmuebles.index')
            ->with('success', 'Relación Servicio Conveniente-Inmueble actualizada exitosamente.');
    }

    public function destroy(ServicioConvenienteInmueble $servicioConvenienteInmueble)
    {
        $servicioConvenienteInmueble->delete();

        return redirect()->route('servicios_convenientes_inmuebles.index')
            ->with('success', 'Relación Servicio Conveniente-Inmueble eliminada exitosamente.');
    }
}
