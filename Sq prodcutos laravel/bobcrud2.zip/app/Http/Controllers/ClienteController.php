<?php

namespace App\Http\Controllers;

use App\Models\Cliente;
use Illuminate\Http\Request;

class ClienteController extends Controller
{
    public function index(Request $request)
    {
        $query = Cliente::query();

        if ($request->has('cedula_identidad') && !empty($request->cedula_identidad)) {
            $query->where('cedula_identidad', 'like', '%' . $request->cedula_identidad . '%');
        }

        $clientes = $query->paginate(5); // 5 elementos por página

        return view('clientes.index', [
            'clientes' => $clientes,
            'currentPage' => $clientes->currentPage(),
            'lastPage' => $clientes->lastPage()
        ]);
    }





    public function create()
    {
        return view('clientes.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'cedula_identidad' => 'required|unique:clientes,cedula_identidad|regex:/^[0-9]+$/|digits:10',
            'nombre_cliente' => 'required|string|max:255|regex:/^[a-zA-Z\s]+$/',
            'apellido_cliente' => 'required|string|max:255|regex:/^[a-zA-Z\s]+$/',
            'telefono_cliente' => 'required|string|min:5|max:8|regex:/^[0-9]+$/',
            'correo_cliente' => 'nullable|email|max:255',
        ], [
            'cedula_identidad.required' => 'La cédula de identidad es obligatoria.',
            'cedula_identidad.unique' => 'Esta cédula de identidad ya está registrada.',
            'cedula_identidad.regex' => 'La cédula de identidad solo puede contener números.',
            'cedula_identidad.digits' => 'La cédula de identidad no cumple formato',

            'nombre_cliente.required' => 'El nombre del cliente es obligatorio.',
            'nombre_cliente.string' => 'El nombre del cliente debe ser una cadena de texto.',
            'nombre_cliente.max' => 'El nombre del cliente no puede tener más de 255 caracteres.',
            'nombre_cliente.regex' => 'El nombre del cliente solo puede contener letras y espacios.',

            'apellido_cliente.required' => 'El apellido del cliente es obligatorio.',
            'apellido_cliente.string' => 'El apellido del cliente debe ser una cadena de texto.',
            'apellido_cliente.max' => 'El apellido del cliente no puede tener más de 255 caracteres.',
            'apellido_cliente.regex' => 'El apellido del cliente solo puede contener letras y espacios.',

            'telefono_cliente.required' => 'El teléfono del cliente es obligatorio.',
            'telefono_cliente.string' => 'El teléfono del cliente debe ser una cadena de texto.',
            'telefono_cliente.min' => 'El teléfono del cliente debe tener al menos 5 dígitos.',
            'telefono_cliente.max' => 'El teléfono del cliente no puede tener más de 8 dígitos.',
            'telefono_cliente.regex' => 'El teléfono del cliente solo puede contener números.',

            'correo_cliente.email' => 'El correo electrónico no tiene un formato válido.',
            'correo_cliente.max' => 'El correo electrónico no puede tener más de 255 caracteres.',
        ]);


        Cliente::create($request->all());

        return redirect()->route('clientes.index')
            ->with('success', 'Cliente creado exitosamente.');
    }

    public function show($cliente)
    {
        $cliente = Cliente::findOrFail($cliente);
        return view('clientes.show', compact('cliente'));
    }

    public function edit($cliente)
    {
        $cliente = Cliente::findOrFail($cliente);
        return view('clientes.edit', compact('cliente'));
    }

    public function update(Request $request, $cliente)
    {
        $request->validate([
            'cedula_identidad' => 'required|regex:/^[0-9]+$/|unique:clientes,cedula_identidad,' . $cliente . ',id_cliente|digits:10',
            'nombre_cliente' => 'required|string|regex:/^[a-zA-Z\s]+$/|max:255',
            'apellido_cliente' => 'required|string|regex:/^[a-zA-Z\s]+$/|max:255',
            'telefono_cliente' => 'required|string|regex:/^[0-9]+$/|min:5|max:8',
            'correo_cliente' => 'nullable|email|max:255',
        ], [
            'cedula_identidad.required' => 'La cédula de identidad es obligatoria.',
            'cedula_identidad.unique' => 'Esta cédula de identidad ya está registrada.',
            'cedula_identidad.regex' => 'La cédula de identidad solo puede contener números.',
            'cedula_identidad.digits' => 'La cédula de identidad debe tener exactamente :digits dígitos (10 en este caso).', // Agregar el mensaje personalizado para digits aquí

            'nombre_cliente.required' => 'El nombre del cliente es obligatorio.',
            'nombre_cliente.string' => 'El nombre del cliente debe ser una cadena de texto.',
            'nombre_cliente.regex' => 'El nombre del cliente solo puede contener letras y espacios.',
            'nombre_cliente.max' => 'El nombre del cliente no puede tener más de 255 caracteres.',

            'apellido_cliente.required' => 'El apellido del cliente es obligatorio.',
            'apellido_cliente.string' => 'El apellido del cliente debe ser una cadena de texto.',
            'apellido_cliente.rege  x' => 'El apellido del cliente solo puede contener letras y espacios.',
            'apellido_cliente.max' => 'El apellido del cliente no puede tener más de 255 caracteres.',

            'telefono_cliente.required' => 'El teléfono del cliente es obligatorio.',
            'telefono_cliente.string' => 'El teléfono del cliente debe ser una cadena de texto.',
            'telefono_cliente.regex' => 'El teléfono del cliente solo puede contener números.',
            'telefono_cliente.min' => 'El teléfono del cliente debe tener al menos 5 dígitos.',
            'telefono_cliente.max' => 'El teléfono del cliente no puede tener más de 8 dígitos.',

            'correo_cliente.email' => 'El correo electrónico no tiene un formato válido.',
            'correo_cliente.max' => 'El correo electrónico no puede tener más de 255 caracteres.',
        ]);

        $cliente = Cliente::findOrFail($cliente);
        $cliente->update($request->all());

        return redirect()->route('clientes.index')
            ->with('success', 'Cliente actualizado exitosamente.');
    }


    public function destroy(Request $request, $clienteId)
    {
        try {
            $cliente = Cliente::findOrFail($clienteId);
            $cliente->delete();

            return redirect()->route('clientes.index')
                ->with('success', 'Cliente eliminado exitosamente.');
        } catch (\Exception $e) {
            // Si ocurre un error, enviamos un mensaje de error al frontend
            return response()->json(['error' => 'Error al eliminar el cliente.'], 500);
        }
    }
}
