<?php

namespace App\Http\Controllers;

use App\Models\TipoInmueble;
use Illuminate\Http\Request;

class TipoInmuebleController extends Controller
{
    public function index()
    {
        $tipoInmuebles = TipoInmueble::all();
        return view('tipo_inmuebles.index', compact('tipoInmuebles'));
    }

    public function create()
    {
        return view('tipo_inmuebles.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nombre_tipo_inmueble' => 'required|string|max:50',
        ]);

        TipoInmueble::create($request->all());
        return redirect()->route('tipo_inmuebles.index')->with('success', 'Tipo de inmueble creado exitosamente.');
    }

    public function edit(TipoInmueble $tipoInmueble)
    {
        return view('tipo_inmuebles.edit', compact('tipoInmueble'));
    }
    public function show(TipoInmueble $tipoInmueble)
{
    return view('tipo_inmuebles.show', compact('tipoInmueble'));
}


    public function update(Request $request, TipoInmueble $tipoInmueble)
    {
        $request->validate([
            'nombre_tipo_inmueble' => 'required|string|max:50',
        ]);

        $tipoInmueble->update($request->all());
        return redirect()->route('tipo_inmuebles.index')->with('success', 'Tipo de inmueble actualizado exitosamente.');
    }

    public function destroy(TipoInmueble $tipoInmueble)
    {
        $tipoInmueble->delete();
        return redirect()->route('tipo_inmuebles.index')->with('success', 'Tipo de inmueble eliminado exitosamente.');
    }
}
