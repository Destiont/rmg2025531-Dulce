<?php

namespace App\Http\Controllers;

use App\Models\ServicioBasicoInmueble;
use App\Models\Inmueble;
use App\Models\ServicioBasico;
use Illuminate\Http\Request;

class ServicioBasicoInmuebleController extends Controller
{
    public function index()
{
    $serviciosBasicosInmuebles = ServicioBasicoInmueble::paginate(10);
    return view('servicios_basicos_inmuebles.index', compact('serviciosBasicosInmuebles'));
}

    public function create()
    {
        $serviciosBasicos = ServicioBasico::all();
        $inmuebles = Inmueble::all();

        return view('servicios_basicos_inmuebles.create', compact('serviciosBasicos', 'inmuebles'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'id_servicio_basico' => 'required',
            'id_inmueble' => 'required',
            'especificacion_ser_bas_inm' => 'required|string', // Asegurar que sea una cadena de texto
        ]);

        ServicioBasicoInmueble::create([
            'id_servicio_basico' => $request->id_servicio_basico,
            'id_inmueble' => $request->id_inmueble,
            'especificacion_ser_bas_inm' => $request->especificacion_ser_bas_inm,
        ]);

        return redirect()->route('servicios_basicos_inmuebles.index')
            ->with('success', 'Relación servicio básico-inmueble creada exitosamente.');
    }

    public function edit(ServicioBasicoInmueble $servicioBasicoInmueble)
    {
        $serviciosBasicos = ServicioBasico::all();
        $inmuebles = Inmueble::all();

        return view('servicios_basicos_inmuebles.edit', compact('servicioBasicoInmueble', 'serviciosBasicos', 'inmuebles'));
    }

    public function update(Request $request, ServicioBasicoInmueble $servicioBasicoInmueble)
    {
        $request->validate([
            'id_servicio_basico' => 'required',
            'id_inmueble' => 'required',
            'especificacion_ser_bas_inm' => 'required|string', // Asegurar que sea una cadena de texto
        ]);

        $servicioBasicoInmueble->update([
            'id_servicio_basico' => $request->id_servicio_basico,
            'id_inmueble' => $request->id_inmueble,
            'especificacion_ser_bas_inm' => $request->especificacion_ser_bas_inm,
        ]);

        return redirect()->route('servicios_basicos_inmuebles.index')
            ->with('success', 'Relación servicio básico-inmueble actualizada exitosamente.');
    }

    public function destroy(ServicioBasicoInmueble $servicioBasicoInmueble)
    {
        $servicioBasicoInmueble->delete();

        return redirect()->route('servicios_basicos_inmuebles.index')
            ->with('success', 'Relación servicio básico-inmueble eliminada exitosamente.');
    }
}
