<?php

namespace App\Http\Controllers;

use App\Models\Comision;
use App\Models\Empleado;
use App\Models\Inmueble;
use Illuminate\Http\Request;

class ComisionController extends Controller
{
    public function index(Request $request)
    {
        $query = Comision::query();

        if ($request->has('id_empleado') && $request->id_empleado != '') {
            $query->where('id_empleado', $request->id_empleado);
        }

        $comisiones = $query->paginate(10);
        $totalComisiones = $query->sum('precio_comi');
        $empleados = Empleado::all();

        return view('comisiones.index', [
            'comisiones' => $comisiones,
            'empleados' => $empleados,
            'totalComisiones' => $totalComisiones,
            'currentPage' => $comisiones->currentPage(),
            'lastPage' => $comisiones->lastPage(),
        ]);
    }

    public function create()
    {
        $empleados = Empleado::all();
        $inmuebles = Inmueble::all();

        return view('comisiones.create', compact('empleados', 'inmuebles'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'id_empleado' => 'required|exists:empleados,id_empleado',
            'id_inmueble' => 'required|exists:inmuebles,id_inmueble',
            'precio_comi' => 'required|integer|min:0',
        ], [
            'id_empleado.required' => 'El campo empleado es obligatorio.',
            'id_empleado.exists' => 'El empleado seleccionado no es válido.',
            'id_inmueble.required' => 'El campo inmueble es obligatorio.',
            'id_inmueble.exists' => 'El inmueble seleccionado no es válido.',
            'precio_comi.required' => 'El campo precio de la comisión es obligatorio.',
            'precio_comi.integer' => 'El precio de la comisión debe ser un número entero.',
            'precio_comi.min' => 'El precio de la comisión debe ser como mínimo :min.',
        ]);

        Comision::create($request->all());

        return redirect()->route('comisiones.index')->with('success', 'Comisión creada exitosamente.');
    }

    public function show(Comision $comision)
    {
        return view('comisiones.show', compact('comision'));
    }

    public function edit(Comision $comision)
    {
        $empleados = Empleado::all();
        $inmuebles = Inmueble::all();

        return view('comisiones.edit', compact('comision', 'empleados', 'inmuebles'));
    }

    public function update(Request $request, Comision $comision)
    {
        $request->validate([
            'id_empleado' => 'required|exists:empleados,id_empleado',
            'id_inmueble' => 'required|exists:inmuebles,id_inmueble',
            'precio_comi' => 'required|integer|min:0',
        ], [
            'id_empleado.required' => 'El campo empleado es obligatorio.',
            'id_empleado.exists' => 'El empleado seleccionado no es válido.',
            'id_inmueble.required' => 'El campo inmueble es obligatorio.',
            'id_inmueble.exists' => 'El inmueble seleccionado no es válido.',
            'precio_comi.required' => 'El campo precio de la comisión es obligatorio.',
            'precio_comi.integer' => 'El precio de la comisión debe ser un número entero.',
            'precio_comi.min' => 'El precio de la comisión debe ser como mínimo :min.',
        ]);

        $comision->update($request->all());

        return redirect()->route('comisiones.index')->with('success', 'Comisión actualizada exitosamente.');
    }

    public function destroy(Comision $comision)
    {
        $comision->delete();

        return redirect()->route('comisiones.index')->with('success', 'Comisión eliminada exitosamente.');
    }
}
