<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\InmueblesVista;
use App\Models\Inmueble;

class InmueblesVistaController extends Controller
{
    public function index()
    {
        $inmuebles = Inmueble::paginate(10); // Cambia el número 10 por el número de resultados por página que desees
        return view('tu_vista', compact('inmuebles'));
    }

    public function create()
    {
        $inmuebles = Inmueble::all();
        return view('inmuebles_vista.create', compact('inmuebles'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'id_inmueble' => 'required|exists:inmuebles,id',
            'ruta_inm_vista' => 'required|integer|min:0',
            'orden_inm_vista' => 'required|integer|min:0',
        ], [
            'ruta_inm_vista.required' => 'El campo ruta de la vista es obligatorio.',
            'ruta_inm_vista.integer' => 'La ruta de la vista debe ser un número entero.',
            'ruta_inm_vista.min' => 'La ruta de la vista no puede ser un número negativo.',
            'orden_inm_vista.required' => 'El campo orden de la vista es obligatorio.',
            'orden_inm_vista.integer' => 'El orden de la vista debe ser un número entero.',
            'orden_inm_vista.min' => 'El orden de la vista no puede ser un número negativo.',
        ]);

        InmueblesVista::create($request->all());

        return redirect()->route('inmuebles_vista.index')
            ->with('success', 'Vista de Inmueble creada exitosamente.');
    }

    public function edit(InmueblesVista $inmueblesVista)
    {
        $inmuebles = Inmueble::all();
        return view('inmuebles_vista.edit', compact('inmueblesVista', 'inmuebles'));
    }

    public function update(Request $request, InmueblesVista $inmueblesVista)
    {
        $request->validate([
            'id_inmueble' => 'required|exists:inmuebles,id',
            'ruta_inm_vista' => 'required|integer|min:0',
            'orden_inm_vista' => 'required|integer|min:0',
        ], [
            'ruta_inm_vista.required' => 'El campo ruta de la vista es obligatorio.',
            'ruta_inm_vista.integer' => 'La ruta de la vista debe ser un número entero.',
            'ruta_inm_vista.min' => 'La ruta de la vista no puede ser un número negativo.',
            'orden_inm_vista.required' => 'El campo orden de la vista es obligatorio.',
            'orden_inm_vista.integer' => 'El orden de la vista debe ser un número entero.',
            'orden_inm_vista.min' => 'El orden de la vista no puede ser un número negativo.',
        ]);

        $inmueblesVista->update($request->all());

        return redirect()->route('inmuebles_vista.index')
            ->with('success', 'Vista de Inmueble actualizada exitosamente.');
    }

    public function destroy(InmueblesVista $inmueblesVista)
    {
        $inmueblesVista->delete();

        return redirect()->route('inmuebles_vista.index')
            ->with('success', 'Vista de Inmueble eliminada exitosamente.');
    }
}
