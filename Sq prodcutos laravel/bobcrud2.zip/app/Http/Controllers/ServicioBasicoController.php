<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ServicioBasico;

class ServicioBasicoController extends Controller
{
    public function index()
    {
        $serviciosBasicos = ServicioBasico::all();
        return view('servicios_basicos.index', compact('serviciosBasicos'));
    }

    public function create()
    {
        return view('servicios_basicos.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nombre_servicio_basico' => 'required|max:50',
        ]);

        ServicioBasico::create($request->all());

        return redirect()->route('servicios_basicos.index')
            ->with('success', 'Servicio básico creado exitosamente.');
    }

    public function show(ServicioBasico $servicioBasico)
    {
        return view('servicios_basicos.show', compact('servicioBasico'));
    }

    public function edit(ServicioBasico $servicioBasico)
    {
        return view('servicios_basicos.edit', compact('servicioBasico'));
    }

    public function update(Request $request, ServicioBasico $servicioBasico)
    {
        $request->validate([
            'nombre_servicio_basico' => 'required|max:50',
        ]);

        $servicioBasico->update($request->all());

        return redirect()->route('servicios_basicos.index')
            ->with('success', 'Servicio básico actualizado exitosamente.');
    }

    public function destroy(ServicioBasico $servicioBasico)
    {
        $servicioBasico->delete();

        return redirect()->route('servicios_basicos.index')
            ->with('success', 'Servicio básico eliminado exitosamente.');
    }
}
