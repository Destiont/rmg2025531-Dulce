<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\ServicioConveniente;

class ServicioConvenienteController extends Controller
{
    public function index()
    {
        $serviciosConvenientes = ServicioConveniente::all();
        return view('servicios_convenientes.index', compact('serviciosConvenientes'));
    }

    public function create()
    {
        return view('servicios_convenientes.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nombre_servicio_conveniente' => 'required|max:50',
        ]);

        ServicioConveniente::create($request->all());

        return redirect()->route('servicios_convenientes.index')
            ->with('success', 'Servicio conveniente creado exitosamente.');
    }

    public function show(ServicioConveniente $servicioConveniente)
    {
        return view('servicios_convenientes.show', compact('servicioConveniente'));
    }

    public function edit(ServicioConveniente $servicioConveniente)
    {
        return view('servicios_convenientes.edit', compact('servicioConveniente'));
    }

    public function update(Request $request, ServicioConveniente $servicioConveniente)
    {
        $request->validate([
            'nombre_servicio_conveniente' => 'required|max:50',
        ]);

        $servicioConveniente->update($request->all());

        return redirect()->route('servicios_convenientes.index')
            ->with('success', 'Servicio conveniente actualizado exitosamente.');
    }

    public function destroy(ServicioConveniente $servicioConveniente)
    {
        $servicioConveniente->delete();

        return redirect()->route('servicios_convenientes.index')
            ->with('success', 'Servicio conveniente eliminado exitosamente.');
    }
}
