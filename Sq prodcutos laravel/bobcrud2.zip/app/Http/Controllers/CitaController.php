<?php

namespace App\Http\Controllers;

use App\Models\Cita;
use App\Models\Empleado;
use App\Models\Cliente;
use App\Models\Inmueble;
use Illuminate\Http\Request;

class CitaController extends Controller
{
    public function index(Request $request)
    {
        $query = Cita::with(['empleado', 'cliente', 'inmueble']);

        if ($request->has('id_cliente') && $request->id_cliente != '') {
            $query->where('id_cliente', 'like', '%' . $request->id_cliente . '%');
        }

        if ($request->has('fecha_cita') && $request->fecha_cita != '') {
            $query->where('fecha_cita', $request->fecha_cita);
        }

        $citas = $query->paginate(10); // Paginar resultados, 10 por página

        $clientes = Cliente::all();

        return view('citas.index', compact('citas', 'clientes'));
    }


    public function create()
    {
        $empleados = Empleado::all();
        $clientes = Cliente::all();
        $inmuebles = Inmueble::all();

        return view('citas.create', compact('empleados', 'clientes', 'inmuebles'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'id_empleado' => 'required|exists:empleados,id_empleado',
            'id_cliente' => 'required|exists:clientes,id_cliente',
            'id_inmueble' => 'required|exists:inmuebles,id_inmueble',
            'fecha_cita' => 'required|date',
            'hora_cita' => 'required|date_format:H:i',
        ]);

        Cita::create($request->all());

        return redirect()->route('citas.index')->with('success', 'Cita creada exitosamente.');
    }

    public function show(Cita $cita)
    {
        return view('citas.show', compact('cita'));
    }

    public function edit(Cita $cita)
    {
        $empleados = Empleado::all();
        $clientes = Cliente::all();
        $inmuebles = Inmueble::all();

        return view('citas.edit', compact('cita', 'empleados', 'clientes', 'inmuebles'));
    }

    public function update(Request $request, Cita $cita)
    {
        $request->validate([
            'id_empleado' => 'required|exists:empleados,id_empleado',
            'id_cliente' => 'required|exists:clientes,id_cliente',
            'id_inmueble' => 'required|exists:inmuebles,id_inmueble',
            'fecha_cita' => 'required|date',
            'hora_cita' => 'required|date_format:H:i',
        ]);

        $cita->update($request->all());

        return redirect()->route('citas.index')->with('success', 'Cita actualizada exitosamente.');
    }

    public function destroy(Cita $cita)
    {
        $cita->delete();

        return redirect()->route('citas.index')->with('success', 'Cita eliminada exitosamente.');
    }
}
