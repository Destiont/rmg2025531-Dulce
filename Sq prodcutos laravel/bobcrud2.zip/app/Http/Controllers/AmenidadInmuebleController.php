<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\AmenidadInmueble;
use App\Models\Amenidad;
use App\Models\Inmueble;


class AmenidadInmuebleController extends Controller
{public function index(Request $request)
    {
        // Obtenemos la consulta base de todas las amenidades inmueble
        $query = AmenidadInmueble::query();

        // Verificamos si se ha enviado un término de búsqueda
        if ($request->has('search')) {
            // Obtenemos el término de búsqueda del request
            $search = $request->input('search');

            // Realizamos la búsqueda por amenidad utilizando una relación
            $query->whereHas('amenidad', function ($q) use ($search) {
                $q->where('nombre_amenidad', 'LIKE', "%$search%");
            });
        }

        $amenidadesInmueble = $query->paginate(10);

    // Pasa los datos paginados a la vista
    return view('amenidades_inmueble.index', [
        'amenidadesInmueble' => $amenidadesInmueble,
        'currentPage' => $amenidadesInmueble->currentPage(),
        'lastPage' => $amenidadesInmueble->lastPage(),
    ]);
        // Retornamos la vista con las amenidades inmueble paginadas
        return view('amenidades_inmueble.index', compact('amenidadesInmueble'));
    }


    public function create()
    {
        // Obtener las amenidades y los inmuebles desde tu base de datos
        $amenidades = Amenidad::all();
        $inmuebles = Inmueble::all();

        return view('amenidades_inmueble.create', compact('amenidades', 'inmuebles'));
    }


    public function store(Request $request)
    {
        // Código para validar y almacenar los datos recibidos del formulario de creación
        AmenidadInmueble::create($request->all());

        return redirect()->route('amenidades_inmueble.index')
            ->with('success', 'Relación amenidad-inmueble creada exitosamente.');
    }

    public function show(AmenidadInmueble $amenidadInmueble)
    {
        // Código para mostrar la información de la relación amenidad-inmueble
        return view('amenidades_inmueble.show', compact('amenidadInmueble'));
    }

    public function edit(AmenidadInmueble $amenidadInmueble)
    {
        // Código para obtener y pasar datos necesarios a la vista de edición
        return view('amenidades_inmueble.edit', compact('amenidadInmueble'));
    }

    public function update(Request $request, AmenidadInmueble $amenidadInmueble)
    {
        // Código para validar y actualizar los datos recibidos del formulario de edición
        $request->validate([
            'id_amenidad' => 'required|exists:amenidades,id_amenidad',
            'id_inmueble' => 'required|exists:inmuebles,id_inmueble',
            'especificacion' => 'required|string|max:255|regex:/^[a-zA-Z\s]+$/',
        ], [
            'especificacion.required' => 'La especificación es obligatoria.',
            'especificacion.string' => 'La especificación debe ser una cadena de texto.',
            'especificacion.max' => 'La especificación no puede tener más de 255 caracteres.',
            'especificacion.regex' => 'La especificación solo puede contener letras y espacios.',
        ]);

        $amenidadInmueble->update($request->all());

        return redirect()->route('amenidades_inmueble.index')
            ->with('success', 'Relación amenidad-inmueble actualizada exitosamente.');
    }

    public function destroy(AmenidadInmueble $amenidadInmueble)
    {
        // Código para eliminar la relación amenidad-inmueble
        $amenidadInmueble->delete();

        return redirect()->route('amenidades_inmueble.index')
            ->with('success', 'Relación amenidad-inmueble eliminada exitosamente.');
    }
}
