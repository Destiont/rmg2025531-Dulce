<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Editar Usuario</h1>
        <form action="<?php echo e(route('usuarios.update', $usuario->id_usuario)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="id_rol">Rol</label>
                <select class="form-control" id="id_rol" name="id_rol">
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($rol->id_rol); ?>" <?php echo e($usuario->id_rol == $rol->id_rol ? 'selected' : ''); ?>><?php echo e($rol->nombre_rol); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="correo_usuario">Correo</label>
                <input type="email" class="form-control" id="correo_usuario" name="correo_usuario" value="<?php echo e($usuario->correo_usuario); ?>" required>
            </div>
            <div class="form-group">
                <label for="error_usuario">Error</label>
                <input type="number" class="form-control" id="error_usuario" name="error_usuario" value="<?php echo e($usuario->error_usuario); ?>" required>
            </div>
            <div class="form-group">
                <label for="id_estado">Estado</label>
                <select class="form-control" id="id_estado" name="id_estado">
                    <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($estado->id_estado); ?>" <?php echo e($usuario->id_estado == $estado->id_estado ? 'selected' : ''); ?>><?php echo e($estado->nombre_estado); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Actualizar</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\laragon\www\bob\resources\views/usuarios/edit.blade.php ENDPATH**/ ?>