<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="m-0 text-dark">Página principal de <span style="color: #fff;">Bob Inmobiliario</span></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-8">
            <!-- Publicación 1 -->
            <div class="card mb-3" style="border: 2px solid #ccc; border-radius: 20px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
                <div class="row no-gutters">
                    <div class="col-md-6">
                        <div id="carousel1" class="carousel slide" data-ride="carousel">
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img src="https://lajoya.ec/wp-content/uploads/2015/02/LJ-CONDOMINIO-2-SALA-COMEDOR-1108x960.png" class="d-block w-100 img-fluid rounded-lg border border-dark" alt="Imagen 1">
                                </div>
                                <div class="carousel-item">
                                    <img src="https://cdn.pixabay.com/photo/2017/03/19/01/43/living-room-2155376_640.jpg" class="d-block w-100 img-fluid rounded-lg border border-dark" alt="Imagen 2">
                                </div>
                                <div class="carousel-item">
                                    <img src="https://cdn.pixabay.com/photo/2018/01/26/08/15/dining-room-3108037_640.jpg" class="d-block w-100 img-fluid rounded-lg border border-dark" alt="Imagen 3">
                                </div>
                            </div>
                            <a class="carousel-control-prev" href="#carousel1" role="button" data-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="carousel-control-next" href="#carousel1" role="button" data-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card-body">
                            <h5 class="card-title"><strong style="color: #fff;">Departamento</strong></h5>
                            <p class="card-text" id="descripcion1" style="font-size: 1.2rem; color: #fff; margin-bottom: 15px;">Descripción de la publicación Se alquila un departamento en una ubicación privilegiada cerca del estadio en La Paz, Bolivia. Este departamento está situado en una zona estratégica y de alta demanda, ideal para aquellos que deseen disfrutar de la comodidad y la cercanía a importantes centros deportivos y recreativos..</p>
                            <div class="d-flex justify-content-end align-items-center mt-3">
                                <button id="verMas1" class="btn btn-primary mr-2">Ver más</button>
                                <button class="btn btn-primary like-button"><i class="far fa-thumbs-up mr-1"></i>Me gusta</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Publicación 2 -->
            <div class="card mb-3" style="border: 2px solid #ccc; border-radius: 20px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
                <div class="row no-gutters">
                    <div class="col-md-6">
                        <div id="carousel2" class="carousel slide" data-ride="carousel">
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img src="https://cdn.pixabay.com/photo/2016/11/29/03/53/house-1867187_640.jpg" class="d-block w-100 img-fluid rounded-lg border border-dark" alt="Imagen 1">
                                </div>
                                <div class="carousel-item">
                                    <img src="https://cdn.pixabay.com/photo/2017/03/22/17/39/kitchen-2165756_640.jpg" class="d-block w-100 img-fluid rounded-lg border border-dark" alt="Imagen 2">
                                </div>
                                <div class="carousel-item">
                                    <img src="https://cdn.pixabay.com/photo/2017/09/09/18/25/living-room-2732939_640.jpg" class="d-block w-100 img-fluid rounded-lg border border-dark" alt="Imagen 3">
                                </div>
                            </div>
                            <a class="carousel-control-prev" href="#carousel2" role="button" data-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="carousel-control-next" href="#carousel2" role="button" data-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card-body">
                            <h5 class="card-title"><strong style="color: #fff;">Casa</strong></h5>
                            <p class="card-text" id="descripcion2" style="font-size: 1.2rem; color: #fff; margin-bottom: 15px;">En venta una impresionante casa ubicada en el prestigioso barrio de Cota Cota, en la ciudad de La Paz, Bolivia. Esta propiedad se encuentra en una de las zonas más exclusivas y demandadas de la ciudad, ofreciendo un estilo de vida de lujo y comodidad.</p>
                            <div class="d-flex justify-content-end align-items-center mt-3">
                                <button id="verMas2" class="btn btn-primary mr-2">Ver más</button>
                                <button class="btn btn-primary like-button"><i class="far fa-thumbs-up mr-1"></i>Me gusta</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Publicación 3 -->
            <div class="card mb-3" style="border: 2px solid #ccc; border-radius: 20px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
                <div class="row no-gutters">
                    <div class="col-md-6">
                        <div id="carousel3" class="carousel slide" data-ride="carousel">
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img src="https://www.bienesonline.com/bolivia/photos/en-venta-por-motivos-de-viaje-bonito-terreno-en-cota-cota-400-metros-precio-negociable--TEV70961698073989-263.jpg" class="d-block w-100 img-fluid rounded-lg border border-dark" alt="Imagen 1">
                                </div>
                                <div class="carousel-item">
                                    <img src="https://cdn6.ultracasas.com/dyn/yastaimages/8d0e04b5f0b7780000b60acee7d0dc836cf611" class="d-block w-100 img-fluid rounded-lg border border-dark" alt="Imagen 2">
                                </div>
                                <div class="carousel-item">
                                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQBcSWnSOqPkzKLkh9Gd6JZUgmgbkXayIS7Zoot8wb8Iw&s" class="d-block w-100 img-fluid rounded-lg border border-dark" alt="Imagen 3">
                                </div>
                            </div>
                            <a class="carousel-control-prev" href="#carousel3" role="button" data-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="carousel-control-next" href="#carousel3" role="button" data-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card-body">
                            <h5 class="card-title"><strong style="color: #fff;">Terreno</strong></h5>
                            <p class="card-text" id="descripcion3" style="font-size: 1.2rem; color: #fff; margin-bottom: 15px;">Descripción de la publicación: Se ofrece a la venta un terreno estratégicamente ubicado en el prestigioso barrio de Cota Cota, en la ciudad de La Paz, Bolivia. Este terreno se encuentra en una de las zonas más exclusivas y solicitadas de la ciudad..</p>
                            <div class="d-flex justify-content-end align-items-center mt-3">
                                <button id="verMas3" class="btn btn-primary mr-2">Ver más</button>
                                <button class="btn btn-primary like-button"><i class="far fa-thumbs-up mr-1"></i>Me gusta</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        body {
            background-color: #f8f9fa;
            color: #fff; /* Cambio global de color de texto a blanco */
            font-family: 'Roboto', sans-serif; /* Cambio de la fuente tipográfica */
        }

        .card-title {
            font-size: 1.8rem;
            margin-bottom: 20px;
        }

        .card-text {
            line-height: 1.6;
        }

        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
            border-color: #0056b3;
        }

        .like-button {
            background-color: #3b5998; /* Facebook Blue */
            border-color: #3b5998;
        }

        .like-button:hover {
            background-color: #2d4373;
            border-color: #2d4373;
        }

        .like-button i {
            color: #fff;
        }

        .image-container {
            position: relative;
        }

        .like-count {
            position: absolute;
            bottom: 10px;
            right: 10px;
            color: #fff;
        }

        .card.mb-3 {
            cursor: pointer;
        }

        .collapsed {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.2s ease-out;
        }

        .expanded {
            max-height: 500px; /* Ajusta esta altura según tus necesidades */
            overflow: hidden;
            transition: max-height 0.2s ease-in;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelector('.btn-primary').addEventListener('click', function() {
                alert('Detalles: Esta sección está actualmente en construcción.');
            });

            document.querySelector('.like-button').addEventListener('click', function() {
                alert('¡Me gusta!');
            });

            // Inicializar el carrusel al cargar la página
            $('#carousel1').carousel();
            $('#carousel2').carousel();
            $('#carousel3').carousel();

            // Cambiar la imagen al hacer clic en la tarjeta
            $('.card.mb-3').on('click', function() {
                $(this).find('.carousel').carousel('next');
            });

            // Desplegar o contraer la información al hacer clic en "Ver más"
            document.getElementById('verMas1').addEventListener('click', function() {
                var descripcion = document.getElementById('descripcion1');
                descripcion.classList.toggle('expanded');
                descripcion.classList.toggle('collapsed');
            });

            document.getElementById('verMas2').addEventListener('click', function() {
                var descripcion = document.getElementById('descripcion2');
                descripcion.classList.toggle('expanded');
                descripcion.classList.toggle('collapsed');
            });

            document.getElementById('verMas3').addEventListener('click', function() {
                var descripcion = document.getElementById('descripcion3');
                descripcion.classList.toggle('expanded');
                descripcion.classList.toggle('collapsed');
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\BRYAN\Desktop\bobsextaImplementadoroles\resources\views/home.blade.php ENDPATH**/ ?>