<?php $__env->startSection('content'); ?>
    <div class="container">
        <a href="<?php echo e(route('servicios_convenientes.create')); ?>" class="btn btn-primary mb-4">Crear Servicio Conveniente</a>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $serviciosConvenientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicioConveniente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($servicioConveniente->id_servicio_conveniente); ?></td>
                        <td><?php echo e($servicioConveniente->nombre_servicio_conveniente); ?></td>
                        <td>
                            <a href="<?php echo e(route('servicios_convenientes.show', $servicioConveniente)); ?>" class="btn btn-info btn-sm">Ver</a>
                            <a href="<?php echo e(route('servicios_convenientes.edit', $servicioConveniente)); ?>" class="btn btn-primary btn-sm">Editar</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\laragon\www\bobquinta\resources\views/servicios_convenientes/index.blade.php ENDPATH**/ ?>