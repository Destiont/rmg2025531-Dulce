<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear Inmueble</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">Crear Nuevo Inmueble</h1>
        <form action="<?php echo e(route('inmuebles.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="tipo_inmueble">Tipo de Inmueble</label>
                <select class="form-control" id="tipo_inmueble" name="tipo_inmueble">
                    <?php $__currentLoopData = $tiposInmueble; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tipo->id_tipo_inmueble); ?>"><?php echo e($tipo->nombre_tipo_inmueble); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="tipo_venta_inmueble">Tipo de Venta</label>
                <select class="form-control" id="tipo_venta_inmueble" name="tipo_venta_inmueble">
                    <?php $__currentLoopData = $tiposVentaInmueble; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoVenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tipoVenta->id_tipo_venta_inmueble); ?>"><?php echo e($tipoVenta->nombre_tipo_venta_inmueble); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="descripcion_inm">Descripción</label>
                <textarea class="form-control" id="descripcion_inm" name="descripcion_inm" rows="3"></textarea>
            </div>
            <div class="form-group">
                <label for="ubicacion_inm">Ubicación</label>
                <input type="text" class="form-control" id="ubicacion_inm" name="ubicacion_inm">
            </div>
            <div class="form-group">
                <label for="dimensiones_inm">Dimensiones</label>
                <input type="text" class="form-control" id="dimensiones_inm" name="dimensiones_inm">
            </div>
            <div class="form-group">
                <label for="tamano_inm">Tamaño</label>
                <input type="number" class="form-control" id="tamano_inm" name="tamano_inm">
            </div>
            <div class="form-group">
                <label for="habitacion_inm">Habitaciones</label>
                <input type="number" class="form-control" id="habitacion_inm" name="habitacion_inm">
            </div>
            <div class="form-group">
                <label for="bano_inm">Baños</label>
                <input type="number" class="form-control" id="bano_inm" name="bano_inm">
            </div>
            <div class="form-group">
                <label for="precio_inm">Precio</label>
                <input type="number" class="form-control" id="precio_inm" name="precio_inm">
            </div>
            <div class="form-group">
                <label for="id_estado">Estado</label>
                <select class="form-control" id="id_estado" name="id_estado">
                    <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($estado->id_estado); ?>"><?php echo e($estado->nombre_estado); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button type="submit" class="btn btn-success">Guardar</button>
        </form>
    </div>
</body>
</html>
<?php /**PATH C:\Users\BRYAN\Desktop\bobsextaImplementadoroles\resources\views/inmuebles/create.blade.php ENDPATH**/ ?>