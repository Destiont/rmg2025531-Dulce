<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Laravel</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/welcome.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body class="antialiased">
<header>
    <h1>Bob Inmobiliario</h1>
    <nav>
        <ul>
            <li>
                <?php if(auth()->guard()->check()): ?>
                    <a href="<?php echo e(url('/home')); ?>" class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">
                        <i class="fas fa-compass"></i> Inicio
                    </a>
                <?php else: ?>
                    <a href="<?php echo e(route('login')); ?>" class="font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">
                        <i class="fas fa-sign-in-alt"></i> Iniciar Sesión
                    </a>
                    <?php if(Route::has('register')): ?>
                        <a href="<?php echo e(route('register')); ?>" class="ml-4 font-semibold text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-white focus:outline focus:outline-2 focus:rounded-sm focus:outline-red-500">
                            <i class="fas fa-user-plus"></i> Registrarse
                        </a>
                    <?php endif; ?>
                <?php endif; ?>
            </li>
        </ul>
    </nav>
</header>
<section class="hero">
    <h2>Bienvenido a Bob Inmobiliario</h2>
    <p>Encuentra la propiedad de tus sueños con nosotros</p>
    <div class="search">
        <button><i class="fas fa-search"></i></button>
        <input type="text" placeholder="Buscar...">
    </div>
    <div class="filter-buttons">
        <button class="active">En Venta</button>
        <button>En Alquiler</button>
        <button>Anticretico</button>
    </div>
</section>
<footer>
    <p>&copy; 2024 Bob Inmobiliario</p>
</footer>
</body>
</html>
<?php /**PATH C:\Users\BRYAN\Desktop\bobsextasin roles\resources\views/welcome.blade.php ENDPATH**/ ?>