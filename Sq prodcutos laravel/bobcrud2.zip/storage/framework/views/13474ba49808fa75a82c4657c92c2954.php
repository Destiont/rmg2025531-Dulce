<?php $__env->startSection('content'); ?>
    <div class="container">
        <a href="<?php echo e(route('servicios_basicos_inmuebles.create')); ?>" class="btn btn-primary mb-4">Crear Relación Servicio Básico-Inmueble</a>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Servicio Básico</th>
                    <th>Inmueble</th>
                    <th>Especificación</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $serviciosBasicosInmuebles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicioBasicoInmueble): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($servicioBasicoInmueble->id_ser_bas_inm); ?></td>
                        <td><?php echo e($servicioBasicoInmueble->servicioBasico->nombre_servicio_basico); ?></td>
                        <td><?php echo e($servicioBasicoInmueble->inmueble->ubicacion_inm); ?></td>
                        <td><?php echo e($servicioBasicoInmueble->especificacion_ser_bas_inm); ?></td>
                        <td>
                            <a href="<?php echo e(route('servicios_basicos_inmuebles.show', $servicioBasicoInmueble)); ?>" class="btn btn-info btn-sm">Ver</a>
                            <a href="<?php echo e(route('servicios_basicos_inmuebles.edit', $servicioBasicoInmueble)); ?>" class="btn btn-primary btn-sm">Editar</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\laragon\www\bobtercera\resources\views/servicios_basicos_inmuebles/index.blade.php ENDPATH**/ ?>