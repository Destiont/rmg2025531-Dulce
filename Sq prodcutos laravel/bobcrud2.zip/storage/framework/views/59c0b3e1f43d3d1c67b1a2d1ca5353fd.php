<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Crear Relación Servicio Conveniente-Inmueble</h1>
        <form action="<?php echo e(route('servicios_convenientes_inmuebles.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="id_servicio_conveniente">Servicio Conveniente:</label>
                <select name="id_servicio_conveniente" id="id_servicio_conveniente" class="form-control">
                    <?php $__currentLoopData = $serviciosConvenientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicioConveniente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($servicioConveniente->id_servicio_conveniente); ?>"><?php echo e($servicioConveniente->nombre_servicio_conveniente); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="id_inmueble">Inmueble:</label>
                <select name="id_inmueble" id="id_inmueble" class="form-control">
                    <?php $__currentLoopData = $inmuebles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inmueble): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($inmueble->id_inmueble); ?>"><?php echo e($inmueble->nombre_inmueble); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="especificacion_ser_con_inm">Especificación:</label>
                <input type="text" class="form-control" id="especificacion_ser_con_inm" name="especificacion_ser_con_inm">
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\laragon\www\bob\resources\views/servicios_convenientes_inmuebles/create.blade.php ENDPATH**/ ?>