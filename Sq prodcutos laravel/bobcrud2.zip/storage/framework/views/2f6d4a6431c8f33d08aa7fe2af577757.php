<!-- resources/views/empleados/index.blade.php -->



<?php $__env->startSection('content'); ?>
    <div class="container" x-data="pagination(<?php echo e($empleados->currentPage()); ?>, <?php echo e($empleados->lastPage()); ?>)">
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(Session::get('success')); ?>

            </div>
        <?php endif; ?>
        <h1>Listado de Empleados</h1>

        <!-- Green Bar -->
        <div class="mb-3" style="border-top: 10px solid green;"></div>
        <div class="mb-3">
            <a href="<?php echo e(route('empleados.create')); ?>" class="btn btn-success">
                <i class="fas fa-plus"></i> Crear Empleado
            </a>
        </div>
        <form action="<?php echo e(route('empleados.index')); ?>" method="GET" class="mb-3">
            <div class="input-group">
                <input type="text" name="apellido_emp" class="form-control" placeholder="Buscar por apellido" value="<?php echo e(request()->get('apellido_emp')); ?>">
                <div class="input-group-append">
                    <button class="btn btn-primary" type="submit">
                        <i class="fas fa-search"></i> Buscar
                    </button>
                </div>
            </div>
        </form>

        <?php if($empleados->isEmpty()): ?>
            <p>No se encontraron empleados.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-bordered table-hover shadow-lg">
                    <thead class="thead-dark">
                        <tr>
                            <th>Usuario</th>
                            <th>Nombre</th>
                            <th>Apellido</th>
                            <th>Fecha Contratación</th>
                            <th>Fecha Nacimiento</th>
                            <th>Género</th>
                            <th>Dirección</th>
                            <th>Teléfono</th>
                            <th>Salario</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($empleado->usuario->email); ?></td>
                                <td><?php echo e($empleado->nombre_emp); ?></td>
                                <td><?php echo e($empleado->apellido_emp); ?></td>
                                <td><?php echo e($empleado->fecha_contratacion_emp); ?></td>
                                <td><?php echo e($empleado->fecha_nacimiento_emp); ?></td>
                                <td><?php echo e($empleado->genero->nombre_genero); ?></td>
                                <td><?php echo e($empleado->direccion_emp); ?></td>
                                <td><?php echo e($empleado->telefono_emp); ?></td>
                                <td><?php echo e($empleado->salario_emp); ?></td>
                                <td><?php echo e($empleado->estado->nombre_estado); ?></td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="<?php echo e(route('empleados.show', $empleado->id_empleado)); ?>" class="btn btn-info">
                                            <i class="fas fa-eye"></i> Ver
                                        </a>
                                        <a href="<?php echo e(route('empleados.edit', $empleado->id_empleado)); ?>" class="btn btn-warning">
                                            <i class="fas fa-edit"></i> Editar
                                        </a>
                                        <form action="<?php echo e(route('empleados.destroy', $empleado->id_empleado)); ?>" method="POST" class="d-inline" onsubmit="return confirm('¿Estás seguro de que deseas eliminar este empleado?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger">
                                                <i class="fas fa-trash-alt"></i> Eliminar
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <!-- Paginación con Alpine.js -->
            <ul class="pagination justify-content-center">
                <li class="page-item" :class="{ disabled: currentPage == 1 }">
                    <a class="page-link" href="#" aria-label="Previous" @click.prevent="changePage(currentPage - 1)">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                <?php for($i = 1; $i <= $empleados->lastPage(); $i++): ?>
                    <li class="page-item" :class="{ active: currentPage == <?php echo e($i); ?> }">
                        <a class="page-link" href="#" @click.prevent="changePage(<?php echo e($i); ?>)"><?php echo e($i); ?></a>
                    </li>
                <?php endfor; ?>
                <li class="page-item" :class="{ disabled: currentPage == <?php echo e($empleados->lastPage()); ?> }">
                    <a class="page-link" href="#" aria-label="Next" @click.prevent="changePage(currentPage + 1)">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        <?php endif; ?>
    </div>

    <!-- Importar Alpine.js -->
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>

    <script>
        function pagination(currentPage, lastPage) {
            return {
                currentPage,
                lastPage,
                changePage(page) {
                    if (page >= 1 && page <= this.lastPage) {
                        const url = new URL(window.location.href);
                        url.searchParams.set('page', page);
                        window.location.href = url.toString();
                    }
                }
            }
        }
    </script>

    <style>
        .table {
            border-radius: 10px;
            overflow: hidden;
            border: 1px solid #dee2e6;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .table-hover tbody tr:hover {
            background-color: #f1f1f1;
            transition: background-color 0.3s ease;
        }

        .btn-group .btn {
            transition: transform 0.3s ease;
        }

        .btn-group .btn:hover {
            transform: scale(1.05);
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bobcrud2\resources\views/empleados/index.blade.php ENDPATH**/ ?>