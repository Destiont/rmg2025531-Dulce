<?php $__env->startSection('title', 'Bienvenido a Bob Inmobiliario'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 class="m-0 text-dark">Bienvenido a <span style="color: #007bff;">Bob Inmobiliario</span></h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-6">
            <div class="card mb-3">
                <div class="card-body">
                    <h5 class="card-title">Encuentra tu hogar ideal</h5>
                    <p class="card-text">Explora nuestra amplia selección de propiedades en venta y alquiler. Desde departamentos modernos hasta lujosas casas y terrenos bien ubicados, tenemos algo para todos.</p>
                    <a href="<?php echo e(route('clienteprincipal')); ?>" class="btn btn-primary">Ver propiedades</a>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card mb-3">
                <div class="card-body">
                    <h5 class="card-title">Únete a nuestra comunidad</h5>
                    <p class="card-text">Regístrate para recibir actualizaciones sobre nuevas propiedades, precios, ofertas especiales y eventos exclusivos. ¡Únete a nuestra comunidad de amantes de bienes raíces!</p>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- Agrega estilos personalizados aquí si es necesario -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- Agrega scripts personalizados aquí si es necesario -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\BRYAN\Desktop\mio\bobsextaImplementadorolespartesdos\resources\views/home.blade.php ENDPATH**/ ?>