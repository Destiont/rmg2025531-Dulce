<!-- resources/views/servicios_extras_inmuebles/index.blade.php -->



<?php $__env->startSection('content'); ?>
    <div class="container" x-data="pagination(<?php echo e($currentPage); ?>, <?php echo e($lastPage); ?>)">
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(Session::get('success')); ?>

            </div>
        <?php endif; ?>
        <h1>Servicios Extra Inmuebles</h1>

        <!-- Green Bar -->
        <div class="mb-3" style="border-top: 10px solid green;"></div>

        <div class="mb-3">
            <a href="<?php echo e(route('servicios_extras_inmuebles.create')); ?>" class="btn btn-primary mb-4">
                <i class="fas fa-plus"></i> Crear Nuevo Servicio Extra Inmueble
            </a>
        </div>

        <form action="<?php echo e(route('servicios_extras_inmuebles.index')); ?>" method="GET" class="mb-3">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Buscar por Servicio Extra" value="<?php echo e(request()->get('search')); ?>">
                <div class="input-group-append">
                    <button class="btn btn-primary" type="submit">
                        <i class="fas fa-search"></i> Buscar
                    </button>
                </div>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-bordered table-hover shadow-lg">
                <thead class="thead-dark">
                    <tr>
                        <th>ID</th>
                        <th>Servicio Extra</th>
                        <th>Inmueble</th>
                        <th>Especificación</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $serviciosExtrasInmuebles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicioExtraInmueble): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($servicioExtraInmueble->id_ser_ext_inm); ?></td>
                            <td><?php echo e($servicioExtraInmueble->servicioExtra->nombre_servicio_extra); ?></td>
                            <td><?php echo e($servicioExtraInmueble->inmueble->ubicacion_inm); ?></td>
                            <td><?php echo e($servicioExtraInmueble->especificacion_ser_ext_inm); ?></td>
                            <td>
                                <div class="btn-group" role="group">
                                    <a href="<?php echo e(route('servicios_extras_inmuebles.show', $servicioExtraInmueble->id_ser_ext_inm)); ?>" class="btn btn-info btn-sm">
                                        <i class="fas fa-eye"></i> Ver
                                    </a>
                                    <a href="<?php echo e(route('servicios_extras_inmuebles.edit', $servicioExtraInmueble->id_ser_ext_inm)); ?>" class="btn btn-primary btn-sm">
                                        <i class="fas fa-edit"></i> Editar
                                    </a>
                                    <form action="<?php echo e(route('servicios_extras_inmuebles.destroy', $servicioExtraInmueble->id_ser_ext_inm)); ?>" method="POST" class="d-inline" onsubmit="return confirm('¿Estás seguro de eliminar este servicio extra inmueble?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm">
                                            <i class="fas fa-trash-alt"></i> Eliminar
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <!-- Paginación con Alpine.js -->
        <ul class="pagination justify-content-center">
            <li class="page-item" :class="{ disabled: currentPage == 1 }">
                <a class="page-link" href="#" aria-label="Previous" @click.prevent="changePage(currentPage - 1)">
                    <span aria-hidden="true">&laquo;</span>
                </a>
            </li>
            <?php for($i = 1; $i <= $lastPage; $i++): ?>
                <li class="page-item" :class="{ active: currentPage == <?php echo e($i); ?> }">
                    <a class="page-link" href="#" @click.prevent="changePage(<?php echo e($i); ?>)"><?php echo e($i); ?></a>
                </li>
            <?php endfor; ?>
            <li class="page-item" :class="{ disabled: currentPage == <?php echo e($lastPage); ?> }">
                <a class="page-link" href="#" aria-label="Next" @click.prevent="changePage(currentPage + 1)">
                    <span aria-hidden="true">&raquo;</span>
                </a>
            </li>
        </ul>
    </div>

    <!-- Importar Alpine.js -->
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>

    <script>
        function pagination(currentPage, lastPage) {
            return {
                currentPage,
                lastPage,
                changePage(page) {
                    if (page >= 1 && page <= this.lastPage) {
                        const url = new URL(window.location.href);
                        url.searchParams.set('page', page);
                        window.location.href = url.toString();
                    }
                }
            }
        }
    </script>

    <style>
        .table {
            border-radius: 10px;
            overflow: hidden;
            border: 1px solid #dee2e6;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .table-hover tbody tr:hover {
            background-color: #f1f1f1;
            transition: background-color 0.3s ease;
        }

        .btn-group .btn {
            transition: transform 0.3s ease;
        }

        .btn-group .btn:hover {
            transform: scale(1.05);
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\BRYAN\Desktop\mio\Finalsistema\bobcrud2\resources\views/servicios_extras_inmuebles/index.blade.php ENDPATH**/ ?>