<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inmuebles</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">Listado de Inmuebles</h1>
        <a href="<?php echo e(route('inmuebles.create')); ?>" class="btn btn-primary mb-3">Crear Inmueble</a>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Tipo de Inmueble</th>
                    <th>Tipo de Venta</th>
                    <th>Descripción</th>
                    <th>Ubicación</th>
                    <th>Dimensiones</th>
                    <th>Tamaño</th>
                    <th>Habitaciones</th>
                    <th>Baños</th>
                    <th>Precio</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $inmuebles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inmueble): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($inmueble->id_inmueble); ?></td>
                        <td><?php echo e($inmueble->tipoInmueble->nombre_tipo_inmueble); ?></td>
                        <td><?php echo e($inmueble->tipoVentaInmueble->nombre_tipo_venta_inmueble); ?></td>
                        <td><?php echo e($inmueble->descripcion_inm); ?></td>
                        <td><?php echo e($inmueble->ubicacion_inm); ?></td>
                        <td><?php echo e($inmueble->dimensiones_inm); ?></td>
                        <td><?php echo e($inmueble->tamano_inm); ?></td>
                        <td><?php echo e($inmueble->habitacion_inm); ?></td>
                        <td><?php echo e($inmueble->bano_inm); ?></td>
                        <td><?php echo e($inmueble->precio_inm); ?></td>
                        <td><?php echo e($inmueble->estado->nombre_estado); ?></td>
                        <td>
                            <a href="<?php echo e(route('inmuebles.edit', $inmueble->id_inmueble)); ?>" class="btn btn-warning btn-sm">Editar</a>
                            <form action="<?php echo e(route('inmuebles.destroy', $inmueble->id_inmueble)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>
</html>
<?php /**PATH C:\Users\BRYAN\Desktop\bobsextaImplementadorolespartesdos\resources\views/inmuebles/index.blade.php ENDPATH**/ ?>