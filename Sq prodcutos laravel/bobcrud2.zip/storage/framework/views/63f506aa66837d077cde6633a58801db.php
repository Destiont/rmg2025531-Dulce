<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success">
                <?php echo e(Session::get('success')); ?>

            </div>
        <?php endif; ?>
        <h1>Listado de Clientes</h1>
        <div class="mb-3">
            <a href="<?php echo e(route('clientes.create')); ?>" class="btn btn-success">Crear Cliente</a>
        </div>
        <form action="<?php echo e(route('clientes.index')); ?>" method="GET" class="mb-3">
            <div class="input-group">
                <input type="text" name="cedula_identidad" class="form-control" placeholder="Buscar por cédula de identidad" value="<?php echo e(request()->get('cedula_identidad')); ?>">
                <div class="input-group-append">
                    <button class="btn btn-primary" type="submit">Buscar</button>
                </div>
            </div>
        </form>

        <?php if($clientes->isEmpty()): ?>
            <p>No se encontraron clientes.</p>
        <?php else: ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Cédula de Identidad</th>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Teléfono</th>
                        <th>Correo</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($cliente->cedula_identidad); ?></td>
                            <td><?php echo e($cliente->nombre_cliente); ?></td>
                            <td><?php echo e($cliente->apellido_cliente); ?></td>
                            <td><?php echo e($cliente->telefono_cliente); ?></td>
                            <td><?php echo e($cliente->correo_cliente); ?></td>
                            <td>
                                <div class="btn-group" role="group">
                                    <a href="<?php echo e(route('clientes.show', $cliente->id_cliente)); ?>" class="btn btn-info">Ver</a>
                                    <a href="<?php echo e(route('clientes.edit', $cliente)); ?>" class="btn btn-warning">Editar</a>
                                    <form action="<?php echo e(route('clientes.destroy', $cliente)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Eliminar</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <?php echo e($clientes->links()); ?>

        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\BRYAN\Desktop\bobsextaImplementadoroles\resources\views/clientes/index.blade.php ENDPATH**/ ?>