<?php $__env->startSection('content'); ?>
    <div class="container">
        <a href="<?php echo e(route('tipo_venta_inmuebles.create')); ?>" class="btn btn-primary mb-4">Crear Tipo de Venta de Inmueble</a>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tipoVentaInmuebles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoVentaInmueble): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($tipoVentaInmueble->id_tipo_venta_inmueble); ?></td>
                        <td><?php echo e($tipoVentaInmueble->nombre_tipo_venta_inmueble); ?></td>
                        <td>
                            <a href="<?php echo e(route('tipo_venta_inmuebles.show', $tipoVentaInmueble)); ?>" class="btn btn-info btn-sm">Ver</a>
                            <a href="<?php echo e(route('tipo_venta_inmuebles.edit', $tipoVentaInmueble)); ?>" class="btn btn-primary btn-sm">Editar</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\laragon\www\bobquinta\resources\views/tipo_venta_inmuebles/index.blade.php ENDPATH**/ ?>