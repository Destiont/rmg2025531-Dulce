<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Crear Comentario</h1>
        <form action="<?php echo e(route('comentarios.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="id_usuario">Usuario:</label>
                <select name="id_usuario" id="id_usuario" class="form-control">
                    <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($usuario->id_usuario); ?>"><?php echo e($usuario->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="descripcion_com">Descripción:</label>
                <textarea name="descripcion_com" id="descripcion_com" class="form-control" rows="3"></textarea>
            </div>
            <div class="form-group">
                <label for="puntuacion_com">Puntuación:</label>
                <input type="number" name="puntuacion_com" id="puntuacion_com" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\laragon\www\bob\resources\views/comentarios/create.blade.php ENDPATH**/ ?>