<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Editar Cliente</h1>
        <form action="<?php echo e(route('clientes.update', $cliente->id_cliente)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="nombre_cliente">Nombre:</label>
                <input type="text" name="nombre_cliente" id="nombre_cliente" class="form-control" value="<?php echo e($cliente->nombre_cliente); ?>">
            </div>
            <div class="form-group">
                <label for="apellido_cliente">Apellido:</label>
                <input type="text" name="apellido_cliente" id="apellido_cliente" class="form-control" value="<?php echo e($cliente->apellido_cliente); ?>">
            </div>
            <div class="form-group">
                <label for="telefono_cliente">Teléfono:</label>
                <input type="text" name="telefono_cliente" id="telefono_cliente" class="form-control" value="<?php echo e($cliente->telefono_cliente); ?>">
            </div>
            <div class="form-group">
                <label for="correo_cliente">Correo:</label>
                <input type="email" name="correo_cliente" id="correo_cliente" class="form-control" value="<?php echo e($cliente->correo_cliente); ?>">
            </div>
            <button type="submit" class="btn btn-primary">Actualizar</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\laragon\www\bobtercera\resources\views/clientes/edit.blade.php ENDPATH**/ ?>