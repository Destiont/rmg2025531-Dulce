<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header bg-danger text-white">Configuración</div>

                    <div class="card-body">
                        <form action="<?php echo e(route('configuracion.actualizar')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="modo">Seleccionar modo:</label>
                                <select name="modo" id="modo" class="form-control">
                                    <option value="false" <?php echo e(!$modoOscuro ? 'selected' : ''); ?>>Modo Claro</option>
                                    <option value="true" <?php echo e($modoOscuro ? 'selected' : ''); ?>>Modo Oscuro</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary">Guardar</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\BRYAN\Desktop\mio\bobsextaImplementadorolespartesdos\resources\views/configuracion.blade.php ENDPATH**/ ?>