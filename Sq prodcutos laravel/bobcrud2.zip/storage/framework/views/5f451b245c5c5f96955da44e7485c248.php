<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Crear Relación Amenidad-Inmueble</h1>
        <form action="<?php echo e(route('amenidades_inmueble.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="id_amenidad">Amenidad:</label>
                <select name="id_amenidad" id="id_amenidad" class="form-control">
                    <?php $__currentLoopData = $amenidades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenidad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($amenidad->id_amenidad); ?>"><?php echo e($amenidad->nombre_amenidad); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="id_inmueble">Inmueble:</label>
                <select name="id_inmueble" id="id_inmueble" class="form-control">
                    <?php $__currentLoopData = $inmuebles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inmueble): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($inmueble->id_inmueble); ?>"><?php echo e($inmueble->ubicacion_inm); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="especificacion_ame_inm">Especificación:</label>
                <input type="text" class="form-control" id="especificacion_ame_inm" name="especificacion_ame_inm">
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\BRYAN\Desktop\mio\bobsextaImplementadorolespartesdos\resources\views/amenidades_inmueble/create.blade.php ENDPATH**/ ?>