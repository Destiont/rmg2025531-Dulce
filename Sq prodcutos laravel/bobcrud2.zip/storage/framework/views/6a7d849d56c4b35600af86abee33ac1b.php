<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Crear Inmueble en la Vista</h1>
        <form action="<?php echo e(route('inmuebles_vista.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="id_inmueble">Inmueble:</label>
                <select name="id_inmueble" id="id_inmueble" class="form-control">
                    <?php $__currentLoopData = $inmuebles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inmueble): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($inmueble->id); ?>"><?php echo e($inmueble->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label for="ruta_inm_vista">Ruta:</label>
                <input type="text" name="ruta_inm_vista" id="ruta_inm_vista" class="form-control">
            </div>

            <div class="form-group">
                <label for="orden_inm_vista">Orden:</label>
                <input type="text" name="orden_inm_vista" id="orden_inm_vista" class="form-control">
            </div>

            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\laragon\www\bobtercera\resources\views/inmuebles_vista/create.blade.php ENDPATH**/ ?>