<?php $__env->startSection('content'); ?>
    <div class="container">
        <a href="<?php echo e(route('amenidades_inmueble.create')); ?>" class="btn btn-primary mb-4">Crear Relación Amenidad-Inmueble</a>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Amenidad</th>
                    <th>Inmueble</th>
                    <th>Especificación</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $amenidadesInmueble; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amenidadInmueble): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($amenidadInmueble->id_ame_inm); ?></td>
                        <td><?php echo e($amenidadInmueble->amenidad->nombre_amenidad); ?></td>
                        <td><?php echo e($amenidadInmueble->inmueble->ubicacion_inm); ?></td>
                        <td><?php echo e($amenidadInmueble->especificacion_ame_inm); ?></td>
                        <td>
                            <a href="<?php echo e(route('amenidades_inmueble.show', $amenidadInmueble)); ?>" class="btn btn-info btn-sm">Ver</a>
                            <a href="<?php echo e(route('amenidades_inmueble.edit', $amenidadInmueble)); ?>" class="btn btn-primary btn-sm">Editar</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\laragon\www\bobquinta\resources\views/amenidades_inmueble/index.blade.php ENDPATH**/ ?>