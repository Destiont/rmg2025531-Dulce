<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Listado de Inmuebles en la Vista</h1>
        <div class="mb-3">
            <a href="<?php echo e(route('inmuebles_vista.create')); ?>" class="btn btn-success">Crear Inmueble en la Vista</a>
        </div>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Inmueble</th>
                    <th>Ruta</th>
                    <th>Orden</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $inmueblesVista; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inmuebleVista): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($inmuebleVista->id_inm_vista); ?></td>
                        <td><?php echo e($inmuebleVista->inmueble->nombre); ?></td>
                        <td><?php echo e($inmuebleVista->ruta_inm_vista); ?></td>
                        <td><?php echo e($inmuebleVista->orden_inm_vista); ?></td>
                        <td>
                            <a href="<?php echo e(route('inmuebles_vista.show', $inmuebleVista->id_inm_vista)); ?>" class="btn btn-info">Ver</a>
                            <a href="<?php echo e(route('inmuebles_vista.edit', $inmuebleVista->id_inm_vista)); ?>" class="btn btn-primary">Editar</a>
                            <!-- Agrega aquí más acciones según tus necesidades -->
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\laragon\www\bobtercera\resources\views/inmuebles_vista/index.blade.php ENDPATH**/ ?>