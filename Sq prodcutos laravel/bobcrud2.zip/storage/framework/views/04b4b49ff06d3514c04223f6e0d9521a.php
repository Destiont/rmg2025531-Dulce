<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Detalles del Servicio Conveniente</h1>
        <p><strong>ID:</strong> <?php echo e($servicioConveniente->id_servicio_conveniente); ?></p>
        <p><strong>Nombre:</strong> <?php echo e($servicioConveniente->nombre_servicio_conveniente); ?></p>
        <a href="<?php echo e(route('servicios_convenientes.edit', $servicioConveniente)); ?>" class="btn btn-primary">Editar</a>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\laragon\www\bobtercera\resources\views/servicios_convenientes/show.blade.php ENDPATH**/ ?>