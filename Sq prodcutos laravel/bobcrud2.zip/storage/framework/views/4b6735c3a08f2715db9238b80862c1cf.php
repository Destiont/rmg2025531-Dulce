<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Listado de Usuarios</h1>
        <a href="<?php echo e(route('usuarios.create')); ?>" class="btn btn-success mb-3">Nuevo Usuario</a>
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Rol</th>
                    <th>Correo</th>
                    <th>Error</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($usuario->id_usuario); ?></td>
                        <td><?php echo e($usuario->rol->nombre_rol); ?></td>
                        <td><?php echo e($usuario->correo_usuario); ?></td>
                        <td><?php echo e($usuario->error_usuario); ?></td>
                        <td><?php echo e($usuario->estado->nombre_estado); ?></td>
                        <td>
                            <a href="<?php echo e(route('usuarios.show', $usuario->id_usuario)); ?>" class="btn btn-primary btn-sm">Ver</a>
                            <a href="<?php echo e(route('usuarios.edit', $usuario->id_usuario)); ?>" class="btn btn-info btn-sm">Editar</a>
                            <form action="<?php echo e(route('usuarios.destroy', $usuario->id_usuario)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de querer eliminar este usuario?')">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\laragon\www\bob\resources\views/usuarios/index.blade.php ENDPATH**/ ?>