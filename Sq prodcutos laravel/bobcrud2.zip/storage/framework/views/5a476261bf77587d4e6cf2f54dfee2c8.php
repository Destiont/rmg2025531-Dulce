<?php $__env->startSection('content'); ?>
    <div class="container" x-data="{ showMessage: false }">
        <h1>Crear Cliente</h1>
        <?php if(Session::has('success')): ?>
            <div class="alert alert-success" x-show="showMessage" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform scale-90" x-transition:enter-end="opacity-100 transform scale-100" x-transition:leave="transition ease-in duration-200" x-transition:leave-start="opacity-100 transform scale-100" x-transition:leave-end="opacity-0 transform scale-90" x-cloak>
                <?php echo e(Session::get('success')); ?>

            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('clientes.store')); ?>" method="POST" x-on:submit="showMessage = true">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="cedula_identidad">Cédula de Identidad:</label>
                <input type="text" name="cedula_identidad" id="cedula_identidad" class="form-control" value="<?php echo e(old('cedula_identidad')); ?>">
                <?php $__errorArgs = ['cedula_identidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="nombre_cliente">Nombre:</label>
                <input type="text" name="nombre_cliente" id="nombre_cliente" class="form-control" value="<?php echo e(old('nombre_cliente')); ?>">
                <?php $__errorArgs = ['nombre_cliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="apellido_cliente">Apellido:</label>
                <input type="text" name="apellido_cliente" id="apellido_cliente" class="form-control" value="<?php echo e(old('apellido_cliente')); ?>">
                <?php $__errorArgs = ['apellido_cliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="telefono_cliente">Teléfono:</label>
                <input type="text" name="telefono_cliente" id="telefono_cliente" class="form-control" value="<?php echo e(old('telefono_cliente')); ?>">
                <?php $__errorArgs = ['telefono_cliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="correo_cliente">Correo:</label>
                <input type="email" name="correo_cliente" id="correo_cliente" class="form-control" value="<?php echo e(old('correo_cliente')); ?>">
                <?php $__errorArgs = ['correo_cliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>

    <!-- Alpine.js CDN -->
    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@2.x.x/dist/alpine.min.js" defer></script>

    <!-- Importar app.js desde Vite.js -->
    <script type="module" src="<?php echo e(mix('js/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\BRYAN\Desktop\mio\bobsextaImplementadorolespartesdos\resources\views/clientes/create.blade.php ENDPATH**/ ?>