<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Listado de Relaciones Servicio Conveniente-Inmueble</h1>
        <a href="<?php echo e(route('servicios_convenientes_inmuebles.create')); ?>" class="btn btn-primary mb-4">Crear Relación</a>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Servicio Conveniente</th>
                    <th>Inmueble</th>
                    <th>Especificación</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $serviciosConvenientesInmuebles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicioConvenienteInmueble): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($servicioConvenienteInmueble->id_ser_con_inm); ?></td>
                        <td><?php echo e($servicioConvenienteInmueble->servicioConveniente->nombre_servicio_conveniente); ?></td>
                        <td><?php echo e($servicioConvenienteInmueble->inmueble->nombre_inmueble); ?></td>
                        <td><?php echo e($servicioConvenienteInmueble->especificacion_ser_con_inm); ?></td>
                        <td>
                            <a href="<?php echo e(route('servicios_convenientes_inmuebles.show', $servicioConvenienteInmueble)); ?>" class="btn btn-info btn-sm">Ver</a>
                            <a href="<?php echo e(route('servicios_convenientes_inmuebles.edit', $servicioConvenienteInmueble)); ?>" class="btn btn-primary btn-sm">Editar</a>
                            <form action="<?php echo e(route('servicios_convenientes_inmuebles.destroy', $servicioConvenienteInmueble)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de eliminar esta relación?')">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\laragon\www\bob\resources\views/servicios_convenientes_inmuebles/index.blade.php ENDPATH**/ ?>