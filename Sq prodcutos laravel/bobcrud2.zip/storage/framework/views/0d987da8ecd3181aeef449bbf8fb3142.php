<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Nuevo Inmueble</h1>
        <form action="<?php echo e(route('inmuebles.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="tipo_inmueble">Tipo de Inmueble</label>
                <input type="text" name="tipo_inmueble" id="tipo_inmueble" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="tipo_venta_inmueble">Tipo de Venta</label>
                <input type="text" name="tipo_venta_inmueble" id="tipo_venta_inmueble" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="descripcion_inm">Descripción</label>
                <textarea name="descripcion_inm" id="descripcion_inm" class="form-control" rows="3" required></textarea>
            </div>

            <div class="form-group">
                <label for="ubicacion_inm">Ubicación</label>
                <input type="text" name="ubicacion_inm" id="ubicacion_inm" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="dimensiones_inm">Dimensiones</label>
                <input type="text" name="dimensiones_inm" id="dimensiones_inm" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="tamano_inm">Tamaño</label>
                <input type="number" name="tamano_inm" id="tamano_inm" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="amenidad_inm">Amenidades</label>
                <textarea name="amenidad_inm" id="amenidad_inm" class="form-control" rows="3" required></textarea>
            </div>

            <div class="form-group">
                <label for="servicio_basicos_inm">Servicios Básicos</label>
                <textarea name="servicio_basicos_inm" id="servicio_basicos_inm" class="form-control" rows="3" required></textarea>
            </div>

            <div class="form-group">
                <label for="servicio_extra_inm">Servicios Extra</label>
                <textarea name="servicio_extra_inm" id="servicio_extra_inm" class="form-control" rows="3" required></textarea>
            </div>

            <div class="form-group">
                <label for="servicio_convenientes_inm">Servicios Convenientes</label>
                <textarea name="servicio_convenientes_inm" id="servicio_convenientes_inm" class="form-control" rows="3" required></textarea>
            </div>

            <div class="form-group">
                <label for="habitacion_inm">Habitaciones</label>
                <input type="number" name="habitacion_inm" id="habitacion_inm" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="bano_inm">Baños</label>
                <input type="number" name="bano_inm" id="bano_inm" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="precio_inm">Precio</label>
                <input type="number" name="precio_inm" id="precio_inm" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="id_estado">Estado</label>
                <select name="id_estado" id="id_estado" class="form-control" required>
                    <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($estado->id_estado); ?>"><?php echo e($estado->nombre_estado); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\laragon\www\bob\resources\views/inmuebles/create.blade.php ENDPATH**/ ?>