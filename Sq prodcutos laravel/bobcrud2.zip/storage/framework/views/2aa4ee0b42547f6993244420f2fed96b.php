<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Listado de Empleados</h1>
        <div class="mb-3">
            <a href="<?php echo e(route('empleados.create')); ?>" class="btn btn-success">Crear Empleado</a>
        </div>
        <form action="<?php echo e(route('empleados.index')); ?>" method="GET" class="mb-3">
            <div class="input-group">
                <input type="text" name="telefono_emp" class="form-control" placeholder="Buscar por teléfono" value="<?php echo e(request()->get('telefono_emp')); ?>">
                <div class="input-group-append">
                    <button class="btn btn-primary" type="submit">Buscar</button>
                </div>
            </div>
        </form>

        <?php if($empleados->isEmpty()): ?>
            <p>No se encontraron empleados.</p>
        <?php else: ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Usuario</th>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Fecha Contratación</th>
                        <th>Fecha Nacimiento</th>
                        <th>Género</th>
                        <th>Dirección</th>
                        <th>Teléfono</th>
                        <th>Salario</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($empleado->usuario->correo_usuario); ?></td>
                            <td><?php echo e($empleado->nombre_emp); ?></td>
                            <td><?php echo e($empleado->apellido_emp); ?></td>
                            <td><?php echo e($empleado->fecha_contratacion_emp); ?></td>
                            <td><?php echo e($empleado->fecha_nacimiento_emp); ?></td>
                            <td><?php echo e($empleado->genero->nombre_genero); ?></td>
                            <td><?php echo e($empleado->direccion_emp); ?></td>
                            <td><?php echo e($empleado->telefono_emp); ?></td>
                            <td><?php echo e($empleado->salario_emp); ?></td>
                            <td><?php echo e($empleado->estado->nombre_estado); ?></td>
                            <td>
                                <div class="btn-group" role="group">
                                    <a href="<?php echo e(route('empleados.show', $empleado->id_empleado)); ?>" class="btn btn-info">Ver</a>
                                    <a href="<?php echo e(route('empleados.edit', $empleado)); ?>" class="btn btn-warning">Editar</a>
                                    <form action="<?php echo e(route('empleados.destroy', $empleado)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Eliminar</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\laragon\www\bobtercera\resources\views/empleados/index.blade.php ENDPATH**/ ?>