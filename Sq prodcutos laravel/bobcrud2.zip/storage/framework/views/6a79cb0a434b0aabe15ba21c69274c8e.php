<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Servicios Extra Inmuebles</h1>
        <a href="<?php echo e(route('servicios_extras_inmuebles.create')); ?>" class="btn btn-primary mb-3">Crear Nuevo Servicio Extra Inmueble</a>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Servicio Extra</th>
                    <th>Inmueble</th>
                    <th>Especificación</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $serviciosExtrasInmuebles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicioExtraInmueble): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($servicioExtraInmueble->id); ?></td>
                        <td><?php echo e($servicioExtraInmueble->servicioExtra->nombre); ?></td>
                        <td><?php echo e($servicioExtraInmueble->inmueble->nombre); ?></td>
                        <td><?php echo e($servicioExtraInmueble->especificacion); ?></td>
                        <td>
                            <a href="<?php echo e(route('servicios_extras_inmuebles.show', $servicioExtraInmueble->id)); ?>" class="btn btn-info">Ver</a>
                            <a href="<?php echo e(route('servicios_extras_inmuebles.edit', $servicioExtraInmueble->id)); ?>" class="btn btn-primary">Editar</a>
                            <!-- Agrega un formulario para eliminar si lo necesitas -->
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\laragon\www\bob\resources\views/servicios_extras_inmuebles/index.blade.php ENDPATH**/ ?>