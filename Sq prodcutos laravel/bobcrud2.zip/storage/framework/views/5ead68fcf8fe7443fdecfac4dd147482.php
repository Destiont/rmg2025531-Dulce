<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Nuevo Cliente</h1>
        <form action="<?php echo e(route('clientes.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="nombre_cliente">Nombre</label>
                <input type="text" class="form-control" id="nombre_cliente" name="nombre_cliente" required>
            </div>
            <div class="form-group">
                <label for="apellido_cliente">Apellido</label>
                <input type="text" class="form-control" id="apellido_cliente" name="apellido_cliente" required>
            </div>
            <div class="form-group">
                <label for="telefono_cliente">Teléfono</label>
                <input type="text" class="form-control" id="telefono_cliente" name="telefono_cliente" required>
            </div>
            <div class="form-group">
                <label for="correo_cliente">Correo</label>
                <input type="email" class="form-control" id="correo_cliente" name="correo_cliente">
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\laragon\www\bob\resources\views/clientes/create.blade.php ENDPATH**/ ?>