<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Editar Inmueble</h1>
        <form action="<?php echo e(route('inmuebles.update', $inmueble)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="tipo_inmueble">Tipo de Inmueble:</label>
                <select name="tipo_inmueble" id="tipo_inmueble" class="form-control">
                    <?php $__currentLoopData = $tiposInmueble; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tipo->id_tipo_inmueble); ?>" <?php echo e($inmueble->tipo_inmueble == $tipo->id_tipo_inmueble ? 'selected' : ''); ?>><?php echo e($tipo->nombre_tipo_inmueble); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="tipo_venta_inmueble">Tipo de Venta:</label>
                <select name="tipo_venta_inmueble" id="tipo_venta_inmueble" class="form-control">
                    <?php $__currentLoopData = $tiposVenta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoVenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tipoVenta->id_tipo_venta_inmueble); ?>" <?php echo e($inmueble->tipo_venta_inmueble == $tipoVenta->id_tipo_venta_inmueble ? 'selected' : ''); ?>><?php echo e($tipoVenta->nombre_tipo_venta_inmueble); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="descripcion_inm">Descripción:</label>
                <textarea name="descripcion_inm" id="descripcion_inm" class="form-control" rows="3"><?php echo e($inmueble->descripcion_inm); ?></textarea>
            </div>
            <div class="form-group">
                <label for="departamento">Departamento:</label>
                <input type="text" name="departamento" id="departamento" class="form-control" value="<?php echo e($inmueble->departamento); ?>">
            </div>
            <div class="form-group">
                <label for="ubicacion_inm">Ubicación:</label>
                <input type="text" name="ubicacion_inm" id="ubicacion_inm" class="form-control" value="<?php echo e($inmueble->ubicacion_inm); ?>">
            </div>
            <div class="form-group">
                <label for="dimensiones_inm">Dimensiones:</label>
                <input type="text" name="dimensiones_inm" id="dimensiones_inm" class="form-control" value="<?php echo e($inmueble->dimensiones_inm); ?>">
            </div>
            <div class="form-group">
                <label for="tamano_inm">Tamaño:</label>
                <input type="number" name="tamano_inm" id="tamano_inm" class="form-control" value="<?php echo e($inmueble->tamano_inm); ?>">
            </div>
            <div class="form-group">
                <label for="habitacion_inm">Habitaciones:</label>
                <input type="number" name="habitacion_inm" id="habitacion_inm" class="form-control" value="<?php echo e($inmueble->habitacion_inm); ?>">
            </div>
            <div class="form-group">
                <label for="bano_inm">Baños:</label>
                <input type="number" name="bano_inm" id="bano_inm" class="form-control" value="<?php echo e($inmueble->bano_inm); ?>">
            </div>
            <div class="form-group">
                <label for="precio_inm">Precio:</label>
                <input type="number" name="precio_inm" id="precio_inm" class="form-control" value="<?php echo e($inmueble->precio_inm); ?>">
            </div>
            <div class="form-group">
                <label for="id_estado">Estado:</label>
                <select name="id_estado" id="id_estado" class="form-control">
                    <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($estado->id_estado); ?>" <?php echo e($inmueble->id_estado == $estado->id_estado ? 'selected' : ''); ?>><?php echo e($estado->nombre_estado); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Actualizar</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\laragon\www\bobquinta\resources\views/inmuebles/edit.blade.php ENDPATH**/ ?>