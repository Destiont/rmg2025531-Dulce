<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Listado de Citas</h1>
        <a href="<?php echo e(route('citas.create')); ?>" class="btn btn-primary mb-3">Crear Cita</a>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Empleado</th>
                    <th>Cliente</th>
                    <th>Inmueble</th>
                    <th>Fecha</th>
                    <th>Hora</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($cita->id); ?></td>
                        <td><?php echo e($cita->empleado->nombre); ?></td>
                        <td><?php echo e($cita->cliente->nombre); ?></td>
                        <td><?php echo e($cita->inmueble->nombre); ?></td>
                        <td><?php echo e($cita->fecha_cita); ?></td>
                        <td><?php echo e($cita->hora_cita); ?></td>
                        <td>
                            <a href="<?php echo e(route('citas.show', $cita->id)); ?>" class="btn btn-info">Ver</a>
                            <a href="<?php echo e(route('citas.edit', $cita->id)); ?>" class="btn btn-primary">Editar</a>
                            <!-- Agrega aquí más acciones según tus necesidades -->
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\laragon\www\bobtercera\resources\views/citas/index.blade.php ENDPATH**/ ?>