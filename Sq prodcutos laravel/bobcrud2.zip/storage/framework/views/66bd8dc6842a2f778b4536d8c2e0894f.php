<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Listado de Comentarios</h1>
        <a href="<?php echo e(route('comentarios.create')); ?>" class="btn btn-primary mb-4">Crear Comentario</a>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Usuario</th>
                    <th>Descripción</th>
                    <th>Puntuación</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($comentario->id_comentario); ?></td>
                        <td><?php echo e($comentario->usuario->nombre); ?></td>
                        <td><?php echo e($comentario->descripcion_com); ?></td>
                        <td><?php echo e($comentario->puntuacion_com); ?></td>
                        <td>
                            <a href="<?php echo e(route('comentarios.show', $comentario->id_comentario)); ?>" class="btn btn-info btn-sm">Ver</a>
                            <a href="<?php echo e(route('comentarios.edit', $comentario->id_comentario)); ?>" class="btn btn-primary btn-sm">Editar</a>
                            <!-- Agrega aquí el formulario de eliminación si lo deseas -->
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\laragon\www\bob\resources\views/comentarios/index.blade.php ENDPATH**/ ?>