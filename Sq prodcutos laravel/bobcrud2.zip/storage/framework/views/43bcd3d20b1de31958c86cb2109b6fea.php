<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Nuevo Empleado</h1>
        <form action="<?php echo e(route('empleados.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="id_usuario">Usuario</label>
                <select name="id_usuario" id="id_usuario" class="form-control">
                    <?php if($usuarioSeleccionado): ?>
                        <option value="<?php echo e($usuarioSeleccionado->id); ?>"><?php echo e($usuarioSeleccionado->nombre); ?></option>
                    <?php else: ?>
                        <option value="" disabled>No hay usuarios disponibles</option>
                    <?php endif; ?>
                </select>
            </div>


            <div class="form-group">
                <label for="nombre_emp">Nombre</label>
                <input type="text" name="nombre_emp" id="nombre_emp" class="form-control">
            </div>
            <div class="form-group">
                <label for="apellido_emp">Apellido</label>
                <input type="text" name="apellido_emp" id="apellido_emp" class="form-control">
            </div>
            <div class="form-group">
                <label for="fecha_contratacion_emp">Fecha Contratación</label>
                <input type="date" name="fecha_contratacion_emp" id="fecha_contratacion_emp" class="form-control">
            </div>
            <div class="form-group">
                <label for="fecha_nacimiento_emp">Fecha Nacimiento</label>
                <input type="date" name="fecha_nacimiento_emp" id="fecha_nacimiento_emp" class="form-control">
            </div>
            <div class="form-group">
                <label for="id_genero">Género</label>
                <select name="id_genero" id="id_genero" class="form-control">
                    <?php $__currentLoopData = $generos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($genero->id_genero); ?>"><?php echo e($genero->nombre_genero); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="direccion_emp">Dirección</label>
                <input type="text" name="direccion_emp" id="direccion_emp" class="form-control">
            </div>
            <div class="form-group">
                <label for="telefono_emp">Teléfono</label>
                <input type="text" name="telefono_emp" id="telefono_emp" class="form-control">
            </div>
            <div class="form-group">
                <label for="salario_emp">Salario</label>
                <input type="text" name="salario_emp" id="salario_emp" class="form-control">
            </div>
            <div class="form-group">
                <label for="id_estado">Estado</label>
                <select name="id_estado" id="id_estado" class="form-control">
                    <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($estado->id_estado); ?>"><?php echo e($estado->nombre_estado); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\laragon\www\bob\resources\views/empleados/create.blade.php ENDPATH**/ ?>