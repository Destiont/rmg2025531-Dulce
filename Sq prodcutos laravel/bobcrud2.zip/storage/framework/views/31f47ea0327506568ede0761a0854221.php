<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Listado de Movimientos</h1>
        <a href="<?php echo e(route('movimientos.create')); ?>" class="btn btn-primary mb-3">Crear Movimiento</a>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Empleado</th>
                    <th>Inmueble</th>
                    <th>Fecha</th>
                    <th>Precio Final</th>
                    <th>Comisión</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $movimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($movimiento->id_movimiento); ?></td>
                        <td><?php echo e($movimiento->empleado->nombre); ?></td>
                        <td><?php echo e($movimiento->inmueble->nombre); ?></td>
                        <td><?php echo e($movimiento->fecha_mov); ?></td>
                        <td><?php echo e($movimiento->precio_final_mov); ?></td>
                        <td><?php echo e($movimiento->comision_mov); ?></td>
                        <td>
                            <a href="<?php echo e(route('movimientos.show', $movimiento->id_movimiento)); ?>" class="btn btn-info">Ver</a>
                            <a href="<?php echo e(route('movimientos.edit', $movimiento->id_movimiento)); ?>" class="btn btn-primary">Editar</a>
                            <!-- Agrega aquí más acciones según tus necesidades -->
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon2\laragon\www\bob\resources\views/movimientos/index.blade.php ENDPATH**/ ?>