@extends('layouts.app')

@section('content')
    <div class="container">
        <a href="{{ route('tipo_venta_inmuebles.create') }}" class="btn btn-primary mb-4">Crear Tipo de Venta de Inmueble</a>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($tipoVentaInmuebles as $tipoVentaInmueble)
                    <tr>
                        <td>{{ $tipoVentaInmueble->id_tipo_venta_inmueble }}</td>
                        <td>{{ $tipoVentaInmueble->nombre_tipo_venta_inmueble }}</td>
                        <td>
                            <a href="{{ route('tipo_venta_inmuebles.show', $tipoVentaInmueble) }}" class="btn btn-info btn-sm">Ver</a>
                            <a href="{{ route('tipo_venta_inmuebles.edit', $tipoVentaInmueble) }}" class="btn btn-primary btn-sm">Editar</a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
