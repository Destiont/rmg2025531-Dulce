@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Detalles del Tipo de Venta de Inmueble</h1>
        <p><strong>ID:</strong> {{ $tipoVentaInmueble->id_tipo_venta_inmueble }}</p>
        <p><strong>Nombre:</strong> {{ $tipoVentaInmueble->nombre_tipo_venta_inmueble }}</p>
        <a href="{{ route('tipo_venta_inmuebles.edit', $tipoVentaInmueble) }}" class="btn btn-primary">Editar</a>
    </div>
@endsection
