@extends('layouts.app')

@section('content')
    <div class="container">
        <a href="{{ route('servicios_extras.create') }}" class="btn btn-primary mb-4">Crear Servicio Extra</a>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($serviciosExtras as $servicioExtra)
                    <tr>
                        <td>{{ $servicioExtra->id_servicio_extra }}</td>
                        <td>{{ $servicioExtra->nombre_servicio_extra }}</td>
                        <td>
                            <a href="{{ route('servicios_extras.show', $servicioExtra) }}" class="btn btn-info btn-sm">Ver</a>
                            <a href="{{ route('servicios_extras.edit', $servicioExtra) }}" class="btn btn-primary btn-sm">Editar</a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
