@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Crear Servicio Extra</h1>
        <form action="{{ route('servicios_extras.store') }}" method="POST">
            @csrf
            <div class="form-group">
                <label for="nombre_servicio_extra">Nombre:</label>
                <input type="text" class="form-control" id="nombre_servicio_extra" name="nombre_servicio_extra">
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>
@endsection
