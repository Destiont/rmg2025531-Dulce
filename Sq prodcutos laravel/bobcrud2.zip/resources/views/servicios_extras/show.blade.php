@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Detalles del Servicio Extra</h1>
        <p><strong>ID:</strong> {{ $servicioExtra->id_servicio_extra }}</p>
        <p><strong>Nombre:</strong> {{ $servicioExtra->nombre_servicio_extra }}</p>
        <a href="{{ route('servicios_extras.edit', $servicioExtra) }}" class="btn btn-primary">Editar</a>
    </div>
@endsection
