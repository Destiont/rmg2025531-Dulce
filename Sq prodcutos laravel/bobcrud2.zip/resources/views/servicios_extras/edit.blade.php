@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Editar Servicio Extra</h1>
        <form action="{{ route('servicios_extras.update', $servicioExtra) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="nombre_servicio_extra">Nombre:</label>
                <input type="text" class="form-control" id="nombre_servicio_extra" name="nombre_servicio_extra" value="{{ $servicioExtra->nombre_servicio_extra }}">
            </div>
            <button type="submit" class="btn btn-primary">Actualizar</button>
        </form>
    </div>
@endsection
