@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Listado de Movimientos</h1>
        <a href="{{ route('movimientos.create') }}" class="btn btn-primary mb-3">Crear Movimiento</a>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Empleado</th>
                    <th>Inmueble</th>
                    <th>Fecha</th>
                    <th>Precio Final</th>
                    <th>Comisión</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($movimientos as $movimiento)
                    <tr>
                        <td>{{ $movimiento->id_movimiento }}</td>
                        <td>{{ $movimiento->empleado->nombre }}</td>
                        <td>{{ $movimiento->inmueble->nombre }}</td>
                        <td>{{ $movimiento->fecha_mov }}</td>
                        <td>{{ $movimiento->precio_final_mov }}</td>
                        <td>{{ $movimiento->comision_mov }}</td>
                        <td>
                            <a href="{{ route('movimientos.show', $movimiento->id_movimiento) }}" class="btn btn-info">Ver</a>
                            <a href="{{ route('movimientos.edit', $movimiento->id_movimiento) }}" class="btn btn-primary">Editar</a>
                            <!-- Agrega aquí más acciones según tus necesidades -->
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
