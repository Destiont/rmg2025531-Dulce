@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Detalles del Movimiento</h1>
        <div class="card">
            <div class="card-header">
                <h3>ID: {{ $movimiento->id }}</h3>
            </div>
            <div class="card-body">
                <p><strong>Empleado:</strong> {{ $movimiento->empleado->nombre }}</p>
                <p><strong>Inmueble:</strong> {{ $movimiento->inmueble->nombre }}</p>
                <p><strong>Fecha:</strong> {{ $movimiento->fecha_mov }}</p>
                <p><strong>Precio Final:</strong> {{ $movimiento->precio_final_mov }}</p>
                <p><strong>Comisión:</strong> {{ $movimiento->comision_mov }}</p>
            </div>
        </div>
    </div>
@endsection
