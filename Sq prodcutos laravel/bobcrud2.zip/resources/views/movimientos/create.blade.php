@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Crear Movimiento</h1>
        <form action="{{ route('movimientos.store') }}" method="POST">
            @csrf
            <div class="form-group">
                <label for="id_empleado">Empleado:</label>
                <select name="id_empleado" id="id_empleado" class="form-control">
                    @foreach ($empleados as $empleado)
                        <option value="{{ $empleado->id }}">{{ $empleado->nombre }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="id_inmueble">Inmueble:</label>
                <select name="id_inmueble" id="id_inmueble" class="form-control">
                    @foreach ($inmuebles as $inmueble)
                        <option value="{{ $inmueble->id }}">{{ $inmueble->nombre }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="fecha_mov">Fecha:</label>
                <input type="date" name="fecha_mov" id="fecha_mov" class="form-control">
            </div>
            <div class="form-group">
                <label for="precio_final_mov">Precio Final:</label>
                <input type="number" name="precio_final_mov" id="precio_final_mov" class="form-control">
            </div>
            <div class="form-group">
                <label for="comision_mov">Comisión:</label>
                <input type="number" name="comision_mov" id="comision_mov" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>
@endsection
