@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Editar Movimiento</h1>
        <form action="{{ route('movimientos.update', $movimiento->id) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="id_empleado">Empleado:</label>
                <select name="id_empleado" id="id_empleado" class="form-control">
                    @foreach ($empleados as $empleado)
                        <option value="{{ $empleado->id }}" @if($empleado->id === $movimiento->id_empleado) selected @endif>{{ $empleado->nombre }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="id_inmueble">Inmueble:</label>
                <select name="id_inmueble" id="id_inmueble" class="form-control">
                    @foreach ($inmuebles as $inmueble)
                        <option value="{{ $inmueble->id }}" @if($inmueble->id === $movimiento->id_inmueble) selected @endif>{{ $inmueble->nombre }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="fecha_mov">Fecha:</label>
                <input type="date" name="fecha_mov" id="fecha_mov" class="form-control" value="{{ $movimiento->fecha_mov }}">
            </div>
            <div class="form-group">
                <label for="precio_final_mov">Precio Final:</label>
                <input type="number" name="precio_final_mov" id="precio_final_mov" class="form-control" value="{{ $movimiento->precio_final_mov }}">
            </div>
            <div class="form-group">
                <label for="comision_mov">Comisión:</label>
                <input type="number" name="comision_mov" id="comision_mov" class="form-control" value="{{ $movimiento->comision_mov }}">
            </div>
            <button type="submit" class="btn btn-primary">Guardar Cambios</button>
        </form>
    </div>
@endsection
