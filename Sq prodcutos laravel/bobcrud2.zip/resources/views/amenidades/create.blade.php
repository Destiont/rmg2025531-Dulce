@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Crear Amenidad</h1>
        <form action="{{ route('amenidades.store') }}" method="POST">
            @csrf
            <div class="form-group">
                <label for="nombre_amenidad">Nombre de la amenidad</label>
                <input type="text" class="form-control" id="nombre_amenidad" name="nombre_amenidad" required>
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>
@endsection
