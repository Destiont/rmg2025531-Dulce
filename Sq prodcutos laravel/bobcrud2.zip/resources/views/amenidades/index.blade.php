@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Amenidades</h1>
        <a href="{{ route('amenidades.create') }}" class="btn btn-success mb-3">Crear Amenidad</a>
        @if(session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Fecha de Creación</th>
                    <th>Última Actualización</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($amenidades as $amenidad)
                    <tr>
                        <td>{{ $amenidad->id_amenidad }}</td>
                        <td>{{ $amenidad->nombre_amenidad }}</td>
                        <td>{{ $amenidad->created_at }}</td>
                        <td>{{ $amenidad->updated_at }}</td>
                        <td>
                            <a href="{{ route('amenidades.edit', $amenidad->id_amenidad) }}" class="btn btn-primary btn-sm">Editar</a>
                            <form action="{{ route('amenidades.destroy', $amenidad->id_amenidad) }}" method="POST" class="d-inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de querer eliminar esta amenidad?')">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
