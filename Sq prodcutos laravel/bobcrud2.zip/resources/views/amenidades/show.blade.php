@extends('layouts.app')

@section('content')
    <h1>Detalles de la Amenidad</h1>
    <p>ID: {{ $amenidad->id }}</p>
    <p>Nombre: {{ $amenidad->nombre }}</p>
    <a href="{{ route('amenidades.edit', $amenidad) }}" class="btn btn-warning">Editar</a>
    <form action="{{ route('amenidades.destroy', $amenidad) }}" method="POST" style="display:inline">
        @csrf
        @method('DELETE')
        <button type="submit" class="btn btn-danger">Eliminar</button>
    </form>
@endsection
