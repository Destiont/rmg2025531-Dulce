@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Editar Amenidad</h1>
        <form action="{{ route('amenidades.update', $amenidad->id_amenidad) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="nombre_amenidad">Nombre de la amenidad</label>
                <input type="text" class="form-control" id="nombre_amenidad" name="nombre_amenidad" value="{{ $amenidad->nombre_amenidad }}" required>
            </div>
            <button type="submit" class="btn btn-primary">Actualizar</button>
        </form>
    </div>
@endsection
