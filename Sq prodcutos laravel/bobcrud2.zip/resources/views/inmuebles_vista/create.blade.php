@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Crear Inmueble en la Vista</h1>
        <form action="{{ route('inmuebles_vista.store') }}" method="POST">
            @csrf

            <div class="form-group">
                <label for="id_inmueble">Inmueble:</label>
                <select name="id_inmueble" id="id_inmueble" class="form-control">
                    @foreach ($inmuebles as $inmueble)
                        <option value="{{ $inmueble->id }}">{{ $inmueble->nombre }}</option>
                    @endforeach
                </select>
            </div>

            <div class="form-group">
                <label for="ruta_inm_vista">Ruta:</label>
                <input type="text" name="ruta_inm_vista" id="ruta_inm_vista" class="form-control">
            </div>

            <div class="form-group">
                <label for="orden_inm_vista">Orden:</label>
                <input type="text" name="orden_inm_vista" id="orden_inm_vista" class="form-control">
            </div>

            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>
@endsection
