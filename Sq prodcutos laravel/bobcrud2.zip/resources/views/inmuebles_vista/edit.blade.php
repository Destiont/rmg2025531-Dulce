@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Editar Inmueble en la Vista</h1>
        <form action="{{ route('inmuebles_vista.update', $inmuebleVista->id_inm_vista) }}" method="POST">
            @csrf
            @method('PUT')

            <div class="form-group">
                <label for="id_inmueble">Inmueble:</label>
                <select name="id_inmueble" id="id_inmueble" class="form-control">
                    @foreach ($inmuebles as $inmueble)
                        <option value="{{ $inmueble->id }}" {{ $inmueble->id == $inmuebleVista->id_inmueble ? 'selected' : '' }}>{{ $inmueble->nombre }}</option>
                    @endforeach
                </select>
            </div>

            <div class="form-group">
                <label for="ruta_inm_vista">Ruta:</label>
                <input type="text" name="ruta_inm_vista" id="ruta_inm_vista" class="form-control" value="{{ $inmuebleVista->ruta_inm_vista }}">
            </div>

            <div class="form-group">
                <label for="orden_inm_vista">Orden:</label>
                <input type="text" name="orden_inm_vista" id="orden_inm_vista" class="form-control" value="{{ $inmuebleVista->orden_inm_vista }}">
            </div>

            <button type="submit" class="btn btn-primary">Guardar Cambios</button>
        </form>
    </div>
@endsection
