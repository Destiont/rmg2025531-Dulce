@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Listado de Inmuebles en la Vista</h1>
        <div class="mb-3">
            <a href="{{ route('inmuebles_vista.create') }}" class="btn btn-success">Crear Inmueble en la Vista</a>
        </div>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Inmueble</th>
                    <th>Ruta</th>
                    <th>Orden</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($inmueblesVista as $inmuebleVista)
                    <tr>
                        <td>{{ $inmuebleVista->id_inm_vista }}</td>
                        <td>{{ $inmuebleVista->inmueble->nombre }}</td>
                        <td>{{ $inmuebleVista->ruta_inm_vista }}</td>
                        <td>{{ $inmuebleVista->orden_inm_vista }}</td>
                        <td>
                            <a href="{{ route('inmuebles_vista.show', $inmuebleVista->id_inm_vista) }}" class="btn btn-info">Ver</a>
                            <a href="{{ route('inmuebles_vista.edit', $inmuebleVista->id_inm_vista) }}" class="btn btn-primary">Editar</a>
                            <!-- Agrega aquí más acciones según tus necesidades -->
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
