@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Detalles del Inmueble en la Vista</h1>
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">ID del Inmueble: {{ $inmuebleVista->id_inm_vista }}</h5>
                <p class="card-text">ID del Inmueble Real: {{ $inmuebleVista->id_inmueble }}</p>
                <p class="card-text">Ruta del Inmueble en la Vista: {{ $inmuebleVista->ruta_inm_vista }}</p>
                <p class="card-text">Orden del Inmueble en la Vista: {{ $inmuebleVista->orden_inm_vista }}</p>
                <!-- Agrega aquí más detalles específicos del inmueble en la vista según tus necesidades -->
            </div>
        </div>
    </div>
@endsection
