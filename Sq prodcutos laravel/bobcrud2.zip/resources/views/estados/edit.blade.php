@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Editar Estado</h1>
        <form action="{{ route('estados.update', $estado->id_estado) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="nombre_estado">Nombre</label>
                <input type="text" class="form-control" id="nombre_estado" name="nombre_estado" value="{{ $estado->nombre_estado }}" required>
            </div>
            <button type="submit" class="btn btn-primary">Actualizar</button>
        </form>
    </div>
@endsection
