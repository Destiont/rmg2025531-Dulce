@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Nuevo Estado</h1>
        <form action="{{ route('estados.store') }}" method="POST">
            @csrf
            <div class="form-group">
                <label for="nombre_estado">Nombre</label>
                <input type="text" class="form-control" id="nombre_estado" name="nombre_estado" required>
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>
@endsection
