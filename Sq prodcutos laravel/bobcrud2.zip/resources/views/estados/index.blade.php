@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Listado de Estados</h1>
        <a href="{{ route('estados.create') }}" class="btn btn-success mb-3">Nuevo Estado</a>
        @if(session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($estados as $estado)
                    <tr>
                        <td>{{ $estado->id_estado }}</td>
                        <td>{{ $estado->nombre_estado }}</td>
                        <td>
                            <a href="{{ route('estados.show', $estado->id_estado) }}" class="btn btn-primary btn-sm">Ver</a>
                            <a href="{{ route('estados.edit', $estado->id_estado) }}" class="btn btn-info btn-sm">Editar</a>
                            <form action="{{ route('estados.destroy', $estado->id_estado) }}" method="POST" class="d-inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de querer eliminar este estado?')">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
