@extends('adminlte::page')

@section('content')
    <div class="container">
        <h1>Detalles de la Relación Servicio Conveniente-Inmueble</h1>
        <p><strong>ID:</strong> {{ $servicioConvenienteInmueble->id_ser_con_inm }}</p>
        <p><strong>Servicio Conveniente:</strong> {{ $servicioConvenienteInmueble->servicioConveniente->nombre_servicio_conveniente }}</p>
        <p><strong>Inmueble:</strong> {{ $servicioConvenienteInmueble->inmueble->nombre_inmueble }}</p>
        <p><strong>Especificación:</strong> {{ $servicioConvenienteInmueble->especificacion_ser_con_inm }}</p>
        <a href="{{ route('servicios_convenientes_inmuebles.index') }}" class="btn btn-primary">Volver al listado</a>
    </div>
@endsection
