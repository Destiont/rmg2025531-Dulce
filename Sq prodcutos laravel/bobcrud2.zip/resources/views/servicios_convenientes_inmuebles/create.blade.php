@extends('adminlte::page')

@section('content')
    <div class="container">
        <h1>Crear Relación Servicio Conveniente-Inmueble</h1>
        <form action="{{ route('servicios_convenientes_inmuebles.store') }}" method="POST">
            @csrf
            <div class="form-group">
                <label for="id_servicio_conveniente">Servicio Conveniente:</label>
                <select name="id_servicio_conveniente" id="id_servicio_conveniente" class="form-control">
                    @foreach ($serviciosConvenientes as $servicioConveniente)
                        <option value="{{ $servicioConveniente->id_servicio_conveniente }}">{{ $servicioConveniente->nombre_servicio_conveniente }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="id_inmueble">Inmueble:</label>
                <select name="id_inmueble" id="id_inmueble" class="form-control">
                    @foreach ($inmuebles as $inmueble)
                        <option value="{{ $inmueble->id_inmueble }}">{{ $inmueble->ubicacion_inm }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="especificacion_ser_con_inm">Especificación:</label>
                <input type="text" class="form-control" id="especificacion_ser_con_inm" name="especificacion_ser_con_inm">
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>
@endsection
