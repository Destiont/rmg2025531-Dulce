@extends('adminlte::page')

@section('content')
    <div class="container">
        <h1>Detalles del Servicio Extra Inmueble</h1>
        <p>ID: {{ $servicioExtraInmueble->id }}</p>
        <p>Servicio Extra: {{ $servicioExtraInmueble->servicioExtra->nombre }}</p>
        <p>Inmueble: {{ $servicioExtraInmueble->inmueble->nombre }}</p>
        <p>Especificación: {{ $servicioExtraInmueble->especificacion }}</p>
        <a href="{{ route('servicios_extras_inmuebles.edit', $servicioExtraInmueble->id) }}" class="btn btn-primary">Editar</a>
        <!-- Agrega un enlace o formulario para eliminar si lo necesitas -->
    </div>
@endsection
