@extends('adminlte::page')

@section('content')
    <div class="container">
        <h1>Editar Servicio Extra Inmueble</h1>
        <form action="{{ route('servicios_extras_inmuebles.update', $servicioExtraInmueble->id) }}" method="POST">
            @csrf
            @method('PUT')
            <!-- Agrega aquí los campos del formulario prellenando los valores actuales -->
            <button type="submit" class="btn btn-primary">Guardar Cambios</button>
        </form>
    </div>
@endsection
