@extends('adminlte::page')

@section('content')
    <div class="container">
        <h1>Crear Servicio Extra Inmueble</h1>
        <form action="{{ route('servicios_extras_inmuebles.store') }}" method="POST">
            @csrf
            <div class="form-group">
                <label for="id_servicio_extra">Servicio Extra:</label>
                <select name="id_servicio_extra" id="id_servicio_extra" class="form-control">
                    @foreach($serviciosExtras as $servicioExtra)
                        <option value="{{ $servicioExtra->id_servicio_extra }}">{{ $servicioExtra->nombre_servicio_extra }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="id_inmueble">Inmueble:</label>
                <select name="id_inmueble" id="id_inmueble" class="form-control">
                    @foreach($inmuebles as $inmueble)
                        <option value="{{ $inmueble->id_inmueble }}">{{ $inmueble->ubicacion_inm }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="especificacion_ser_ext_inm">Especificación:</label>
                <input type="text" class="form-control" id="especificacion_ser_ext_inm" name="especificacion_ser_ext_inm">
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>
@endsection
