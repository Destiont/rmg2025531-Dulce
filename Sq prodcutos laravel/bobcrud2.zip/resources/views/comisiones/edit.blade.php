@extends('adminlte::page')
@section('content')
    <div class="container">
        <h1>Editar Comisión</h1>
        <form action="{{ route('comisiones.update', $comision->id_comision) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="id_empleado">Empleado:</label>
                <select name="id_empleado" id="id_empleado" class="form-control" required>
                    @foreach($empleados as $empleado)
                        <option value="{{ $empleado->id_empleado }}" {{ $empleado->id_empleado == $comision->id_empleado ? 'selected' : '' }}>{{ $empleado->nombre_empleado }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="id_inmueble">Inmueble:</label>
                <select name="id_inmueble" id="id_inmueble" class="form-control" required>
                    @foreach($inmuebles as $inmueble)
                        <option value="{{ $inmueble->id_inmueble }}" {{ $inmueble->id_inmueble == $comision->id_inmueble ? 'selected' : '' }}>{{ $inmueble->ubicacion_inm }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="precio_comi">Precio Comisión:</label>
                <input type="number" name="precio_comi" id="precio_comi" class="form-control
