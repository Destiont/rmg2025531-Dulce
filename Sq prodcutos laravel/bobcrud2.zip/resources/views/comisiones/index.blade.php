@extends('adminlte::page')

@section('content')
    <div class="container" x-data="pagination({{ $currentPage }}, {{ $lastPage }})">
        @if(Session::has('success'))
            <div class="alert alert-success">
                {{ Session::get('success') }}
            </div>
        @endif

        <h1>Comisiones</h1>
        <a href="{{ route('comisiones.create') }}" class="btn btn-primary mb-3">Crear Nueva Comisión</a>

        <form method="GET" action="{{ route('comisiones.index') }}" class="mb-3">
            <div class="row">
                <div class="col-md-4">
                    <select name="id_empleado" class="form-control">
                        <option value="">Seleccionar Empleado</option>
                        @foreach($empleados as $empleado)
                            <option value="{{ $empleado->id_empleado }}" {{ request()->get('id_empleado') == $empleado->id_empleado ? 'selected' : '' }}>
                                {{ $empleado->nombre_emp }}
                            </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary">Buscar</button>
                </div>
            </div>
        </form>

        <h3>Total Comisiones: ${{ $totalComisiones }}</h3>

        @if($comisiones->isEmpty())
            <p>No se encontraron comisiones.</p>
        @else
            <div class="table-responsive">
                <table class="table table-bordered table-hover shadow-lg">
                    <thead class="thead-dark">
                        <tr>
                            <th>ID</th>
                            <th>Empleado</th>
                            <th>Inmueble</th>
                            <th>Precio Comisión</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($comisiones as $comision)
                            <tr>
                                <td>{{ $comision->id_comision }}</td>
                                <td>{{ $comision->empleado->nombre_emp }}</td>
                                <td>{{ $comision->inmueble->ubicacion_inm }}</td>
                                <td>{{ $comision->precio_comi }}</td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="{{ route('comisiones.show', $comision->id_comision) }}" class="btn btn-info">
                                            <i class="fas fa-eye"></i> Ver
                                        </a>
                                        <a href="{{ route('comisiones.edit', $comision->id_comision) }}" class="btn btn-primary">
                                            <i class="fas fa-edit"></i> Editar
                                        </a>
                                        <form action="{{ route('comisiones.destroy', $comision->id_comision) }}" method="POST" style="display:inline-block;" onsubmit="return confirm('¿Estás seguro de que deseas eliminar esta comisión?');">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-danger">
                                                <i class="fas fa-trash-alt"></i> Eliminar
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <!-- Paginación con Alpine.js -->
            <ul class="pagination justify-content-center">
                <li class="page-item" :class="{ disabled: currentPage == 1 }">
                    <a class="page-link" href="#" aria-label="Previous" @click.prevent="changePage(currentPage - 1)">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                @for ($i = 1; $i <= $lastPage; $i++)
                    <li class="page-item" :class="{ active: currentPage == {{ $i }} }">
                        <a class="page-link" href="#" @click.prevent="changePage({{ $i }})">{{ $i }}</a>
                    </li>
                @endfor
                <li class="page-item" :class="{ disabled: currentPage == {{ $lastPage }} }">
                    <a class="page-link" href="#" aria-label="Next" @click.prevent="changePage(currentPage + 1)">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        @endif
    </div>

    <!-- Importar Alpine.js -->
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>

    <script>
        function pagination(currentPage, lastPage) {
            return {
                currentPage,
                lastPage,
                changePage(page) {
                    if (page >= 1 && page <= this.lastPage) {
                        const url = new URL(window.location.href);
                        url.searchParams.set('page', page);
                        window.location.href = url.toString();
                    }
                }
            }
        }
    </script>

    <style>
        .table {
            border-radius: 10px;
            overflow: hidden;
            border: 1px solid #dee2e6;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .table-hover tbody tr:hover {
            background-color: #f1f1f1;
            transition: background-color 0.3s ease;
        }

        .btn-group .btn {
            transition: transform 0.3s ease;
        }

        .btn-group .btn:hover {
            transform: scale(1.05);
        }
    </style>
@endsection
