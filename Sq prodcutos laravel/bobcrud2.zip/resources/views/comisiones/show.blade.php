@extends('adminlte::page')

@section('content')
    <div class="container">
        <h1>Detalles de la Comisión</h1>
        <div class="card">
            <div class="card-header">
                Comisión ID: {{ $comision->id_comision }}
            </div>
            <div class="card-body">
                <h5 class="card-title">Empleado: {{ $comision->empleado->nombre_empleado }}</h5>
                <p class="card-text">Inmueble: {{ $comision->inmueble->ubicacion_inm }}</p>
                <p class="card-text">Precio Comisión: {{ $comision->precio_comi }}</p>
                <a href="{{ route('comisiones.index') }}" class="btn btn-primary">Volver a la lista</a>
            </div>
        </div>
    </div>
@endsection
