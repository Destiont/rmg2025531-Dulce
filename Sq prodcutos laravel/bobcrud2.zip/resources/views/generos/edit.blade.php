@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Editar Género</h1>
        <form action="{{ route('generos.update', $genero->id_genero) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="nombre_genero">Nombre</label>
                <input type="text" class="form-control" id="nombre_genero" name="nombre_genero" value="{{ $genero->nombre_genero }}" required>
            </div>
            <button type="submit" class="btn btn-primary">Actualizar</button>
        </form>
    </div>
@endsection
    