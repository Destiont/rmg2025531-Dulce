@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Listado de Géneros</h1>
        <a href="{{ route('generos.create') }}" class="btn btn-success mb-3">Nuevo Género</a>
        @if(session('success'))
            <div class="alert alert-success">{{ session('success') }}</div>
        @endif
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($generos as $genero)
                    <tr>
                        <td>{{ $genero->id_genero }}</td>
                        <td>{{ $genero->nombre_genero }}</td>
                        <td>
                            <a href="{{ route('generos.show', $genero->id_genero) }}" class="btn btn-primary btn-sm">Ver</a>
                            <a href="{{ route('generos.edit', $genero->id_genero) }}" class="btn btn-info btn-sm">Editar</a>
                            <form action="{{ route('generos.destroy', $genero->id_genero) }}" method="POST" class="d-inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de querer eliminar este género?')">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
