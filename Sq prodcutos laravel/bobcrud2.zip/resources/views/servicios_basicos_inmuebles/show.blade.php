@extends('adminlte::page')

@section('content')
    <div class="container">
        <h1>Detalles de la Relación Servicio Básico-Inmueble</h1>
        <p><strong>ID:</strong> {{ $servicioBasicoInmueble->id_ser_bas_inm }}</p>
        <p><strong>Servicio Básico:</strong> {{ $servicioBasicoInmueble->servicioBasico->nombre_servicio_basico }}</p>
        <p><strong>Inmueble:</strong> {{ $servicioBasicoInmueble->inmueble->nombre_inmueble }}</p>
        <p><strong>Especificación:</strong> {{ $servicioBasicoInmueble->especificacion_ser_bas_inm }}</p>
        <a href="{{ route('servicios_basicos_inmuebles.index') }}" class="btn btn-primary">Volver al listado</a>
    </div>
@endsection
