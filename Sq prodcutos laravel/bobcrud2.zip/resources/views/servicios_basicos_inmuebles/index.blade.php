@extends('adminlte::page')

@section('content')
<div class="container">
    <a href="{{ route('servicios_basicos_inmuebles.create') }}" class="btn btn-primary mb-4">Crear Relación Servicio Básico-Inmueble</a>

    <!-- Buscador -->
    <form action="{{ route('servicios_basicos_inmuebles.index') }}" method="GET" class="mb-3">
        <div class="input-group">
            <input type="text" name="buscar" class="form-control" placeholder="Buscar..." value="{{ request()->get('buscar') }}">
            <div class="input-group-append">
                <button class="btn btn-primary" type="submit">
                    <i class="fas fa-search"></i> Buscar
                </button>
            </div>
        </div>
    </form>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Servicio Básico</th>
                <th>Inmueble</th>
                <th>Especificación</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($serviciosBasicosInmuebles as $servicioBasicoInmueble)
                <tr>
                    <td>{{ $servicioBasicoInmueble->id_ser_bas_inm }}</td>
                    <td>{{ $servicioBasicoInmueble->servicioBasico->nombre_servicio_basico }}</td>
                    <td>{{ $servicioBasicoInmueble->inmueble->ubicacion_inm }}</td>
                    <td>{{ $servicioBasicoInmueble->especificacion_ser_bas_inm }}</td>
                    <td>
                        <a href="{{ route('servicios_basicos_inmuebles.show', $servicioBasicoInmueble) }}" class="btn btn-info btn-sm">Ver</a>
                        <a href="{{ route('servicios_basicos_inmuebles.edit', $servicioBasicoInmueble) }}" class="btn btn-primary btn-sm">Editar</a>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <!-- Paginación -->
    <div class="d-flex justify-content-center">
        {{ $serviciosBasicosInmuebles->links() }}
    </div>
</div>
@endsection

@section('css')
<style>
    .btn-info, .btn-primary {
        background-color: #17a2b8 !important;
        border-color: #17a2b8 !important;
    }

    .btn-info:hover, .btn-primary:hover {
        background-color: #138496 !important;
        border-color: #138496 !important;
    }
</style>
@endsection
