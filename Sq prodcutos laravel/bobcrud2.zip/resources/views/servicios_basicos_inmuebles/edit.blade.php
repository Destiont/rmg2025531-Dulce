@extends('adminlte::page')

@section('content')
    <div class="container">
        <h1>Editar Relación Servicio Básico-Inmueble</h1>
        <form action="{{ route('servicios_basicos_inmuebles.update', $servicioBasicoInmueble) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="id_servicio_basico">Servicio Básico:</label>
                <select name="id_servicio_basico" id="id_servicio_basico" class="form-control">
                    @foreach ($serviciosBasicos as $servicioBasico)
                        <option value="{{ $servicioBasico->id_servicio_basico }}" {{ $servicioBasicoInmueble->id_servicio_basico == $servicioBasico->id_servicio_basico ? 'selected' : '' }}>{{ $servicioBasico->nombre_servicio_basico }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="id_inmueble">Inmueble:</label>
                <select name="id_inmueble" id="id_inmueble" class="form-control">
                    @foreach ($inmuebles as $inmueble)
                        <option value="{{ $inmueble->id_inmueble }}" {{ $servicioBasicoInmueble->id_inmueble == $inmueble->id_inmueble ? 'selected' : '' }}>{{ $inmueble->nombre_inmueble }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="especificacion_ser_bas_inm">Especificación:</label>
                <input type="text" class="form-control" id="especificacion_ser_bas_inm" name="especificacion_ser_bas_inm" value="{{ $servicioBasicoInmueble->especificacion_ser_bas_inm }}">
            </div>
            <button type="submit" class="btn btn-primary">Actualizar</button>
        </form>
    </div>
@endsection
