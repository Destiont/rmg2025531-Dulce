@extends('adminlte::page')

@section('content')
    <div class="container">
        <h1>Crear Relación Servicio Básico-Inmueble</h1>
        <form action="{{ route('servicios_basicos_inmuebles.store') }}" method="POST">
            @csrf
            <div class="form-group">
                <label for="id_servicio_basico">Servicio Básico:</label>
                <select name="id_servicio_basico" id="id_servicio_basico" class="form-control">
                    @foreach ($serviciosBasicos as $servicioBasico)
                        <option value="{{ $servicioBasico->id_servicio_basico }}">{{ $servicioBasico->nombre_servicio_basico }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="id_inmueble">Inmueble:</label>
                <select name="id_inmueble" id="id_inmueble" class="form-control">
                    @foreach ($inmuebles as $inmueble)
                        <option value="{{ $inmueble->id_inmueble }}">{{ $inmueble->ubicacion_inm }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="especificacion_ser_bas_inm">Especificación:</label>
                <input type="text" class="form-control" id="especificacion_ser_bas_inm" name="especificacion_ser_bas_inm">
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>
@endsection
