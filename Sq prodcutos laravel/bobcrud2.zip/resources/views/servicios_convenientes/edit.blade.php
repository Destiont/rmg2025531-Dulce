@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Editar Servicio Conveniente</h1>
        <form action="{{ route('servicios_convenientes.update', $servicioConveniente) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="nombre_servicio_conveniente">Nombre:</label>
                <input type="text" class="form-control" id="nombre_servicio_conveniente" name="nombre_servicio_conveniente" value="{{ $servicioConveniente->nombre_servicio_conveniente }}">
            </div>
            <button type="submit" class="btn btn-primary">Actualizar</button>
        </form>
    </div>
@endsection
