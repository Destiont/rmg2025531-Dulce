@extends('layouts.app')

@section('content')
    <div class="container">
        <a href="{{ route('servicios_convenientes.create') }}" class="btn btn-primary mb-4">Crear Servicio Conveniente</a>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($serviciosConvenientes as $servicioConveniente)
                    <tr>
                        <td>{{ $servicioConveniente->id_servicio_conveniente }}</td>
                        <td>{{ $servicioConveniente->nombre_servicio_conveniente }}</td>
                        <td>
                            <a href="{{ route('servicios_convenientes.show', $servicioConveniente) }}" class="btn btn-info btn-sm">Ver</a>
                            <a href="{{ route('servicios_convenientes.edit', $servicioConveniente) }}" class="btn btn-primary btn-sm">Editar</a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
