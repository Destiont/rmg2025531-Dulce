@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Detalles del Servicio Conveniente</h1>
        <p><strong>ID:</strong> {{ $servicioConveniente->id_servicio_conveniente }}</p>
        <p><strong>Nombre:</strong> {{ $servicioConveniente->nombre_servicio_conveniente }}</p>
        <a href="{{ route('servicios_convenientes.edit', $servicioConveniente) }}" class="btn btn-primary">Editar</a>
    </div>
@endsection
