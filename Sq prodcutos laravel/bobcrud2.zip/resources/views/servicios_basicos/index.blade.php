@extends('layouts.app')

@section('content')
    <div class="container">
        <a href="{{ route('servicios_basicos.create') }}" class="btn btn-primary mb-4">Crear Servicio Básico</a>

        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($serviciosBasicos as $servicioBasico)
                    <tr>
                        <td>{{ $servicioBasico->id_servicio_basico }}</td>
                        <td>{{ $servicioBasico->nombre_servicio_basico }}</td>
                        <td>
                            <a href="{{ route('servicios_basicos.show', $servicioBasico) }}" class="btn btn-info btn-sm">Ver</a>
                            <a href="{{ route('servicios_basicos.edit', $servicioBasico) }}" class="btn btn-primary btn-sm">Editar</a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
