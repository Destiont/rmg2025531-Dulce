@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Detalles del Servicio Básico</h1>
        <p><strong>ID:</strong> {{ $servicioBasico->id_servicio_basico }}</p>
        <p><strong>Nombre:</strong> {{ $servicioBasico->nombre_servicio_basico }}</p>
        <a href="{{ route('servicios_basicos.edit', $servicioBasico) }}" class="btn btn-primary">Editar</a>
    </div>
@endsection
