@extends('adminlte::page')

@section('content')
    <div class="container">
        <h1>Editar Empleado</h1>
        <form action="{{ route('empleados.update', $empleado) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="id_usuario">Usuario</label>
                <select name="id_usuario" id="id_usuario" class="form-control @error('id_usuario') is-invalid @enderror">
                    @foreach ($usuarios as $usuario)
                        <option value="{{ $usuario->id_usuario }}" {{ $empleado->id_usuario == $usuario->id_usuario ? 'selected' : '' }}>{{ $usuario->correo_usuario }}</option>
                    @endforeach
                </select>
                @error('id_usuario')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
            <div class="form-group">
                <label for="nombre_emp">Nombre</label>
                <input type="text" name="nombre_emp" id="nombre_emp" class="form-control @error('nombre_emp') is-invalid @enderror" value="{{ old('nombre_emp', $empleado->nombre_emp) }}">
                @error('nombre_emp')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
            <div class="form-group">
                <label for="apellido_emp">Apellido</label>
                <input type="text" name="apellido_emp" id="apellido_emp" class="form-control @error('apellido_emp') is-invalid @enderror" value="{{ old('apellido_emp', $empleado->apellido_emp) }}">
                @error('apellido_emp')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
            <div class="form-group">
                <label for="fecha_contratacion_emp">Fecha Contratación</label>
                <input type="date" name="fecha_contratacion_emp" id="fecha_contratacion_emp" class="form-control @error('fecha_contratacion_emp') is-invalid @enderror" value="{{ old('fecha_contratacion_emp', $empleado->fecha_contratacion_emp) }}">
                @error('fecha_contratacion_emp')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
            <div class="form-group">
                <label for="fecha_nacimiento_emp">Fecha Nacimiento</label>
                <input type="date" name="fecha_nacimiento_emp" id="fecha_nacimiento_emp" class="form-control @error('fecha_nacimiento_emp') is-invalid @enderror" value="{{ old('fecha_nacimiento_emp', $empleado->fecha_nacimiento_emp) }}">
                @error('fecha_nacimiento_emp')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
            <div class="form-group">
                <label for="id_genero">Género</label>
                <select name="id_genero" id="id_genero" class="form-control @error('id_genero') is-invalid @enderror">
                    @foreach ($generos as $genero)
                        <option value="{{ $genero->id_genero }}" {{ $empleado->id_genero == $genero->id_genero ? 'selected' : '' }}>{{ $genero->nombre_genero }}</option>
                    @endforeach
                </select>
                @error('id_genero')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
            <div class="form-group">
                <label for="direccion_emp">Dirección</label>
                <input type="text" name="direccion_emp" id="direccion_emp" class="form-control @error('direccion_emp') is-invalid @enderror" value="{{ old('direccion_emp', $empleado->direccion_emp) }}">
                @error('direccion_emp')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
            <div class="form-group">
                <label for="telefono_emp">Teléfono</label>
                <input type="text" name="telefono_emp" id="telefono_emp" class="form-control @error('telefono_emp') is-invalid @enderror" value="{{ old('telefono_emp', $empleado->telefono_emp) }}">
                @error('telefono_emp')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
            <div class="form-group">
                <label for="salario_emp">Salario</label>
                <input type="text" name="salario_emp" id="salario_emp" class="form-control @error('salario_emp') is-invalid @enderror" value="{{ old('salario_emp', $empleado->salario_emp) }}">
                @error('salario_emp')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
            <div class="form-group">
                <label for="id_estado">Estado</label>
                <select name="id_estado" id="id_estado" class="form-control @error('id_estado') is-invalid @enderror">
                    @foreach ($estados as $estado)
                        <option value="{{ $estado->id_estado }}" {{ $empleado->id_estado == $estado->id_estado ? 'selected' : '' }}>{{ $estado->nombre_estado }}</option>
                    @endforeach
                </select>
                @error('id_estado')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>
            <button type="submit" class="btn btn-primary">Actualizar</button>
        </form>
    </div>
@endsection
