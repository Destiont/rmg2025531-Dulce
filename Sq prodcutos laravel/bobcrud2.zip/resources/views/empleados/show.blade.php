@extends('adminlte::page')

@section('content')
    <div class="container">
        <h1>Detalles del Empleado</h1>
        <p>ID: {{ $empleado->id_empleado }}</p>
        <p>Nombre: {{ $empleado->nombre_emp }}</p>
        <p>Apellido: {{ $empleado->apellido_emp }}</p>
        <p>Fecha Contratación: {{ $empleado->fecha_contratacion_emp }}</p>
        <p>Fecha Nacimiento: {{ $empleado->fecha_nacimiento_emp }}</p>
        <p>Género: {{ $empleado->genero->nombre_genero }}</p>
        <p>Dirección: {{ $empleado->direccion_emp }}</p>
        <p>Teléfono: {{ $empleado->telefono_emp }}</p>
        <p>Salario: {{ $empleado->salario_emp }}</p>
        <p>Estado: {{ $empleado->estado->nombre_estado }}</p>
        <a href="{{ route('empleados.index') }}" class="btn btn-primary">Volver al Listado</a>
    </div>
@endsection
