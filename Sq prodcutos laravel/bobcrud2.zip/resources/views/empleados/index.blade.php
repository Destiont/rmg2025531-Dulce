<!-- resources/views/empleados/index.blade.php -->

@extends('adminlte::page')

@section('content')
    <div class="container" x-data="pagination({{ $empleados->currentPage() }}, {{ $empleados->lastPage() }})">
        @if(Session::has('success'))
            <div class="alert alert-success">
                {{ Session::get('success') }}
            </div>
        @endif
        <h1>Listado de Empleados</h1>

        <!-- Green Bar -->
        <div class="mb-3" style="border-top: 10px solid green;"></div>
        <div class="mb-3">
            <a href="{{ route('empleados.create') }}" class="btn btn-success">
                <i class="fas fa-plus"></i> Crear Empleado
            </a>
        </div>
        <form action="{{ route('empleados.index') }}" method="GET" class="mb-3">
            <div class="input-group">
                <input type="text" name="apellido_emp" class="form-control" placeholder="Buscar por apellido" value="{{ request()->get('apellido_emp') }}">
                <div class="input-group-append">
                    <button class="btn btn-primary" type="submit">
                        <i class="fas fa-search"></i> Buscar
                    </button>
                </div>
            </div>
        </form>

        @if($empleados->isEmpty())
            <p>No se encontraron empleados.</p>
        @else
            <div class="table-responsive">
                <table class="table table-bordered table-hover shadow-lg">
                    <thead class="thead-dark">
                        <tr>
                            <th>Usuario</th>
                            <th>Nombre</th>
                            <th>Apellido</th>
                            <th>Fecha Contratación</th>
                            <th>Fecha Nacimiento</th>
                            <th>Género</th>
                            <th>Dirección</th>
                            <th>Teléfono</th>
                            <th>Salario</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($empleados as $empleado)
                            <tr>
                                <td>{{ $empleado->usuario->email }}</td>
                                <td>{{ $empleado->nombre_emp }}</td>
                                <td>{{ $empleado->apellido_emp }}</td>
                                <td>{{ $empleado->fecha_contratacion_emp }}</td>
                                <td>{{ $empleado->fecha_nacimiento_emp }}</td>
                                <td>{{ $empleado->genero->nombre_genero }}</td>
                                <td>{{ $empleado->direccion_emp }}</td>
                                <td>{{ $empleado->telefono_emp }}</td>
                                <td>{{ $empleado->salario_emp }}</td>
                                <td>{{ $empleado->estado->nombre_estado }}</td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="{{ route('empleados.show', $empleado->id_empleado) }}" class="btn btn-info">
                                            <i class="fas fa-eye"></i> Ver
                                        </a>
                                        <a href="{{ route('empleados.edit', $empleado->id_empleado) }}" class="btn btn-warning">
                                            <i class="fas fa-edit"></i> Editar
                                        </a>
                                        <form action="{{ route('empleados.destroy', $empleado->id_empleado) }}" method="POST" class="d-inline" onsubmit="return confirm('¿Estás seguro de que deseas eliminar este empleado?');">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-danger">
                                                <i class="fas fa-trash-alt"></i> Eliminar
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <!-- Paginación con Alpine.js -->
            <ul class="pagination justify-content-center">
                <li class="page-item" :class="{ disabled: currentPage == 1 }">
                    <a class="page-link" href="#" aria-label="Previous" @click.prevent="changePage(currentPage - 1)">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                @for ($i = 1; $i <= $empleados->lastPage(); $i++)
                    <li class="page-item" :class="{ active: currentPage == {{ $i }} }">
                        <a class="page-link" href="#" @click.prevent="changePage({{ $i }})">{{ $i }}</a>
                    </li>
                @endfor
                <li class="page-item" :class="{ disabled: currentPage == {{ $empleados->lastPage() }} }">
                    <a class="page-link" href="#" aria-label="Next" @click.prevent="changePage(currentPage + 1)">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        @endif
    </div>

    <!-- Importar Alpine.js -->
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>

    <script>
        function pagination(currentPage, lastPage) {
            return {
                currentPage,
                lastPage,
                changePage(page) {
                    if (page >= 1 && page <= this.lastPage) {
                        const url = new URL(window.location.href);
                        url.searchParams.set('page', page);
                        window.location.href = url.toString();
                    }
                }
            }
        }
    </script>

    <style>
        .table {
            border-radius: 10px;
            overflow: hidden;
            border: 1px solid #dee2e6;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .table-hover tbody tr:hover {
            background-color: #f1f1f1;
            transition: background-color 0.3s ease;
        }

        .btn-group .btn {
            transition: transform 0.3s ease;
        }

        .btn-group .btn:hover {
            transform: scale(1.05);
        }
    </style>
@endsection
