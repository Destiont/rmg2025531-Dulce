@extends('adminlte::page')

@section('content')
    <div class="container" x-data="pagination({{ $currentPage }}, {{ $lastPage }})">
        @if(Session::has('success'))
            <div class="alert alert-success">
                {{ Session::get('success') }}
            </div>
        @endif
        <h1>Amenidades Inmueble</h1>

        <!-- Green Bar -->
        <div class="mb-3" style="border-top: 10px solid green;"></div>

        <div class="mb-3">
            <a href="{{ route('amenidades_inmueble.create') }}" class="btn btn-primary mb-4">
                <i class="fas fa-plus"></i> Crear Relación Amenidad-Inmueble
            </a>
        </div>

        <form action="{{ route('amenidades_inmueble.index') }}" method="GET" class="mb-3">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Buscar por Amenidad" value="{{ request()->get('search') }}">
                <div class="input-group-append">
                    <button class="btn btn-primary" type="submit">
                        <i class="fas fa-search"></i> Buscar
                    </button>
                </div>
            </div>
        </form>

        @if($amenidadesInmueble->isEmpty())
            <p>No se encontraron amenidades inmueble.</p>
        @else
            <div class="table-responsive">
                <table class="table table-bordered table-hover shadow-lg">
                    <thead class="thead-dark">
                        <tr>
                            <th>ID</th>
                            <th>Amenidad</th>
                            <th>Inmueble</th>
                            <th>Especificación</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($amenidadesInmueble as $amenidadInmueble)
                            <tr>
                                <td>{{ $amenidadInmueble->id_ame_inm }}</td>
                                <td>{{ $amenidadInmueble->amenidad->nombre_amenidad }}</td>
                                <td>{{ $amenidadInmueble->inmueble->ubicacion_inm }}</td>
                                <td>{{ $amenidadInmueble->especificacion_ame_inm }}</td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="{{ route('amenidades_inmueble.show', $amenidadInmueble) }}" class="btn btn-info btn-sm">
                                            <i class="fas fa-eye"></i> Ver
                                        </a>
                                        <a href="{{ route('amenidades_inmueble.edit', $amenidadInmueble) }}" class="btn btn-primary btn-sm">
                                            <i class="fas fa-edit"></i> Editar
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <!-- Paginación con Alpine.js -->
            <ul class="pagination justify-content-center">
                <li class="page-item" :class="{ disabled: currentPage == 1 }">
                    <a class="page-link" href="#" aria-label="Previous" @click.prevent="changePage(currentPage - 1)">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                @for ($i = 1; $i <= $lastPage; $i++)
                    <li class="page-item" :class="{ active: currentPage == {{ $i }} }">
                        <a class="page-link" href="#" @click.prevent="changePage({{ $i }})">{{ $i }}</a>
                    </li>
                @endfor
                <li class="page-item" :class="{ disabled: currentPage == {{ $lastPage }} }">
                    <a class="page-link" href="#" aria-label="Next" @click.prevent="changePage(currentPage + 1)">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        @endif
    </div>

    <!-- Importar Alpine.js -->
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>

    <script>
        function pagination(currentPage, lastPage) {
            return {
                currentPage,
                lastPage,
                changePage(page) {
                    if (page >= 1 && page <= this.lastPage) {
                        const url = new URL(window.location.href);
                        url.searchParams.set('page', page);
                        window.location.href = url.toString();
                    }
                }
            }
        }
    </script>

    <style>
        .table {
            border-radius: 10px;
            overflow: hidden;
            border: 1px solid #dee2e6;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .table-hover tbody tr:hover {
            background-color: #f1f1f1;
            transition: background-color 0.3s ease;
        }

        .btn-group .btn {
            transition: transform 0.3s ease;
        }

        .btn-group .btn:hover {
            transform: scale(1.05);
        }
    </style>
@endsection
