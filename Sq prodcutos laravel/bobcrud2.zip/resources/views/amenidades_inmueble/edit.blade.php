@extends('adminlte::page')

@section('content')
    <div class="container">
        <h1>Editar Relación Amenidad-Inmueble</h1>
        <form action="{{ route('amenidades_inmueble.update', $amenidadInmueble) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="id_amenidad">Amenidad:</label>
                <select name="id_amenidad" id="id_amenidad" class="form-control">
                    @foreach ($amenidades as $amenidad)
                        <option value="{{ $amenidad->id_amenidad }}" {{ $amenidadInmueble->id_amenidad == $amenidad->id_amenidad ? 'selected' : '' }}>{{ $amenidad->nombre_amenidad }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="id_inmueble">Inmueble:</label>
                <select name="id_inmueble" id="id_inmueble" class="form-control">
                    @foreach ($inmuebles as $inmueble)
                        <option value="{{ $inmueble->id_inmueble }}" {{ $amenidadInmueble->id_inmueble == $inmueble->id_inmueble ? 'selected' : '' }}>{{ $inmueble->nombre_inmueble }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="especificacion_ame_inm">Especificación:</label>
                <input type="text" class="form-control" id="especificacion_ame_inm" name="especificacion_ame_inm" value="{{ $amenidadInmueble->especificacion_ame_inm }}">
            </div>
            <button type="submit" class="btn btn-primary">Actualizar</button>
        </form>
    </div>
@endsection
