@extends('adminlte::page')

@section('content')
    <div class="container">
        <h1>Crear Relación Amenidad-Inmueble</h1>
        <form action="{{ route('amenidades_inmueble.store') }}" method="POST">
            @csrf
            <div class="form-group">
                <label for="id_amenidad">Amenidad:</label>
                <select name="id_amenidad" id="id_amenidad" class="form-control">
                    @foreach ($amenidades as $amenidad)
                        <option value="{{ $amenidad->id_amenidad }}">{{ $amenidad->nombre_amenidad }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="id_inmueble">Inmueble:</label>
                <select name="id_inmueble" id="id_inmueble" class="form-control">
                    @foreach ($inmuebles as $inmueble)
                        <option value="{{ $inmueble->id_inmueble }}">{{ $inmueble->ubicacion_inm }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="especificacion_ame_inm">Especificación:</label>
                <input type="text" class="form-control" id="especificacion_ame_inm" name="especificacion_ame_inm">
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>
@endsection
