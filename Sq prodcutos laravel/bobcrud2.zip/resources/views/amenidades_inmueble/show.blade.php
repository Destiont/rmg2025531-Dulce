@extends('adminlte::page')

@section('content')
    <div class="container">
        <h1>Detalles de la Relación Amenidad-Inmueble</h1>
        <p><strong>ID:</strong> {{ $amenidadInmueble->id_ame_inm }}</p>
        <p><strong>Amenidad:</strong> {{ $amenidadInmueble->amenidad->nombre_amenidad }}</p>
        <p><strong>Inmueble:</strong> {{ $amenidadInmueble->inmueble->nombre_inmueble }}</p>
        <p><strong>Especificación:</strong> {{ $amenidadInmueble->especificacion_ame_inm }}</p>
        <a href="{{ route('amenidades_inmueble.edit', $amenidadInmueble) }}" class="btn btn-primary">Editar</a>
    </div>
@endsection
