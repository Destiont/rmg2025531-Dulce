@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Crear Comentario</h1>
        <form action="{{ route('comentarios.store') }}" method="POST">
            @csrf
            <div class="form-group">
                <label for="id_usuario">Usuario:</label>
                <select name="id_usuario" id="id_usuario" class="form-control">
                    @foreach ($usuarios as $usuario)
                        <option value="{{ $usuario->id_usuario }}">{{ $usuario->nombre }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="descripcion_com">Descripción:</label>
                <textarea name="descripcion_com" id="descripcion_com" class="form-control" rows="3"></textarea>
            </div>
            <div class="form-group">
                <label for="puntuacion_com">Puntuación:</label>
                <input type="number" name="puntuacion_com" id="puntuacion_com" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>
@endsection
