@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Listado de Comentarios</h1>
        <a href="{{ route('comentarios.create') }}" class="btn btn-primary mb-4">Crear Comentario</a>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Usuario</th>
                    <th>Descripción</th>
                    <th>Puntuación</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($comentarios as $comentario)
                    <tr>
                        <td>{{ $comentario->id_comentario }}</td>
                        <td>{{ $comentario->usuario->nombre }}</td>
                        <td>{{ $comentario->descripcion_com }}</td>
                        <td>{{ $comentario->puntuacion_com }}</td>
                        <td>
                            <a href="{{ route('comentarios.show', $comentario->id_comentario) }}" class="btn btn-info btn-sm">Ver</a>
                            <a href="{{ route('comentarios.edit', $comentario->id_comentario) }}" class="btn btn-primary btn-sm">Editar</a>
                            <!-- Agrega aquí el formulario de eliminación si lo deseas -->
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
