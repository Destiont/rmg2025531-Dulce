@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Detalles del Comentario</h1>
        <div class="card">
            <div class="card-header">
                Comentario #{{ $comentario->id_comentario }}
            </div>
            <div class="card-body">
                <p><strong>Usuario:</strong> {{ $comentario->usuario->nombre }}</p>
                <p><strong>Descripción:</strong> {{ $comentario->descripcion_com }}</p>
                <p><strong>Puntuación:</strong> {{ $comentario->puntuacion_com }}</p>
            </div>
        </div>
        <a href="{{ route('comentarios.index') }}" class="btn btn-secondary mt-3">Volver al Listado</a>
    </div>
@endsection
