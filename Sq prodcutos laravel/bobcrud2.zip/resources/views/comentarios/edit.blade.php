@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Editar Comentario</h1>
        <form action="{{ route('comentarios.update', $comentario->id_comentario) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="id_usuario">Usuario:</label>
                <select name="id_usuario" id="id_usuario" class="form-control">
                    @foreach ($usuarios as $usuario)
                        <option value="{{ $usuario->id_usuario }}" @if($comentario->id_usuario == $usuario->id_usuario) selected @endif>{{ $usuario->nombre }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="descripcion_com">Descripción:</label>
                <textarea name="descripcion_com" id="descripcion_com" class="form-control" rows="3">{{ $comentario->descripcion_com }}</textarea>
            </div>
            <div class="form-group">
                <label for="puntuacion_com">Puntuación:</label>
                <input type="number" name="puntuacion_com" id="puntuacion_com" class="form-control" value="{{ $comentario->puntuacion_com }}">
            </div>
            <button type="submit" class="btn btn-primary">Actualizar</button>
        </form>
    </div>
@endsection
