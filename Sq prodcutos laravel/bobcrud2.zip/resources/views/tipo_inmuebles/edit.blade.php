@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Editar Tipo de Inmueble</h1>
        <form action="{{ route('tipo_inmuebles.update', $tipoInmueble->id) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="nombre_tipo_inmueble">Nombre</label>
                <input type="text" name="nombre_tipo_inmueble" id="nombre_tipo_inmueble" class="form-control" value="{{ $tipoInmueble->nombre_tipo_inmueble }}">
            </div>
            <button type="submit" class="btn btn-primary">Guardar Cambios</button>
        </form>
    </div>
@endsection
