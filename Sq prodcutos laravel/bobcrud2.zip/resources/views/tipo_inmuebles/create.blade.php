@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Nuevo Tipo de Inmueble</h1>
        <form action="{{ route('tipo_inmuebles.store') }}" method="POST">
            @csrf
            <div class="form-group">
                <label for="nombre_tipo_inmueble">Nombre</label>
                <input type="text" name="nombre_tipo_inmueble" id="nombre_tipo_inmueble" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>
@endsection
