@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Lista de Tipos de Inmuebles</h1>
        <a href="{{ route('tipo_inmuebles.create') }}" class="btn btn-primary mb-4">Crear Tipo de Inmueble</a>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($tipoInmuebles as $tipoInmueble)
                    <tr>
                        <td>{{ $tipoInmueble->id_tipo_inmueble }}</td>
                        <td>{{ $tipoInmueble->nombre_tipo_inmueble }}</td>
                        <td>
                            <a href="{{ route('tipo_inmuebles.show', ['tipo_inmueble' => $tipoInmueble->id_tipo_inmueble]) }}" class="btn btn-info btn-sm">Ver</a>

                            <a href="{{ route('tipo_inmuebles.edit', $tipoInmueble->id_tipo_inmueble) }}" class="btn btn-primary btn-sm">Editar</a>
                            <form action="{{ route('tipo_inmuebles.destroy', $tipoInmueble->id_tipo_inmueble) }}" method="POST" class="d-inline">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('¿Estás seguro de eliminar este tipo de inmueble?')">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection
