@extends('layouts.app')

@section('content')
    <div class="container">
        <h1>Detalles del Tipo de Inmueble</h1>
        <table class="table">
            <tbody>
                <tr>
                    <th>ID</th>
                    <td>{{ $tipoInmueble->id }}</td>
                </tr>
                <tr>
                    <th>Nombre</th>
                    <td>{{ $tipoInmueble->nombre_tipo_inmueble }}</td>
                </tr>
            </tbody>
        </table>
        <a href="{{ route('tipo_inmuebles.index') }}" class="btn btn-primary">Volver</a>
    </div>
@endsection
