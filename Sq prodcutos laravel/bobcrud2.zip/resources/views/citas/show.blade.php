@extends('adminlte::page')

@section('content')
    <div class="container">
        <h1>Detalles de la Cita</h1>
        <div class="form-group">
            <label for="id_cita">ID:</label>
            <p>{{ $cita->id_cita }}</p>
        </div>
        <div class="form-group">
            <label for="id_empleado">Empleado:</label>
            <p>{{ $cita->empleado->nombre_empleado }}</p>
        </div>
        <div class="form-group">
            <label for="id_cliente">Cliente:</label>
            <p>{{ $cita->cliente->nombre_cliente }}</p>
        </div>
        <div class="form-group">
            <label for="id_inmueble">Inmueble:</label>
            <p>{{ $cita->inmueble->ubicacion_inm }}</p>
        </div>
        <div class="form-group">
            <label for="fecha_cita">Fecha:</label>
            <p>{{ $cita->fecha_cita }}</p>
        </div>
        <div class="form-group">
            <label for="hora_cita">Hora:</label>
            <p>{{ $cita->hora_cita }}</p>
        </div>
        <a href="{{ route('citas.index') }}" class="btn btn-primary">Volver</a>
    </div>
@endsection
