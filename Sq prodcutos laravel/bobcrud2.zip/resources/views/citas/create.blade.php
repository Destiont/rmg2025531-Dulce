@extends('adminlte::page')

@section('content')
    <div class="container">
        <h1>Crear Nueva Cita</h1>
        <form action="{{ route('citas.store') }}" method="POST">
            @csrf
            <div class="form-group">
                <label for="id_empleado">Empleado:</label>
                <select name="id_empleado" id="id_empleado" class="form-control">
                    @foreach($empleados as $empleado)
                        <option value="{{ $empleado->id_empleado }}">{{ $empleado->nombre_emp }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="id_cliente">Cliente:</label>
                <select name="id_cliente" id="id_cliente" class="form-control">
                    @foreach($clientes as $cliente)
                        <option value="{{ $cliente->id_cliente }}">{{ $cliente->nombre_cliente }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="id_inmueble">Inmueble:</label>
                <select name="id_inmueble" id="id_inmueble" class="form-control">
                    @foreach($inmuebles as $inmueble)
                        <option value="{{ $inmueble->id_inmueble }}">{{ $inmueble->ubicacion_inm }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="fecha_cita">Fecha:</label>
                <input type="date" name="fecha_cita" id="fecha_cita" class="form-control">
            </div>
            <div class="form-group">
                <label for="hora_cita">Hora:</label>
                <input type="time" name="hora_cita" id="hora_cita" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>
@endsection
