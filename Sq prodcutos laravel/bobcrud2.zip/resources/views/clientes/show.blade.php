@extends('adminlte::page')

@section('content')
    <div class="container">
        <h1>Detalle de Cliente</h1>
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">ID: {{ $cliente->id_cliente }}</h5>
                <p class="card-text">Nombre: {{ $cliente->nombre_cliente }}</p>
                <p class="card-text">Apellido: {{ $cliente->apellido_cliente }}</p>
                <p class="card-text">Teléfono: {{ $cliente->telefono_cliente }}</p>
                <p class="card-text">Correo: {{ $cliente->correo_cliente }}</p>
            </div>
        </div>
    </div>
@endsection
