@extends('adminlte::page')

@section('content')
    <div class="container">
        <h1>Editar Cliente</h1>
        <form action="{{ route('clientes.update', $cliente->id_cliente) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="form-group">
                <label for="nombre_cliente">Nombre:</label>
                <input type="text" name="nombre_cliente" id="nombre_cliente" class="form-control" value="{{ old('nombre_cliente', $cliente->nombre_cliente) }}">
                @error('nombre_cliente')
                    <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
            <div class="form-group">
                <label for="apellido_cliente">Apellido:</label>
                <input type="text" name="apellido_cliente" id="apellido_cliente" class="form-control" value="{{ old('apellido_cliente', $cliente->apellido_cliente) }}">
                @error('apellido_cliente')
                    <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
            <div class="form-group">
                <label for="telefono_cliente">Teléfono:</label>
                <input type="text" name="telefono_cliente" id="telefono_cliente" class="form-control" value="{{ old('telefono_cliente', $cliente->telefono_cliente) }}">
                @error('telefono_cliente')
                    <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
            <div class="form-group">
                <label for="correo_cliente">Correo:</label>
                <input type="email" name="correo_cliente" id="correo_cliente" class="form-control" value="{{ old('correo_cliente', $cliente->correo_cliente) }}">
                @error('correo_cliente')
                    <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
            <button type="submit" class="btn btn-primary">Actualizar</button>
        </form>
    </div>
@endsection
