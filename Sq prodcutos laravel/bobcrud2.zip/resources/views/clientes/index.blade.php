<!-- index.blade.php -->

@extends('adminlte::page')

@section('content')
    <div class="container" x-data="pagination({{ $currentPage }}, {{ $lastPage }})">
        @if(Session::has('success'))
            <div class="alert alert-success">
                {{ Session::get('success') }}
            </div>
        @endif
        <h1>Listado de Clientes</h1>

        <!-- Green Bar -->
        <div class="mb-3" style="border-top: 10px solid green;"></div>

        <div class="mb-3">
            <a href="{{ route('clientes.create') }}" class="btn btn-success">
                <i class="fas fa-plus"></i> Crear Cliente
            </a>
        </div>

        <form action="{{ route('clientes.index') }}" method="GET" class="mb-3">
            <div class="input-group">
                <input type="text" name="cedula_identidad" class="form-control" placeholder="Buscar por cédula de identidad" value="{{ request()->get('cedula_identidad') }}">
                <div class="input-group-append">
                    <button class="btn btn-primary" type="submit">
                        <i class="fas fa-search"></i> Buscar
                    </button>
                </div>
            </div>
        </form>

        @if($clientes->isEmpty())
            <p>No se encontraron clientes.</p>
        @else
            <div class="table-responsive">
                <table class="table table-bordered table-hover shadow-lg">
                    <thead class="thead-dark">
                        <tr>
                            <th>Cédula de Identidad</th>
                            <th>Nombre</th>
                            <th>Apellido</th>
                            <th>Teléfono</th>
                            <th>Correo</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($clientes as $cliente)
                            <tr>
                                <td>{{ $cliente->cedula_identidad }}</td>
                                <td>{{ $cliente->nombre_cliente }}</td>
                                <td>{{ $cliente->apellido_cliente }}</td>
                                <td>{{ $cliente->telefono_cliente }}</td>
                                <td>{{ $cliente->correo_cliente }}</td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="{{ route('clientes.show', $cliente->id_cliente) }}" class="btn btn-info">
                                            <i class="fas fa-eye"></i> Ver
                                        </a>

                                        <a href="{{ route('clientes.edit', $cliente->id_cliente) }}" class="btn btn-warning">
                                            <i class="fas fa-edit"></i> Editar
                                        </a>
                                        <form action="{{ route('clientes.destroy', $cliente->id_cliente) }}" method="POST" onsubmit="return confirm('¿Estás seguro de que deseas eliminar este cliente?');">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-danger">
                                                <i class="fas fa-trash-alt"></i> Eliminar
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <!-- Paginación con Alpine.js -->
            <ul class="pagination justify-content-center">
                <li class="page-item" :class="{ disabled: currentPage == 1 }">
                    <a class="page-link" href="#" aria-label="Previous" @click.prevent="changePage(currentPage - 1)">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                @for ($i = 1; $i <= $lastPage; $i++)
                    <li class="page-item" :class="{ active: currentPage == {{ $i }} }">
                        <a class="page-link" href="#" @click.prevent="changePage({{ $i }})">{{ $i }}</a>
                    </li>
                @endfor
                <li class="page-item" :class="{ disabled: currentPage == {{ $lastPage }} }">
                    <a class="page-link" href="#" aria-label="Next" @click.prevent="changePage(currentPage + 1)">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        @endif
    </div>

    <!-- Importar Alpine.js -->
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>

    <!-- Importar app.js desde Vite.js -->
    <script type="module" src="{{ mix('js/app.js') }}"></script>

    <!-- Importar componente de paginación -->
    <script type="module" src="{{ asset('js/componentes/clientes/clientesListado.js') }}"></script>

    <script>
        function pagination(currentPage, lastPage) {
            return {
                currentPage,
                lastPage,
                changePage(page) {
                    if (page >= 1 && page <= this.lastPage) {
                        const url = new URL(window.location.href);
                        url.searchParams.set('page', page);
                        window.location.href = url.toString();
                    }
                }
            }
        }
    </script>

    <style>
        .table {
            border-radius: 10px;
            overflow: hidden;
            border: 1px solid #dee2e6;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .table-hover tbody tr:hover {
            background-color: #f1f1f1;
            transition: background-color 0.3s ease;
        }

        .btn-group .btn {
            transition: transform 0.3s ease;
        }

        .btn-group .btn:hover {
            transform: scale(1.05);
        }
    </style>
@endsection
