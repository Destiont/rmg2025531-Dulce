@extends('adminlte::page')

@section('content')
    <div class="container" x-data="{ showMessage: false }">
        <h1>Crear Cliente</h1>
        @if(Session::has('success'))
            <div class="alert alert-success" x-show="showMessage" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 transform scale-90" x-transition:enter-end="opacity-100 transform scale-100" x-transition:leave="transition ease-in duration-200" x-transition:leave-start="opacity-100 transform scale-100" x-transition:leave-end="opacity-0 transform scale-90" x-cloak>
                {{ Session::get('success') }}
            </div>
        @endif
        <form action="{{ route('clientes.store') }}" method="POST" x-on:submit="showMessage = true">
            @csrf
            <div class="form-group">
                <label for="cedula_identidad">Cédula de Identidad:</label>
                <input type="text" name="cedula_identidad" id="cedula_identidad" class="form-control" value="{{ old('cedula_identidad') }}">
                @error('cedula_identidad')
                    <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
            <div class="form-group">
                <label for="nombre_cliente">Nombre:</label>
                <input type="text" name="nombre_cliente" id="nombre_cliente" class="form-control" value="{{ old('nombre_cliente') }}">
                @error('nombre_cliente')
                    <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
            <div class="form-group">
                <label for="apellido_cliente">Apellido:</label>
                <input type="text" name="apellido_cliente" id="apellido_cliente" class="form-control" value="{{ old('apellido_cliente') }}">
                @error('apellido_cliente')
                    <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
            <div class="form-group">
                <label for="telefono_cliente">Teléfono:</label>
                <input type="text" name="telefono_cliente" id="telefono_cliente" class="form-control" value="{{ old('telefono_cliente') }}">
                @error('telefono_cliente')
                    <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
            <div class="form-group">
                <label for="correo_cliente">Correo:</label>
                <input type="email" name="correo_cliente" id="correo_cliente" class="form-control" value="{{ old('correo_cliente') }}">
                @error('correo_cliente')
                    <div class="text-danger">{{ $message }}</div>
                @enderror
            </div>
            <button type="submit" class="btn btn-primary">Guardar</button>
        </form>
    </div>

    <!-- Alpine.js CDN -->
    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@2.x.x/dist/alpine.min.js" defer></script>

    <!-- Importar app.js desde Vite.js -->
    <script type="module" src="{{ mix('js/app.js') }}"></script>
@endsection
