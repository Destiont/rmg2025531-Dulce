import Alpine from 'alpinejs';
import './componentes/alpine';
import 'alpinejs';
import pagination from './componentes/clientes/clientesListado';

window.pagination = pagination;


window.Alpine = Alpine;

Alpine.start();
