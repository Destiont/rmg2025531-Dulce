mix.js('resources/js/app.js', 'public/js')
   .js('resources/js/componentes/clientes/clientesListado.js', 'public/js')
   .postCss('resources/css/app.css', 'public/css', [
       //
   ]);
