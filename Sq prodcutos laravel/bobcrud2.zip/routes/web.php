<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes(['verify' => true]); // Agrega las rutas de verificación de correo electrónico

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home')->middleware('verified');




use App\Http\Controllers\UserController;

Route::middleware(['auth'])->group(function () {
    Route::resource('users', UserController::class);
});



Route::middleware(['auth'])->group(function () {
    Route::resource('users', UserController::class)->middleware('role:admin');
});







Route::get('/empleadoprincipal', function () {
    return view('empleadoprincipal');
})->name('empleadoprincipal');


Route::get('/clienteprincipal', function () {
    return view('clienteprincipal');
})->name('clienteprincipal');


Route::get('/informacion', function () {
    return view('informacion');
})->name('informacion');




use App\Http\Controllers\ConfiguracionController;

Route::get('configuracion', [ConfiguracionController::class, 'index'])->name('configuracion');
Route::post('configuracion', [ConfiguracionController::class, 'actualizar'])->name('configuracion.actualizar');



use App\Http\Controllers\AmenidadController;

Route::get('/amenidades', [AmenidadController::class, 'index'])->name('amenidades.index');
Route::get('/amenidades/create', [AmenidadController::class, 'create'])->name('amenidades.create');
Route::post('/amenidades/store', [AmenidadController::class, 'store'])->name('amenidades.store');
Route::get('/amenidades/{amenidad}/edit', [AmenidadController::class, 'edit'])->name('amenidades.edit');
Route::put('/amenidades/{amenidad}/update', [AmenidadController::class, 'update'])->name('amenidades.update');
Route::delete('/amenidades/{amenidad}/destroy', [AmenidadController::class, 'destroy'])->name('amenidades.destroy');







use App\Http\Controllers\RolController;

// Ruta para mostrar todos los roles en una tabla
Route::get('/roles', [RolController::class, 'index'])->name('roles.index');

// Ruta para mostrar el formulario de creación de rol
Route::get('/roles/create', [RolController::class, 'create'])->name('roles.create');

// Ruta para almacenar un nuevo rol en la base de datos
Route::post('/roles', [RolController::class, 'store'])->name('roles.store');

// Ruta para mostrar los detalles de un rol específico
Route::get('/roles/{rol}', [RolController::class, 'show'])->name('roles.show');

// Ruta para mostrar el formulario de edición de un rol
Route::get('/roles/{rol}/edit', [RolController::class, 'edit'])->name('roles.edit');

// Ruta para actualizar los datos de un rol en la base de datos
Route::put('/roles/{rol}', [RolController::class, 'update'])->name('roles.update');

// Ruta para eliminar un rol de la base de datos
Route::delete('/roles/{rol}', [RolController::class, 'destroy'])->name('roles.destroy');



use App\Http\Controllers\EstadoController;

// Ruta para mostrar todos los estados en una tabla
Route::get('/estados', [EstadoController::class, 'index'])->name('estados.index');

// Ruta para mostrar el formulario de creación de estado
Route::get('/estados/create', [EstadoController::class, 'create'])->name('estados.create');

// Ruta para almacenar un nuevo estado en la base de datos
Route::post('/estados', [EstadoController::class, 'store'])->name('estados.store');

// Ruta para mostrar los detalles de un estado específico
Route::get('/estados/{estado}', [EstadoController::class, 'show'])->name('estados.show');

// Ruta para mostrar el formulario de edición de un estado
Route::get('/estados/{estado}/edit', [EstadoController::class, 'edit'])->name('estados.edit');

// Ruta para actualizar los datos de un estado en la base de datos
Route::put('/estados/{estado}', [EstadoController::class, 'update'])->name('estados.update');

// Ruta para eliminar un estado de la base de datos
Route::delete('/estados/{estado}', [EstadoController::class, 'destroy'])->name('estados.destroy');



use App\Http\Controllers\GeneroController;

// Ruta para mostrar todos los géneros en una tabla
Route::get('/generos', [GeneroController::class, 'index'])->name('generos.index');

// Ruta para mostrar el formulario de creación de género
Route::get('/generos/create', [GeneroController::class, 'create'])->name('generos.create');

// Ruta para almacenar un nuevo género en la base de datos
Route::post('/generos', [GeneroController::class, 'store'])->name('generos.store');

// Ruta para mostrar los detalles de un género específico
Route::get('/generos/{genero}', [GeneroController::class, 'show'])->name('generos.show');

// Ruta para mostrar el formulario de edición de un género
Route::get('/generos/{genero}/edit', [GeneroController::class, 'edit'])->name('generos.edit');

// Ruta para actualizar los datos de un género en la base de datos
Route::put('/generos/{genero}', [GeneroController::class, 'update'])->name('generos.update');

// Ruta para eliminar un género de la base de datos
Route::delete('/generos/{genero}', [GeneroController::class, 'destroy'])->name('generos.destroy');



use App\Http\Controllers\UsuarioController;

// Ruta para mostrar todos los usuarios en una tabla
Route::get('/usuarios', [UsuarioController::class, 'index'])->name('usuarios.index');

// Ruta para mostrar el formulario de creación de usuario
Route::get('/usuarios/create', [UsuarioController::class, 'create'])->name('usuarios.create');

// Ruta para almacenar un nuevo usuario en la base de datos
Route::post('/usuarios', [UsuarioController::class, 'store'])->name('usuarios.store');

// Ruta para mostrar los detalles de un usuario específico
Route::get('/usuarios/{usuario}', [UsuarioController::class, 'show'])->name('usuarios.show');

// Ruta para mostrar el formulario de edición de un usuario
Route::get('/usuarios/{usuario}/edit', [UsuarioController::class, 'edit'])->name('usuarios.edit');

// Ruta para actualizar los datos de un usuario en la base de datos
Route::put('/usuarios/{usuario}', [UsuarioController::class, 'update'])->name('usuarios.update');

// Ruta para eliminar un usuario de la base de datos
Route::delete('/usuarios/{usuario}', [UsuarioController::class, 'destroy'])->name('usuarios.destroy');



use App\Http\Controllers\EmpleadoController;

// Ruta para mostrar todos los empleados en una tabla
Route::get('/empleados', [EmpleadoController::class, 'index'])->name('empleados.index');

// Ruta para mostrar el formulario de creación de empleado
Route::get('/empleados/create', [EmpleadoController::class, 'create'])->name('empleados.create');

// Ruta para almacenar un nuevo empleado en la base de datos
Route::post('/empleados', [EmpleadoController::class, 'store'])->name('empleados.store');

// Ruta para mostrar los detalles de un empleado específico
Route::get('/empleados/{empleado}', [EmpleadoController::class, 'show'])->name('empleados.show');

// Ruta para mostrar el formulario de edición de un empleado
Route::get('/empleados/{empleado}/edit', [EmpleadoController::class, 'edit'])->name('empleados.edit');

// Ruta para actualizar los datos de un empleado en la base de datos
Route::put('/empleados/{empleado}', [EmpleadoController::class, 'update'])->name('empleados.update');

// Ruta para eliminar un empleado de la base de datos
Route::delete('/empleados/{empleado}', [EmpleadoController::class, 'destroy'])->name('empleados.destroy');



use App\Http\Controllers\InmuebleController;
Route::resource('inmuebles', InmuebleController::class);
Route::get('/inmuebles', [InmuebleController::class, 'index'])->name('inmuebles.index');
Route::get('/inmuebles/create', [InmuebleController::class, 'create'])->name('inmuebles.create');
Route::post('/inmuebles', [InmuebleController::class, 'store'])->name('inmuebles.store');
Route::get('/inmuebles/{inmueble}', [InmuebleController::class, 'show'])->name('inmuebles.show');
Route::get('/inmuebles/{inmueble}/edit', [InmuebleController::class, 'edit'])->name('inmuebles.edit');
Route::put('/inmuebles/{inmueble}', [InmuebleController::class, 'update'])->name('inmuebles.update');
Route::delete('/inmuebles/{inmueble}', [InmuebleController::class, 'destroy'])->name('inmuebles.destroy');






use App\Http\Controllers\TipoInmuebleController;

Route::get('/tipo_inmuebles', [TipoInmuebleController::class, 'index'])->name('tipo_inmuebles.index');
Route::get('/tipo_inmuebles/create', [TipoInmuebleController::class, 'create'])->name('tipo_inmuebles.create');
Route::post('/tipo_inmuebles', [TipoInmuebleController::class, 'store'])->name('tipo_inmuebles.store');
Route::get('/tipo_inmuebles/{tipo_inmueble}', [TipoInmuebleController::class, 'show'])->name('tipo_inmuebles.show');

Route::get('/tipo_inmuebles/{tipoInmueble}/edit', [TipoInmuebleController::class, 'edit'])->name('tipo_inmuebles.edit');
Route::put('/tipo_inmuebles/{tipoInmueble}', [TipoInmuebleController::class, 'update'])->name('tipo_inmuebles.update');
Route::delete('/tipo_inmuebles/{tipoInmueble}', [TipoInmuebleController::class, 'destroy'])->name('tipo_inmuebles.destroy');



use App\Http\Controllers\TipoVentaInmuebleController;

Route::get('/tipo_venta_inmuebles', [TipoVentaInmuebleController::class, 'index'])->name('tipo_venta_inmuebles.index');
Route::get('/tipo_venta_inmuebles/create', [TipoVentaInmuebleController::class, 'create'])->name('tipo_venta_inmuebles.create');
Route::post('/tipo_venta_inmuebles', [TipoVentaInmuebleController::class, 'store'])->name('tipo_venta_inmuebles.store');
Route::get('/tipo_venta_inmuebles/{tipoVentaInmueble}', [TipoVentaInmuebleController::class, 'show'])->name('tipo_venta_inmuebles.show');
Route::get('/tipo_venta_inmuebles/{tipoVentaInmueble}/edit', [TipoVentaInmuebleController::class, 'edit'])->name('tipo_venta_inmuebles.edit');
Route::put('/tipo_venta_inmuebles/{tipoVentaInmueble}', [TipoVentaInmuebleController::class, 'update'])->name('tipo_venta_inmuebles.update');
Route::delete('/tipo_venta_inmuebles/{tipoVentaInmueble}', [TipoVentaInmuebleController::class, 'destroy'])->name('tipo_venta_inmuebles.destroy');


use App\Http\Controllers\ServicioBasicoController;

Route::get('/servicios_basicos', [ServicioBasicoController::class, 'index'])->name('servicios_basicos.index');
Route::get('/servicios_basicos/create', [ServicioBasicoController::class, 'create'])->name('servicios_basicos.create');
Route::post('/servicios_basicos', [ServicioBasicoController::class, 'store'])->name('servicios_basicos.store');
Route::get('/servicios_basicos/{servicioBasico}', [ServicioBasicoController::class, 'show'])->name('servicios_basicos.show');
Route::get('/servicios_basicos/{servicioBasico}/edit', [ServicioBasicoController::class, 'edit'])->name('servicios_basicos.edit');
Route::put('/servicios_basicos/{servicioBasico}', [ServicioBasicoController::class, 'update'])->name('servicios_basicos.update');
Route::delete('/servicios_basicos/{servicioBasico}', [ServicioBasicoController::class, 'destroy'])->name('servicios_basicos.destroy');



use App\Http\Controllers\ServicioConvenienteController;

Route::get('/servicios_convenientes', [ServicioConvenienteController::class, 'index'])->name('servicios_convenientes.index');
Route::get('/servicios_convenientes/create', [ServicioConvenienteController::class, 'create'])->name('servicios_convenientes.create');
Route::post('/servicios_convenientes', [ServicioConvenienteController::class, 'store'])->name('servicios_convenientes.store');
Route::get('/servicios_convenientes/{servicioConveniente}', [ServicioConvenienteController::class, 'show'])->name('servicios_convenientes.show');
Route::get('/servicios_convenientes/{servicioConveniente}/edit', [ServicioConvenienteController::class, 'edit'])->name('servicios_convenientes.edit');
Route::put('/servicios_convenientes/{servicioConveniente}', [ServicioConvenienteController::class, 'update'])->name('servicios_convenientes.update');
Route::delete('/servicios_convenientes/{servicioConveniente}', [ServicioConvenienteController::class, 'destroy'])->name('servicios_convenientes.destroy');



use App\Http\Controllers\ServicioExtraController;

Route::get('/servicios_extras', [ServicioExtraController::class, 'index'])->name('servicios_extras.index');
Route::get('/servicios_extras/create', [ServicioExtraController::class, 'create'])->name('servicios_extras.create');
Route::post('/servicios_extras', [ServicioExtraController::class, 'store'])->name('servicios_extras.store');
Route::get('/servicios_extras/{servicioExtra}', [ServicioExtraController::class, 'show'])->name('servicios_extras.show');
Route::get('/servicios_extras/{servicioExtra}/edit', [ServicioExtraController::class, 'edit'])->name('servicios_extras.edit');
Route::put('/servicios_extras/{servicioExtra}', [ServicioExtraController::class, 'update'])->name('servicios_extras.update');
Route::delete('/servicios_extras/{servicioExtra}', [ServicioExtraController::class, 'destroy'])->name('servicios_extras.destroy');


use App\Http\Controllers\AmenidadInmuebleController;

Route::get('/amenidades_inmueble', [AmenidadInmuebleController::class, 'index'])->name('amenidades_inmueble.index');
Route::get('/amenidades_inmueble/create', [AmenidadInmuebleController::class, 'create'])->name('amenidades_inmueble.create');
Route::post('/amenidades_inmueble', [AmenidadInmuebleController::class, 'store'])->name('amenidades_inmueble.store');
Route::get('/amenidades_inmueble/{amenidadInmueble}', [AmenidadInmuebleController::class, 'show'])->name('amenidades_inmueble.show');
Route::get('/amenidades_inmueble/{amenidadInmueble}/edit', [AmenidadInmuebleController::class, 'edit'])->name('amenidades_inmueble.edit');
Route::put('/amenidades_inmueble/{amenidadInmueble}', [AmenidadInmuebleController::class, 'update'])->name('amenidades_inmueble.update');
Route::delete('/amenidades_inmueble/{amenidadInmueble}', [AmenidadInmuebleController::class, 'destroy'])->name('amenidades_inmueble.destroy');


use App\Http\Controllers\ServicioBasicoInmuebleController;

Route::get('/servicios_basicos_inmuebles', [ServicioBasicoInmuebleController::class, 'index'])->name('servicios_basicos_inmuebles.index');
Route::get('/servicios_basicos_inmuebles/create', [ServicioBasicoInmuebleController::class, 'create'])->name('servicios_basicos_inmuebles.create');
Route::post('/servicios_basicos_inmuebles', [ServicioBasicoInmuebleController::class, 'store'])->name('servicios_basicos_inmuebles.store');
Route::get('/servicios_basicos_inmuebles/{servicioBasicoInmueble}', [ServicioBasicoInmuebleController::class, 'show'])->name('servicios_basicos_inmuebles.show');
Route::get('/servicios_basicos_inmuebles/{servicioBasicoInmueble}/edit', [ServicioBasicoInmuebleController::class, 'edit'])->name('servicios_basicos_inmuebles.edit');
Route::put('/servicios_basicos_inmuebles/{servicioBasicoInmueble}', [ServicioBasicoInmuebleController::class, 'update'])->name('servicios_basicos_inmuebles.update');
Route::delete('/servicios_basicos_inmuebles/{servicioBasicoInmueble}', [ServicioBasicoInmuebleController::class, 'destroy'])->name('servicios_basicos_inmuebles.destroy');


use App\Http\Controllers\ServicioConvenienteInmuebleController;

Route::get('/servicios_convenientes_inmuebles', [ServicioConvenienteInmuebleController::class, 'index'])->name('servicios_convenientes_inmuebles.index');
Route::get('/servicios_convenientes_inmuebles/create', [ServicioConvenienteInmuebleController::class, 'create'])->name('servicios_convenientes_inmuebles.create');
Route::post('/servicios_convenientes_inmuebles', [ServicioConvenienteInmuebleController::class, 'store'])->name('servicios_convenientes_inmuebles.store');
Route::get('/servicios_convenientes_inmuebles/{servicioConvenienteInmueble}', [ServicioConvenienteInmuebleController::class, 'show'])->name('servicios_convenientes_inmuebles.show');
Route::get('/servicios_convenientes_inmuebles/{servicioConvenienteInmueble}/edit', [ServicioConvenienteInmuebleController::class, 'edit'])->name('servicios_convenientes_inmuebles.edit');
Route::put('/servicios_convenientes_inmuebles/{servicioConvenienteInmueble}', [ServicioConvenienteInmuebleController::class, 'update'])->name('servicios_convenientes_inmuebles.update');
Route::delete('/servicios_convenientes_inmuebles/{servicioConvenienteInmueble}', [ServicioConvenienteInmuebleController::class, 'destroy'])->name('servicios_convenientes_inmuebles.destroy');


use App\Http\Controllers\ServicioExtraInmuebleController;

Route::get('/servicios_extras_inmuebles', [ServicioExtraInmuebleController::class, 'index'])->name('servicios_extras_inmuebles.index');
Route::get('/servicios_extras_inmuebles/create', [ServicioExtraInmuebleController::class, 'create'])->name('servicios_extras_inmuebles.create');
Route::post('/servicios_extras_inmuebles', [ServicioExtraInmuebleController::class, 'store'])->name('servicios_extras_inmuebles.store');
Route::get('/servicios_extras_inmuebles/{servicioExtraInmueble}', [ServicioExtraInmuebleController::class, 'show'])->name('servicios_extras_inmuebles.show');
Route::get('/servicios_extras_inmuebles/{servicioExtraInmueble}/edit', [ServicioExtraInmuebleController::class, 'edit'])->name('servicios_extras_inmuebles.edit');
Route::put('/servicios_extras_inmuebles/{servicioExtraInmueble}', [ServicioExtraInmuebleController::class, 'update'])->name('servicios_extras_inmuebles.update');
Route::delete('/servicios_extras_inmuebles/{servicioExtraInmueble}', [ServicioExtraInmuebleController::class, 'destroy'])->name('servicios_extras_inmuebles.destroy');




use App\Http\Controllers\ClienteController;

Route::get('/clientes', [ClienteController::class, 'index'])->name('clientes.index');
Route::get('/clientes/create', [ClienteController::class, 'create'])->name('clientes.create');
Route::post('/clientes', [ClienteController::class, 'store'])->name('clientes.store');
Route::get('/clientes/{cliente}', [ClienteController::class, 'show'])->name('clientes.show');
Route::get('/clientes/{cliente}/edit', [ClienteController::class, 'edit'])->name('clientes.edit');
Route::put('/clientes/{cliente}/update', [ClienteController::class, 'update'])->name('clientes.update');
Route::delete('/clientes/{cliente}/destroy', [ClienteController::class, 'destroy'])->name('clientes.destroy');


use App\Http\Controllers\CitaController;

Route::resource('citas', CitaController::class);
Route::get('/citas', [CitaController::class, 'index'])->name('citas.index'); // Mostrar todas las citas
Route::get('/citas/create', [CitaController::class, 'create'])->name('citas.create'); // Mostrar formulario para crear una cita
Route::post('/citas', [CitaController::class, 'store'])->name('citas.store'); // Almacenar la nueva cita
Route::get('/citas/{cita}', [CitaController::class, 'show'])->name('citas.show'); // Mostrar detalles de una cita específica
Route::get('/citas/{cita}/edit', [CitaController::class, 'edit'])->name('citas.edit'); // Mostrar formulario para editar una cita
Route::put('/citas/{cita}', [CitaController::class, 'update'])->name('citas.update'); // Actualizar una cita existente
Route::delete('/citas/{cita}', [CitaController::class, 'destroy'])->name('citas.destroy'); // Eliminar una cita existente


use App\Http\Controllers\ComisionController;

Route::get('/comisiones', [ComisionController::class, 'index'])->name('comisiones.index'); // Mostrar todas las comisiones
Route::get('/comisiones/create', [ComisionController::class, 'create'])->name('comisiones.create'); // Mostrar formulario para crear una comisión
Route::post('/comisiones', [ComisionController::class, 'store'])->name('comisiones.store'); // Almacenar la nueva comisión
Route::get('/comisiones/{comision}', [ComisionController::class, 'show'])->name('comisiones.show'); // Mostrar detalles de una comisión específica
Route::get('/comisiones/{comision}/edit', [ComisionController::class, 'edit'])->name('comisiones.edit'); // Mostrar formulario para editar una comisión
Route::put('/comisiones/{comision}', [ComisionController::class, 'update'])->name('comisiones.update'); // Actualizar una comisión existente
Route::delete('/comisiones/{comision}', [ComisionController::class, 'destroy'])->name('comisiones.destroy'); // Eliminar una comisión existente


use App\Http\Controllers\InmueblesVistaController;

Route::get('/inmuebles-vista', [InmueblesVistaController::class, 'index'])->name('inmuebles_vista.index');
Route::get('/inmuebles-vista/create', [InmueblesVistaController::class, 'create'])->name('inmuebles_vista.create');
Route::post('/inmuebles-vista', [InmueblesVistaController::class, 'store'])->name('inmuebles_vista.store');
Route::get('/inmuebles-vista/{inmuebleVista}', [InmueblesVistaController::class, 'show'])->name('inmuebles_vista.show');
Route::get('/inmuebles-vista/{inmuebleVista}/edit', [InmueblesVistaController::class, 'edit'])->name('inmuebles_vista.edit');
Route::put('/inmuebles-vista/{inmuebleVista}', [InmueblesVistaController::class, 'update'])->name('inmuebles_vista.update');
Route::delete('/inmuebles-vista/{inmuebleVista}', [InmueblesVistaController::class, 'destroy'])->name('inmuebles_vista.destroy');



use App\Http\Controllers\MovimientoController;

// Ruta para mostrar todos los movimientos
Route::get('/movimientos', [MovimientoController::class, 'index'])->name('movimientos.index');

// Ruta para mostrar el formulario de creación de un movimiento
Route::get('/movimientos/create', [MovimientoController::class, 'create'])->name('movimientos.create');

// Ruta para almacenar un nuevo movimiento creado
Route::post('/movimientos', [MovimientoController::class, 'store'])->name('movimientos.store');

// Ruta para mostrar un movimiento específico
Route::get('/movimientos/{movimiento}', [MovimientoController::class, 'show'])->name('movimientos.show');

// Ruta para mostrar el formulario de edición de un movimiento
Route::get('/movimientos/{movimiento}/edit', [MovimientoController::class, 'edit'])->name('movimientos.edit');

// Ruta para actualizar un movimiento editado
Route::put('/movimientos/{movimiento}', [MovimientoController::class, 'update'])->name('movimientos.update');

// Ruta para eliminar un movimiento
Route::delete('/movimientos/{movimiento}', [MovimientoController::class, 'destroy'])->name('movimientos.destroy');




use App\Http\Controllers\ComentarioController;

Route::post('/comentarios', [ComentarioController::class, 'store'])->name('comentarios.store');
